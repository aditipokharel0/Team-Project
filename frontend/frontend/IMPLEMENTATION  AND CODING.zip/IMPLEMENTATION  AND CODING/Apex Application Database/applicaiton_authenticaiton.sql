create or replace FUNCTION authenticate_user(
  p_username IN VARCHAR2,
  p_password IN VARCHAR2
) RETURN BOOLEAN
IS
  l_cnt INTEGER;
BEGIN
  SELECT COUNT(*) 
    INTO l_cnt
    FROM (
      SELECT TRIM(Email)    AS Email, Password FROM CUSTOMER
      UNION ALL
      SELECT TRIM(Email)    AS Email, Password FROM TRADER
      UNION ALL
      SELECT TRIM(Email)    AS Email, Password FROM ADMIN_USERS
    )
   WHERE UPPER(Email)    = UPPER(TRIM(p_username))
     AND Password        = p_password;

  RETURN (l_cnt = 1);
END authenticate_user;
