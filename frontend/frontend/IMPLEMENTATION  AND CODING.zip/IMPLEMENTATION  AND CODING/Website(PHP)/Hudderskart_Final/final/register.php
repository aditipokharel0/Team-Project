<?php
// buffer output so we can redirect
ob_start();
session_start();
include 'connect.php';   // sets up $conn via oci_connect()

$error   = '';
$name    = $_POST['name']             ?? '';
$email   = $_POST['email']            ?? '';
$password= $_POST['password']         ?? '';
$confirm = $_POST['confirm-password'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1) Password match?
    if ($password !== $confirm) {
        $error = '⚠️ Passwords do not match.';
    } else {
        // 2) Email already registered?
        $chk = oci_parse($conn, "SELECT 1 FROM CUSTOMER WHERE Email = :email");
        oci_bind_by_name($chk, ":email", $email);
        oci_execute($chk);
        if (oci_fetch($chk)) {
            $error = '⚠️ Email already registered.';
        } else {
            // 3) Insert new customer (plain password as requested)
            //    — removed the Is_Verified column which didn’t exist
            $sql = "
              INSERT INTO CUSTOMER (
                Customer_ID, FullName, Email, Password
              ) VALUES (
                SEQ_CUSTOMER.NEXTVAL, :fullname, :email, :pass
              )
              RETURNING Customer_ID INTO :new_id
            ";
            $ins = oci_parse($conn, $sql);
            oci_bind_by_name($ins, ":fullname", $name);
            oci_bind_by_name($ins, ":email",    $email);
            oci_bind_by_name($ins, ":pass",     $password);
            oci_bind_by_name($ins, ":new_id",   $newId, -1, SQLT_INT);

            if (oci_execute($ins, OCI_COMMIT_ON_SUCCESS)) {
                // 4) Store session + generate OTP
                $_SESSION['customer_id']    = $newId;
                $_SESSION['customer_email'] = $email;
                $otp = rand(100000, 999999);
                $_SESSION['otp'] = $otp;

                // 5) Send OTP email
                $subject = 'HuddersKart Verification Code';
                $msg     = "Hello $name,\n\nYour code is: $otp";
                mail($email, $subject, $msg, "From: no-reply@hudderskart.com\r\n");

                // 6) Redirect to OTP page
                header('Location: verify.php');
                exit;
            } else {
                $e     = oci_error($ins);
                $error = '❌ Registration error: ' . htmlentities($e['message']);
            }
        }
    }
}

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HuddersKart – Sign Up</title>
  <link rel="stylesheet" href="./css/register.css">
</head>
<body>
  <?php include 'header.php'; ?>

  <main>
    <div class="container">
      <div class="signup-container">
        <div class="signup-header">
          <h1>Welcome To</h1>
          <h2>Sign Up</h2>
        </div>

        <?php if ($error): ?>
          <p style="color:red; text-align:center;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form id="signup-form" method="POST" action="">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name"
                   value="<?= htmlspecialchars($name) ?>"
                   required placeholder="Your full name">
          </div>
          <div class="form-group" style="position:relative;">
            <label for="email">Email</label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($email) ?>"
                   required placeholder="you@example.com">
          </div>
          <div class="form-group" style="position:relative;">
            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                   required placeholder="••••••••">
          </div>
          <div class="form-group" style="position:relative;">
            <label for="confirm-password">Confirm Password</label>
            <input type="password" id="confirm-password" name="confirm-password"
                   required placeholder="••••••••">
          </div>
          <button type="submit" class="submit-btn">SIGN UP</button>
        </form>

        <p style="text-align:center;">
          Already have an account? <a href="login.php">Sign In</a>
        </p>
      </div>
    </div>
  </main>

  <?php include 'footer.php'; ?>
  <script src="./script/register.js"></script>
</body>
</html>
