<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $output = shell_exec('python C:\xampp\htdocs\fi\final\main.py');
  echo "<pre>$output</pre>";

  // Check if UID was written
  $uid_file = 'last_uid.txt';
  if (!file_exists($uid_file)) {
    die('UID file not found. Please scan an RFID tag.');
  }
  $uid = trim(file_get_contents($uid_file));
  if (empty($uid)) {
    die('No UID found in file.');
  }

  echo "<p>RFID scan complete. Inserting or updating product...</p>";

  // Database connection
  $conn = oci_connect('hudderskart', '123456', 'localhost/XE');
  if (!$conn) {
    $e = oci_error();
    die('Connection failed: ' . $e['message']);
  }

  // Set product details based on UID
  if ($uid === '93513811') {
    $name = 'chicken meat';
    $price = 12.50;
    $quantity = 1;
    $description = 'Fresh chicken meat';
  } elseif ($uid === 'D71CCF01') {
    $name = 'buff';
    $price = 10.00;
    $quantity = 1;
    $description = 'Fresh buff meat';
  } else {
    oci_close($conn);
    die('Unknown UID scanned: ' . htmlspecialchars($uid));
  }

  // Common fields
  $shop_id = 500003;
  $category_id = 1000; // Use your actual category_id
  $is_active = 1;
  $min_order = 1;
  $max_order = 10;
  $allergy_info = 'None';
  $wishlist_count = 0;
  $trader_id = 20000;

  // Check if product already exists (by name and shop)
  $check_sql = "SELECT QUANTITY FROM PRODUCT WHERE NAME = :name AND SHOP_ID = :shop_id";
  $check_stid = oci_parse($conn, $check_sql);
  oci_bind_by_name($check_stid, ':name', $name);
  oci_bind_by_name($check_stid, ':shop_id', $shop_id);
  oci_execute($check_stid);
  $row = oci_fetch_assoc($check_stid);

  if ($row) {
    // Product exists, update quantity
    $new_quantity = $row['QUANTITY'] + $quantity;
    $update_sql = "UPDATE PRODUCT SET QUANTITY = :quantity WHERE NAME = :name AND SHOP_ID = :shop_id";
    $update_stid = oci_parse($conn, $update_sql);
    oci_bind_by_name($update_stid, ':quantity', $new_quantity);
    oci_bind_by_name($update_stid, ':name', $name);
    oci_bind_by_name($update_stid, ':shop_id', $shop_id);
    $r = oci_execute($update_stid);
    if ($r) {
      echo "Product already exists. Quantity updated to $new_quantity for UID: " . htmlspecialchars($uid);
    } else {
      $e = oci_error($update_stid);
      echo "Update failed: " . $e['message'];
    }
    oci_free_statement($update_stid);
  } else {
    // Product does not exist, insert new
    $sql = "INSERT INTO PRODUCT (
        SHOP_ID, CATEGORY_ID, NAME, PRICE, QUANTITY, DESCRIPTION, CREATED_AT, IS_ACTIVE,
        MIN_ORDER, MAX_ORDER, ALLERGY_INFO, IMAGE_URL, WISHLIST_COUNT, TRADER_ID
    ) VALUES (
        :shop_id, :category_id, :name, :price, :quantity, :description, SYSTIMESTAMP, :is_active,
        :min_order, :max_order, :allergy_info, :image_url, :wishlist_count, :trader_id
    )";
    $image_url = ''; // Leave image blank for now
    $stid = oci_parse($conn, $sql);
    oci_bind_by_name($stid, ':shop_id', $shop_id);
    oci_bind_by_name($stid, ':category_id', $category_id);
    oci_bind_by_name($stid, ':name', $name);
    oci_bind_by_name($stid, ':price', $price);
    oci_bind_by_name($stid, ':quantity', $quantity);
    oci_bind_by_name($stid, ':description', $description);
    oci_bind_by_name($stid, ':is_active', $is_active);
    oci_bind_by_name($stid, ':min_order', $min_order);
    oci_bind_by_name($stid, ':max_order', $max_order);
    oci_bind_by_name($stid, ':allergy_info', $allergy_info);
    oci_bind_by_name($stid, ':image_url', $image_url);
    oci_bind_by_name($stid, ':wishlist_count', $wishlist_count);
    oci_bind_by_name($stid, ':trader_id', $trader_id);

    $r = oci_execute($stid);

    if ($r) {
      echo "Product inserted successfully for UID: " . htmlspecialchars($uid);
    } else {
      $e = oci_error($stid);
      echo "Insert failed: " . $e['message'];
    }
    oci_free_statement($stid);
  }

  oci_free_statement($check_stid);
  oci_close($conn);
} else {
  // Show the button if not POST
  ?>
  <form method="post">
    <button type="submit">Scan RFID / Update</button>
  </form>
  <?php
}
?>