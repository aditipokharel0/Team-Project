<?php
session_start();
require_once 'connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['customer_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

try {
    $sql = "DELETE FROM CART_PRODUCT 
            WHERE FK1_CART_ID IN (
                SELECT CART_ID 
                FROM CART 
                WHERE FK1_CUSTOMER_ID = :customer_id
            )";
            
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ":customer_id", $_SESSION['customer_id']);
    $success = oci_execute($stmt);

    if (!$success) {
        throw new Exception(oci_error($stmt)['message']);
    }

    echo json_encode(['success' => true, 'message' => 'Cart cleared successfully']);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

oci_close($conn);
?>