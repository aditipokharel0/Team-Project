<?php
session_start();
include 'connect.php'; // ensures $conn is your Oracle connection

$login_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password =          $_POST['password'] ?? '';

    // 1) Fetch the customer record by email
    $sql = "
      SELECT CUSTOMER_ID,
             FULLNAME,
             PASSWORD
        FROM CUSTOMER
       WHERE EMAIL = :email
    ";
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ':email', $email);
    oci_execute($stmt);

    // 2) Attempt to fetch
    if ($row = oci_fetch_assoc($stmt)) {
        // 3) Plain‐text password match
        if ($password === $row['PASSWORD']) {
            // 4) Success: store in session & redirect
            $_SESSION['customer_id']   = $row['CUSTOMER_ID'];
            $_SESSION['customer_name'] = $row['FULLNAME'];
            header('Location: index.php');
            exit;
        } else {
            $login_message = '❌ Incorrect password.';
        }
    } else {
        $login_message = '❌ Email not found.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>HuddersKart – Login</title>
  <link rel="stylesheet" href="./css/login.css">
</head>
<body>
  <?php include 'header.php'; ?>

  <main class="main-content">
    <div class="login-container">

      <div class="login-header">
        <h1>Welcome To Login!</h1>
      </div>

      <?php if ($login_message): ?>
        <div class="login-message">
          <?= htmlentities($login_message) ?>
        </div>
      <?php endif; ?>

      <form id="login-form" method="POST" action="">
        <div class="form-group">
          <label for="email">Email</label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            required 
            placeholder="you@example.com"
            value="<?= htmlentities($_POST['email'] ?? '') ?>"
          >
        </div>

        <div class="form-group">
          <label for="password">Password</label>
          <input 
            type="password" 
            id="password" 
            name="password" 
            required 
            placeholder="************"
          >
          <div class="form-footer">
            <a href="#" class="forgot-password">Forgot Password?</a>
          </div>
        </div>

        <button type="submit" class="login-btn">LOGIN</button>
      </form>

      <div class="signup-prompt">
        Don't have an account? <a href="register.php">Sign up</a>
      </div>

    </div>
  </main>

  <?php include 'footer.php'; ?>
  <script src="./script/login.js"></script>
</body>
</html>
