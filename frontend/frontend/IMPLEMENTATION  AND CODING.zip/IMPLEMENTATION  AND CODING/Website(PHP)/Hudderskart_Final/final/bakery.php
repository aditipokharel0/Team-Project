<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HuddersKart - Butcher Products</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="/css/style.css">
  <style>
    /* ... your existing styles ... */
  </style>
</head>
<body>

  <!-- Header with Logo, Search & Cart Count -->
  <header class="header">
    <a href="/index.html" class="logo"><img src="images/logo.png" alt="HuddersKart Logo"></a>
    <div class="search-container">
      <input type="text" placeholder="Search">
      <i class="fa-solid fa-magnifying-glass"></i>
    </div>
    <div class="user-actions">
      <div class="cart-icon">
        <span>🛒</span>
        <span class="cart-count">0</span>
      </div>
      <a href="/login.html">Login</a>
      <a href="/register.html">Register</a>
      <a href="/costumer.html">👤</a>
    </div>
  </header>

  <!-- Main Navigation -->
  <nav class="main-nav">
    <div class="menu-toggle">☰</div>
    <ul class="nav-links">
      <!-- ... -->
    </ul>
  </nav>

  <!-- Main Content -->
  <main class="main-content">
    <div class="category-banner">
      <h1 class="banner-title">Butcher Shop</h1>
    </div>

    <div class="shop-filters">
      <!-- ... -->
    </div>

    <div class="product-grid">
      <!-- Example Product Card -->
      <div class="product-card">
        <div class="product-image">
          <img src="/api/placeholder/280/200" alt="Ribeye Steak">
        </div>
        <div class="product-details">
          <div class="product-name">Ribeye Steak</div>
          <div class="product-vendor">Smith's Family Butchers</div>
          <div class="product-price">12.99</div>
          <div class="product-actions">
            <!-- note data-id, data-name, data-price -->
            <button class="add-to-cart"
                    data-id="1"
                    data-name="Ribeye Steak"
                    data-price="12.99">
              Add to Cart
            </button>
            <div class="product-rating">★★★★★ (24)</div>
          </div>
        </div>
      </div>

      <!-- Repeat for each product, incrementing data-id -->
      <div class="product-card">
        <div class="product-image">
          <img src="/api/placeholder/280/200" alt="Free Range Chicken">
        </div>
        <div class="product-details">
          <div class="product-name">Free Range Chicken</div>
          <div class="product-vendor">Organic Farm Meats</div>
          <div class="product-price">8.50</div>
          <div class="product-actions">
            <button class="add-to-cart"
                    data-id="2"
                    data-name="Free Range Chicken"
                    data-price="8.50">
              Add to Cart
            </button>
            <div class="product-rating">★★★★☆ (18)</div>
          </div>
        </div>
      </div>

      <!-- ... more products ... -->

    </div>
  </main>

  <!-- Footer -->
  <div class="separator"></div>
  <footer>
    <!-- ... -->
  </footer>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      // --- initialize cart count from localStorage ---
      const cartCountEl = document.querySelector('.cart-count');
      const getCart = () => JSON.parse(localStorage.getItem('cartItems')) || [];
      const setCart = items => localStorage.setItem('cartItems', JSON.stringify(items));
      const updateCount = () => {
        const totalQty = getCart().reduce((sum, i) => sum + i.quantity, 0);
        cartCountEl.textContent = totalQty;
      };
      updateCount();

      // --- handle Add to Cart clicks ---
      document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', () => {
          const id    = btn.dataset.id;
          const name  = btn.dataset.name;
          const price = parseFloat(btn.dataset.price);
          let cart    = getCart();
          let item    = cart.find(x => x.id === id);

          if (item) {
            item.quantity += 1;
          } else {
            cart.push({ id, name, price, quantity: 1 });
          }

          setCart(cart);
          updateCount();
          alert(`✅ Added “${name}” to cart.`);
        });
      });
    });
  </script>
</body>
</html>
