<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard – Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    :root {
      --primary-color: #bee97a;
      --primary-dark: #a2c96a;
      --text-dark: #1a1a1a;
      --background: #f8fafc;
      --border: #e5e7eb;
      --card-bg: #ffffff;
      --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--background);
      color: var(--text-dark);
    }

    .layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: var(--primary-color);
      padding: 1.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      overflow-y: auto;
      z-index: 20;
    }

    .logo {
      display: flex;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .logo img {
      max-width: 250px;
      width: 100%;
      height: auto;
    }

    .sidebar ul {
      list-style: none;
    }

    .sidebar li {
      padding: 0.75rem 1rem;
      border-radius: 8px;
      font-weight: 500;
      color: #222;
      margin-bottom: 0.5rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: background 0.2s;
    }

    .sidebar li.active,
    .sidebar li:hover {
      background: #fff;
      color: var(--primary-color);
    }

    .topbar {
      position: fixed;
      top: 0;
      left: 260px;
      right: 0;
      height: 80px;
      background: var(--primary-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      z-index: 15;
      border-bottom: 1px solid var(--border);
    }

    .toggle-btn {
      font-size: 26px;
      background: none;
      border: none;
      cursor: pointer;
      color: #fff;
    }

    .topbar-right {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .topbar-icon {
      background: #fff;
      color: var(--primary-color);
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      cursor: pointer;
    }

    .avatar-circle {
      background: #fff;
      color: var(--primary-color);
      font-weight: 700;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
    }

    .main {
      margin-left: 260px;
      padding: 100px 1rem 2rem;
      width: 100%;
    }

    .welcome-message {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 1.5rem;
    }

    .dashboard-cards {
      display: flex;
      flex-wrap: wrap;
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .card {
      background: var(--card-bg);
      box-shadow: var(--shadow);
      padding: 1.5rem;
      border-radius: 12px;
      flex: 1 1 250px;
      min-width: 250px;
    }

    .card h3 {
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 0.5rem;
    }

    .card p {
      font-size: 20px;
      font-weight: 700;
      color: var(--primary-dark);
    }

    .quick-links {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
    }

    .quick-link {
      background: #fff;
      padding: 1rem 1.2rem;
      border: 1.5px solid var(--border);
      border-radius: 10px;
      font-weight: 600;
      color: #333;
      cursor: pointer;
      transition: 0.3s;
      text-align: center;
    }

    .quick-link:hover {
      background: var(--primary-color);
      color: #fff;
      border-color: var(--primary-color);
    }

    @media (max-width: 768px) {
      .sidebar {
        position: absolute;
        left: -260px;
        transition: left 0.3s ease;
      }

      .sidebar.active {
        left: 0;
      }

      .topbar {
        left: 0;
      }

      .main {
        margin-left: 0;
        padding: 100px 1rem 2rem;
      }
    }
  </style>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
      <div class="logo">
        <img src="assets/images/logo.png" alt="Logo">
      </div>
      <ul>
        <li class="active">📊 Dashboard</li>
       <ul>
  <li><a href="shop.php">➕ Shop</a></li>
  <li><a href="products.php">📦 Products</a></li>
  <li><a href="orders.php">📋 Orders</a></li>
  <li><a href="categories.php">📈Manage Product</a></li>
  <li><a href="logout.php">🚪 Logout</a></li>

</ul>

      </ul>
    </aside>

    <!-- Topbar -->
    <header class="topbar">
      <button class="toggle-btn" id="toggleBtn">☰</button>
      <div class="topbar-right">
        <div class="topbar-icon">🔔</div>
        <div class="topbar-icon">🛒</div>
        <div class="avatar-circle">A</div>
        <div class="topbar-icon">▼</div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="main">
      <div class="welcome-message">Welcome, Trader John!</div>

      <div class="dashboard-cards">
        <div class="card">
          <h3>Total Orders Today</h3>
          <p>23</p>
        </div>
        <div class="card">
          <h3>Low Stock Alerts</h3>
          <p>5 Items</p>
        </div>
        <div class="card">
          <h3>Upcoming Collection Slots</h3>
          <p>13:00–16:00, 16:00–19:00</p>
        </div>
      </div>

      <div class="quick-links">
        <div class="quick-link">➕ Add / Edit Products</div>
        <div class="quick-link">📋 View Orders</div>
        <div class="quick-link">📈 View Reports</div>
        <div class="quick-link">⚙️ Account Settings</div>
      </div>
    </main>
  </div>

  <script>
    // Toggle Sidebar for Mobile
    document.getElementById('toggleBtn').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('active');
    });
  </script>
</body>
</html>
