<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Order Management – Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    :root {
      --primary-color: #bee97a;
      --primary-dark: #a2c96a;
      --text-dark: #1a1a1a;
      --background: #f8fafc;
      --border: #e5e7eb;
      --card-bg: #ffffff;
      --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--background);
      color: var(--text-dark);
    }

    .layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: var(--primary-color);
      padding: 1.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      overflow-y: auto;
      z-index: 20;
    }

    .logo {
      display: flex;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .logo img {
      max-width: 250px;
      width: 100%;
      height: auto;
    }

    .sidebar ul {
      list-style: none;
    }

    .sidebar li {
      padding: 0.75rem 1rem;
      border-radius: 8px;
      font-weight: 500;
      color: #222;
      margin-bottom: 0.5rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: background 0.2s;
    }

    .sidebar li.active,
    .sidebar li:hover {
      background: #fff;
      color: var(--primary-color);
    }

    .topbar {
      position: fixed;
      top: 0;
      left: 260px;
      right: 0;
      height: 80px;
      background: var(--primary-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      z-index: 15;
      border-bottom: 1px solid var(--border);
    }

    .toggle-btn {
      font-size: 26px;
      background: none;
      border: none;
      cursor: pointer;
      color: #fff;
    }

    .topbar-right {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .topbar-icon {
      background: #fff;
      color: var(--primary-color);
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      cursor: pointer;
    }

    .avatar-circle {
      background: #fff;
      color: var(--primary-color);
      font-weight: 700;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
    }

    .main {
      margin-left: 260px;
      padding: 100px 1rem 2rem;
      width: 100%;
    }

    h2 {
      font-size: 24px;
      margin-bottom: 1.5rem;
    }

    .order-table {
      width: 100%;
      border-collapse: collapse;
      background: var(--card-bg);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: var(--shadow);
    }

    .order-table th,
    .order-table td {
      padding: 1rem;
      border-bottom: 1px solid var(--border);
      text-align: left;
      font-size: 15px;
    }

    .order-table th {
      background: var(--background);
    }

    .order-table td:last-child {
      white-space: nowrap;
    }

    .status {
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
      display: inline-block;
    }

    .status.pending {
      background: #facc15;
      color: #fff;
    }

    .status.completed {
      background: #34d399;
      color: #fff;
    }

    .status.cancelled {
      background: #f87171;
      color: #fff;
    }

    @media (max-width: 768px) {
      .sidebar {
        position: absolute;
        left: -260px;
        transition: left 0.3s ease;
      }

      .sidebar.active {
        left: 0;
      }

      .topbar {
        left: 0;
      }

      .main {
        margin-left: 0;
        padding: 100px 1rem 2rem;
      }

      .order-table {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
      <div class="logo">
        <img src="assets/images/logo.png" alt="Logo">
      </div>
      <ul>
        <li>📊 Dashboard</li>
        <li>➕ Add Trader</li>
        <li>📦 Products</li>
        <li class="active">📋 Orders</li>
        <li>📈 Reports</li>
        <li>⚙️ Settings</li>
        <li>🚪 Logout</li>
      </ul>
    </aside>

    <!-- Topbar -->
    <header class="topbar">
      <button class="toggle-btn" id="toggleBtn">☰</button>
      <div class="topbar-right">
        <div class="topbar-icon">🔔</div>
        <div class="topbar-icon">🛒</div>
        <div class="avatar-circle">A</div>
        <div class="topbar-icon">▼</div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="main">
      <h2>Order Management</h2>

      <table class="order-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Date</th>
            <th>Total (£)</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>#1001</td>
            <td>Emily Clark</td>
            <td>2024-05-15</td>
            <td>27.50</td>
            <td><span class="status pending">Pending</span></td>
          </tr>
          <tr>
            <td>#1002</td>
            <td>Jack Miller</td>
            <td>2024-05-14</td>
            <td>13.20</td>
            <td><span class="status completed">Completed</span></td>
          </tr>
          <tr>
            <td>#1003</td>
            <td>Sarah Ahmed</td>
            <td>2024-05-13</td>
            <td>45.99</td>
            <td><span class="status cancelled">Cancelled</span></td>
          </tr>
        </tbody>
      </table>
    </main>
  </div>

  <script>
    document.getElementById('toggleBtn').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('active');
    });
  </script>
</body>
</html>
