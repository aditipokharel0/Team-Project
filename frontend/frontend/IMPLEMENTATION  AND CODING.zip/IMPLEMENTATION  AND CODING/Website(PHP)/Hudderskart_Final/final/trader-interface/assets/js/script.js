// script.js

// === 1. Sidebar Toggle ===
document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggleBtn');
  const sidebar = document.getElementById('sidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
    });
  }

  // === 2. Preview uploaded photo ===
  const photoInput = document.getElementById('photo');
  const previewImg = document.getElementById('preview');

  if (photoInput && previewImg) {
    photoInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          previewImg.src = reader.result;
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // === 3. Auto-generate password (optional behavior) ===
  const autoGenCheckbox = document.getElementById('autoGen');
  const passwordInput = document.getElementById('password');

  if (autoGenCheckbox && passwordInput) {
    autoGenCheckbox.addEventListener('change', () => {
      if (autoGenCheckbox.checked) {
        const generated = Math.random().toString(36).slice(-10);
        passwordInput.value = generated;
        passwordInput.setAttribute('readonly', true);
      } else {
        passwordInput.removeAttribute('readonly');
        passwordInput.value = '';
      }
    });
  }
});
