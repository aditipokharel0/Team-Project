<?php
// products.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
include '../connect.php';

// ─────────────────────────────────────────────────────────────
// Pull trader_id & shop_id (GET/POST/session)
$trader_id  = intval($_REQUEST['trader_id']  ?? ($_SESSION['trader_id'] ?? 0));
if (!$trader_id) {
    header('Location: TraderLogin.php');
    exit;
}
$shop_id    = intval($_REQUEST['shop_id']    ?? 0);
$product_id = intval($_REQUEST['product_id'] ?? 0);
$action     = $_REQUEST['action']            ?? '';

// ─────────────────────────────────────────────────────────────
// Ensure PRODUCT_SEQ exists
$ddl = <<<PLSQL
BEGIN
  EXECUTE IMMEDIATE '
    CREATE SEQUENCE PRODUCT_SEQ
      START WITH 1
      INCREMENT BY 1
      NOCACHE
      NOCYCLE
  ';
EXCEPTION WHEN OTHERS THEN
  IF SQLCODE != -955 THEN RAISE; END IF;
END;
PLSQL;
oci_execute(oci_parse($conn, $ddl));

// ─────────────────────────────────────────────────────────────
// Handle POST: Add / Edit / Delete
$error   = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['product_name']  ?? '');
    $prd_desc    = trim($_POST['description']   ?? '');
    $price       = floatval($_POST['price']     ?? 0);
    $stock       = intval($_POST['stock']       ?? 0);
    $min_order   = intval($_POST['min_order']   ?? 1);
    $max_order   = intval($_POST['max_order']   ?? 1);
    $category_id = intval($_POST['category_id'] ?? 0);
    $uploadTmp   = $_FILES['product_image']['tmp_name'] ?? null;

    if ($action === 'add') {
        if ($shop_id <= 0) {
            $error = '⚠️ Please select a shop before adding.';
        } else {
            $sql = "
              INSERT INTO PRODUCT (
                PRODUCT_ID, PRODUCT_NAME, DESCRIPTION,
                PRICE, STOCK, MIN_ORDER, MAX_ORDER,
                FK1_SHOP_ID, FK2_TRADER_ID, FK3_CATEGORY_ID,
                PRODUCT_IMAGE, DATE_ADDED
              ) VALUES (
                PRODUCT_SEQ.NEXTVAL,
                :name, :prd_desc,
                :price, :stock, :min_order, :max_order,
                :shop_id, :trader_id, :cat_id,
                EMPTY_BLOB(), SYSDATE
              )
              RETURNING PRODUCT_IMAGE INTO :lob
            ";
            $stmt = oci_parse($conn, $sql);
            oci_bind_by_name($stmt, ':name',      $name);
            oci_bind_by_name($stmt, ':prd_desc',  $prd_desc);
            oci_bind_by_name($stmt, ':price',     $price);
            oci_bind_by_name($stmt, ':stock',     $stock);
            oci_bind_by_name($stmt, ':min_order', $min_order);
            oci_bind_by_name($stmt, ':max_order', $max_order);
            oci_bind_by_name($stmt, ':shop_id',   $shop_id);
            oci_bind_by_name($stmt, ':trader_id', $trader_id);
            oci_bind_by_name($stmt, ':cat_id',    $category_id);
            $lob = oci_new_descriptor($conn, OCI_D_LOB);
            oci_bind_by_name($stmt, ':lob', $lob, -1, OCI_B_BLOB);

            if (!oci_execute($stmt, OCI_DEFAULT)) {
                $e = oci_error($stmt);
                $error = "❌ Insert failed: " . $e['message'];
            } else {
                if ($uploadTmp) {
                    $lob->savefile($uploadTmp);
                }
                oci_commit($conn);
                $success = '✅ Product added successfully!';
            }
            $lob->free();
        }
    }
    elseif ($action === 'edit' && $product_id > 0) {
        if ($uploadTmp) {
            $sql = "
              UPDATE PRODUCT
                 SET PRODUCT_NAME    = :name,
                     DESCRIPTION     = :prd_desc,
                     PRICE           = :price,
                     STOCK           = :stock,
                     MIN_ORDER       = :min_order,
                     MAX_ORDER       = :max_order,
                     FK3_CATEGORY_ID = :cat_id,
                     PRODUCT_IMAGE   = EMPTY_BLOB()
               WHERE PRODUCT_ID      = :prod_id
                 AND FK1_SHOP_ID      = :shop_id
                 AND FK2_TRADER_ID    = :trader_id
              RETURNING PRODUCT_IMAGE INTO :lob
            ";
        } else {
            $sql = "
              UPDATE PRODUCT
                 SET PRODUCT_NAME    = :name,
                     DESCRIPTION     = :prd_desc,
                     PRICE           = :price,
                     STOCK           = :stock,
                     MIN_ORDER       = :min_order,
                     MAX_ORDER       = :max_order,
                     FK3_CATEGORY_ID = :cat_id
               WHERE PRODUCT_ID      = :prod_id
                 AND FK1_SHOP_ID      = :shop_id
                 AND FK2_TRADER_ID    = :trader_id
            ";
        }
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ':name',      $name);
        oci_bind_by_name($stmt, ':prd_desc',  $prd_desc);
        oci_bind_by_name($stmt, ':price',     $price);
        oci_bind_by_name($stmt, ':stock',     $stock);
        oci_bind_by_name($stmt, ':min_order', $min_order);
        oci_bind_by_name($stmt, ':max_order', $max_order);
        oci_bind_by_name($stmt, ':cat_id',    $category_id);
        if ($uploadTmp) {
            $lob = oci_new_descriptor($conn, OCI_D_LOB);
            oci_bind_by_name($stmt, ':lob', $lob, -1, OCI_B_BLOB);
        }
        oci_bind_by_name($stmt, ':prod_id',   $product_id);
        oci_bind_by_name($stmt, ':shop_id',   $shop_id);
        oci_bind_by_name($stmt, ':trader_id', $trader_id);

        if (!oci_execute($stmt, OCI_DEFAULT)) {
            $e = oci_error($stmt);
            $error = "❌ Update failed: " . $e['message'];
        } else {
            if ($uploadTmp) {
                $lob->savefile($uploadTmp);
            }
            oci_commit($conn);
            $success = '✅ Product updated successfully!';
            if (isset($lob)) $lob->free();
        }
    }
    elseif ($action === 'delete' && $product_id > 0) {
        $sql = "
          DELETE FROM PRODUCT
           WHERE PRODUCT_ID    = :prod_id
             AND FK1_SHOP_ID   = :shop_id
             AND FK2_TRADER_ID = :trader_id
        ";
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ':prod_id',   $product_id);
        oci_bind_by_name($stmt, ':shop_id',   $shop_id);
        oci_bind_by_name($stmt, ':trader_id', $trader_id);

        if (!oci_execute($stmt, OCI_DEFAULT)) {
            $e = oci_error($stmt);
            $error = "❌ Delete failed: " . $e['message'];
        } else {
            oci_commit($conn);
            $success = '✅ Product deleted successfully!';
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Fetch shops and categories
$shops = []; $categories = [];
$s = oci_parse($conn, "SELECT SHOP_ID, SHOP_NAME FROM SHOP WHERE FK1_TRADER_ID = :tid ORDER BY SHOP_NAME");
oci_bind_by_name($s, ':tid', $trader_id);
oci_execute($s);
while ($r = oci_fetch_assoc($s)) $shops[] = $r;

$c = oci_parse($conn, "SELECT CATEGORY_ID, CATEGORY_NAME FROM PRODUCT_CATEGORY ORDER BY CATEGORY_NAME");
oci_execute($c);
while ($r = oci_fetch_assoc($c)) $categories[] = $r;

// ─────────────────────────────────────────────────────────────
// If editing, pull existing row
$edit = [];
if ($action === 'edit' && $product_id > 0) {
    $e = oci_parse($conn, "
      SELECT PRODUCT_ID, PRODUCT_NAME, DESCRIPTION,
             PRICE, STOCK, MIN_ORDER, MAX_ORDER,
             FK3_CATEGORY_ID, PRODUCT_IMAGE
        FROM PRODUCT
       WHERE PRODUCT_ID   = :pid
         AND FK1_SHOP_ID  = :sid
         AND FK2_TRADER_ID= :tid
    ");
    oci_bind_by_name($e, ':pid', $product_id);
    oci_bind_by_name($e, ':sid', $shop_id);
    oci_bind_by_name($e, ':tid', $trader_id);
    oci_execute($e);
    $edit = oci_fetch_assoc($e) ?: [];
}

// ─────────────────────────────────────────────────────────────
// Fetch product list
$products = [];
if ($shop_id > 0) {
    $p = oci_parse($conn, "
      SELECT PRODUCT_ID, PRODUCT_NAME, PRICE, STOCK,
             TO_CHAR(DATE_ADDED,'YYYY-MM-DD') AS DATE_ADDED
        FROM PRODUCT
       WHERE FK1_SHOP_ID   = :sid
         AND FK2_TRADER_ID = :tid
       ORDER BY PRODUCT_NAME
    ");
    oci_bind_by_name($p, ':sid', $shop_id);
    oci_bind_by_name($p, ':tid', $trader_id);
    oci_execute($p);
    while ($r = oci_fetch_assoc($p)) $products[] = $r;
}

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Products</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    :root {
      --primary-color: #bee97a;
      --primary-dark:  #a2c96a;
      --text-dark:     #1a1a1a;
      --background:    #f8fafc;
      --border:        #e5e7eb;
      --card-bg:       #ffffff;
      --shadow:        0 4px 12px rgba(0,0,0,0.08);
    }
    * { box-sizing: border-box; margin:0; padding:0; }
    body { font-family:'Inter',sans-serif; background:var(--background); color:var(--text-dark); }
    .container { max-width:900px; margin:40px auto; padding:0 20px; }
    h1,h2 { color:var(--primary-dark); text-align:center; margin-bottom:20px; }
    .alert { padding:12px 20px; border-radius:6px; margin-bottom:20px; box-shadow:var(--shadow); }
    .alert.success { background:var(--primary-color); color:#fff; }
    .alert.error   { background:#fddede; color:#a33; }
    .shop-select { display:flex; justify-content:center; align-items:center; margin-bottom:30px; }
    .shop-select select { padding:8px; border:1px solid var(--border); border-radius:4px; }
    .form-wrap { background:var(--card-bg); padding:20px; border-radius:10px; box-shadow:var(--shadow); margin-bottom:40px; }
    .field { margin-bottom:15px; }
    .field label { display:block; margin-bottom:6px; font-weight:600; }
    .field input, .field select, .field textarea { width:100%; padding:8px; border:1px solid var(--border); border-radius:4px; }
    .field-group { display:flex; gap:20px; margin-bottom:15px; }
    .field-group .field { flex:1; }
    .actions { display:flex; gap:10px; justify-content:flex-end; }
    .actions button, .actions a { padding:10px 20px; border:none; border-radius:6px; font-weight:600; box-shadow:var(--shadow); cursor:pointer; text-decoration:none; }
    .actions button { background:var(--primary-color); color:#fff; }
    .actions a { background:var(--primary-dark); color:#fff; }
    .list table { width:100%; border-collapse:collapse; box-shadow:var(--shadow); }
    .list th, .list td { padding:12px; border:1px solid var(--border); text-align:left; }
    .list th { background:var(--primary-dark); color:#fff; }
    .thumbnail { max-width:60px; max-height:60px; object-fit:cover; border-radius:4px; }

    /* EDIT and DELETE link‐style buttons */
    .edit-btn,
    .delete-btn {
      background: none;
      border: none;
      color: #06c;            /* Edit = blue */
      text-decoration: underline;
      cursor: pointer;
      padding: 0;
      font: inherit;
    }
    .delete-btn {
      color: #06c;            /* Delete = red */
    }
  </style>
</head>
<body>
  <main class="container">
    <h1>Products</h1>
    <?php if ($success): ?><div class="alert success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Shop selector -->
    <form method="GET" action="products.php?trader_id=<?= $trader_id ?>" class="shop-select">
      <label for="shop_id">Select Shop:</label>
      <select name="shop_id" id="shop_id" onchange="this.form.submit()" required>
        <option value="">-- pick a shop --</option>
        <?php foreach ($shops as $s): ?>
          <option value="<?= $s['SHOP_ID'] ?>" <?= $s['SHOP_ID']==$shop_id?'selected':'' ?>>
            <?= htmlspecialchars($s['SHOP_NAME']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>

    <!-- Add / Edit form -->
    <section class="form-wrap">
      <h2><?= $action==='edit' ? 'Edit' : 'Add New' ?> Product</h2>
      <form method="POST" action="products.php?trader_id=<?= $trader_id ?>&shop_id=<?= $shop_id ?>" enctype="multipart/form-data">
        <input type="hidden" name="action"     value="<?= $action==='edit'?'edit':'add' ?>">
        <input type="hidden" name="product_id" value="<?= $product_id ?>">

        <div class="field">
          <label for="category_id">Category</label>
          <select id="category_id" name="category_id" required>
            <option value="">-- choose category --</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?= $c['CATEGORY_ID'] ?>" <?= ($edit['FK3_CATEGORY_ID']??0)==$c['CATEGORY_ID']?'selected':'' ?>>
                <?= htmlspecialchars($c['CATEGORY_NAME']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="field">
          <label for="product_image">Product Image</label>
          <input type="file" id="product_image" name="product_image" accept="image/*">
          <?php if (!empty($edit['PRODUCT_IMAGE'])):
            $lob = $edit['PRODUCT_IMAGE'];
            $data = is_object($lob) ? $lob->load() : $lob;
            $base64 = base64_encode($data);
          ?>
            <img src="data:image/jpeg;base64,<?= $base64 ?>" class="thumbnail" alt="Current Image">
          <?php endif; ?>
        </div>

        <div class="field">
          <label for="product_name">Name</label>
          <input type="text" id="product_name" name="product_name"
                 value="<?= htmlspecialchars($edit['PRODUCT_NAME']??'') ?>" required>
        </div>

        <div class="field">
          <label for="description">Description</label>
          <textarea id="description" name="description"><?= htmlspecialchars($edit['DESCRIPTION']??'') ?></textarea>
        </div>

        <div class="field-group">
          <div class="field">
            <label for="price">Price</label>
            <input type="number" id="price" name="price" step="0.01"
                   value="<?= htmlspecialchars($edit['PRICE']??0) ?>" required>
          </div>
          <div class="field">
            <label for="stock">Stock</label>
            <input type="number" id="stock" name="stock"
                   value="<?= htmlspecialchars($edit['STOCK']??0) ?>" required>
          </div>
        </div>

        <div class="field-group">
          <div class="field">
            <label for="min_order">Min Order</label>
            <input type="number" id="min_order" name="min_order"
                   value="<?= htmlspecialchars($edit['MIN_ORDER']??1) ?>" required>
          </div>
          <div class="field">
            <label for="max_order">Max Order</label>
            <input type="number" id="max_order" name="max_order"
                   value="<?= htmlspecialchars($edit['MAX_ORDER']??1) ?>" required>
          </div>
        </div>

        <div class="actions">
          <button type="submit"><?= $action==='edit' ? 'Update' : 'Add' ?> Product</button>
          <?php if ($action==='edit'): ?>
            <a href="products.php?trader_id=<?= $trader_id ?>&shop_id=<?= $shop_id ?>">Cancel</a>
          <?php endif; ?>
        </div>
      </form>
    </section>

    <!-- Products List -->
    <section class="list">
      <h2>Your Products</h2>
      <?php if (empty($products)): ?>
        <p>No products found.</p>
      <?php else: ?>
        <table>
          <thead>
            <tr>
              <th>Name</th><th>Price</th><th>Stock</th><th>Added</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $p): ?>
            <tr>
              <td><?= htmlspecialchars($p['PRODUCT_NAME']) ?></td>
              <td><?= htmlspecialchars($p['PRICE']) ?></td>
              <td><?= htmlspecialchars($p['STOCK']) ?></td>
              <td><?= htmlspecialchars($p['DATE_ADDED']) ?></td>
              <td>
                <form method="GET" action="products.php" style="display:inline">
                  <input type="hidden" name="action"     value="edit">
                  <input type="hidden" name="trader_id"  value="<?= $trader_id ?>">
                  <input type="hidden" name="shop_id"    value="<?= $shop_id ?>">
                  <input type="hidden" name="product_id" value="<?= $p['PRODUCT_ID'] ?>">
                  <button type="submit" class="edit-btn">Edit</button>
                </form>
                |
                <form method="POST"
                      action="products.php?trader_id=<?= $trader_id ?>&shop_id=<?= $shop_id ?>"
                      style="display:inline"
                      onsubmit="return confirm('Delete this product?')">
                  <input type="hidden" name="action"     value="delete">
                  <input type="hidden" name="product_id" value="<?= $p['PRODUCT_ID'] ?>">
                  <button type="submit" class="delete-btn">Delete</button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </section>
  </main>
</body>
</html>
