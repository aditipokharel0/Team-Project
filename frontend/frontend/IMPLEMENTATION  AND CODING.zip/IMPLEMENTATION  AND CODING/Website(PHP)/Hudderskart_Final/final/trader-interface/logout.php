<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Logout – Trader</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Inter', sans-serif;
      background: #f8fafc;
      color: #1a1a1a;
      display: flex;
      height: 100vh;
      justify-content: center;
      align-items: center;
    }
    .logout-container {
      background: #fff;
      border: 1px solid #e5e7eb;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      border-radius: 12px;
      padding: 40px 60px;
      text-align: center;
      max-width: 500px;
      width: 100%;
    }
    h1 {
      font-size: 28px;
      font-weight: 700;
      margin-bottom: 16px;
    }
    p {
      font-size: 16px;
      color: #4a4a4a;
      margin-bottom: 32px;
    }
    .btn {
      padding: 12px 24px;
      font-size: 16px;
      font-weight: 600;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      background: linear-gradient(90deg, #bee97a 60%, #a2c96a 100%);
      color: white;
      transition: background 0.3s ease;
      text-decoration: none;
      display: inline-block;
    }
    .btn:hover {
      background: linear-gradient(90deg, #a2c96a 60%, #bee97a 100%);
      color: #222;
    }
  </style>
</head>
<body>

  <div class="logout-container">
    <h1>You've been logged out</h1>
    <p>You have successfully logged out.Thank you for using HuddersKart. See You Again!</p>
    <a href="/fi/final/trader-interface/TraderLogin.php" class="btn">Login Again</a>
  </div>

</body>
</html>
