<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Product Detail – Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    :root {
      --primary-color: #bee97a;
      --primary-dark: #a2c96a;
      --text-dark: #1a1a1a;
      --background: #f8fafc;
      --border: #e5e7eb;
      --card-bg: #ffffff;
      --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--background);
      color: var(--text-dark);
    }

    .layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: var(--primary-color);
      padding: 1.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      overflow-y: auto;
      z-index: 20;
    }

    .logo {
      display: flex;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .logo img {
      max-width: 250px;
      width: 100%;
      height: auto;
    }

    .sidebar ul {
      list-style: none;
    }

    .sidebar li {
      padding: 0.75rem 1rem;
      border-radius: 8px;
      font-weight: 500;
      color: #222;
      margin-bottom: 0.5rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: background 0.2s;
    }

    .sidebar li.active,
    .sidebar li:hover {
      background: #fff;
      color: var(--primary-color);
    }

    .topbar {
      position: fixed;
      top: 0;
      left: 260px;
      right: 0;
      height: 80px;
      background: var(--primary-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      z-index: 15;
      border-bottom: 1px solid var(--border);
    }

    .toggle-btn {
      font-size: 26px;
      background: none;
      border: none;
      cursor: pointer;
      color: #fff;
    }

    .topbar-right {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .topbar-icon {
      background: #fff;
      color: var(--primary-color);
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      cursor: pointer;
    }

    .avatar-circle {
      background: #fff;
      color: var(--primary-color);
      font-weight: 700;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
    }

    .main {
      margin-left: 260px;
      padding: 100px 1rem 2rem;
      width: 100%;
    }

    h2 {
      font-size: 24px;
      margin-bottom: 1.5rem;
    }

    .product-wrapper {
      display: flex;
      flex-wrap: wrap;
      gap: 2rem;
      background: var(--card-bg);
      padding: 2rem;
      border-radius: 16px;
      box-shadow: var(--shadow);
      margin-bottom: 2rem;
      position: relative;
    }

    .product-image {
      flex: 0 0 300px;
      height: 300px;
      background: #f3f4f6;
      border-radius: 12px;
      border: 2px dashed var(--primary-color);
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      position: relative;
    }

    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .product-image label {
      position: absolute;
      bottom: 8px;
      left: 8px;
      background: rgba(0,0,0,0.6);
      color: #fff;
      padding: 4px 8px;
      font-size: 12px;
      border-radius: 4px;
      cursor: pointer;
    }

    .product-info {
      flex: 1;
    }

    .product-info h2 {
      font-size: 28px;
      margin-bottom: 0.5rem;
    }

    .product-info .shop-name {
      color: #4a4a4a;
      margin-bottom: 1rem;
      display: block;
    }

    .product-info .price {
      font-size: 24px;
      font-weight: 700;
      color: var(--primary-color);
      margin-bottom: 1.5rem;
    }

    .quantity-control {
      display: flex;
      align-items: center;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .quantity-control button {
      width: 36px;
      height: 36px;
      background: var(--primary-color);
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 18px;
      cursor: pointer;
    }

    .quantity-control button:hover {
      background: var(--primary-dark);
    }

    .quantity-display {
      font-weight: 600;
      font-size: 18px;
      width: 32px;
      text-align: center;
    }

    .add-to-cart {
      background: var(--primary-color);
      color: #fff;
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
    }

    .add-to-cart:hover {
      background: var(--primary-dark);
      color: #1a1a1a;
    }

    .tabs {
      display: flex;
      background: #f3f4f6;
      border: 1px solid var(--border);
      border-radius: 8px;
      overflow: hidden;
      margin-bottom: 0;
    }

    .tab {
      flex: 1;
      padding: 1rem;
      text-align: center;
      cursor: pointer;
      font-weight: 600;
      color: #4a4a4a;
    }

    .tab.active {
      background: #fff;
      color: var(--primary-color);
    }

    .tab-content {
      padding: 2rem;
      background: #fff;
      border: 1px solid var(--border);
      border-top: none;
      border-radius: 0 0 8px 8px;
    }

    @media (max-width: 768px) {
      .sidebar {
        position: absolute;
        left: -260px;
        transition: left 0.3s ease;
      }

      .sidebar.active {
        left: 0;
      }

      .topbar {
        left: 0;
      }

      .main {
        margin-left: 0;
        padding: 100px 1rem 2rem;
      }

      .product-wrapper {
        flex-direction: column;
        align-items: center;
      }
    }
  </style>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
      <div class="logo">
        <img src="assets/images/logo.png" alt="Logo">
      </div>
      <ul>
        <li href="/fi/final/trader-interface/traderdashboard.php">📊 Dashboard</li>
        <li href="/fi/final/trader-interface/shop.php">🛍️ Shop</li>
        <li href="/fi/final/trader-interface/productManagement.php">📦 Products</li>
        <li class="active" style="padding-left: 2rem;">🔍 Details</li>
        <li>📋 Orders</li>
        <li>📈 Reports</li>
        <li>⚙️ Settings</li>
        <li>🚪 Logout</li>
      </ul>
    </aside>

    <!-- Topbar -->
    <header class="topbar">
      <button class="toggle-btn" id="toggleBtn">☰</button>
      <div class="topbar-right">
        <div class="topbar-icon">🔔</div>
        <div class="topbar-icon">🛒</div>
        <div class="avatar-circle">A</div>
        <div class="topbar-icon">▼</div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="main">
      <h2>Product Details</h2>

      <div class="product-wrapper">
        <div class="product-image">
          <img id="previewImage" src="product-image.jpg" alt="Product Image">
          <input type="file" id="imageInput" accept="image/*" style="display: none;">
          <label for="imageInput">Change Image</label>
        </div>
        <div class="product-info">
          <h2>Organic Avocado</h2>
          <span class="shop-name">Fresh Farms Market</span>
          <div class="price">£2.49</div>

          <div class="quantity-control">
            <button onclick="changeQuantity(-1)">−</button>
            <span id="productQuantity" class="quantity-display">1</span>
            <button onclick="changeQuantity(1)">+</button>
          </div>

          <button class="add-to-cart" onclick="addToCart()">Add to Cart 🛒</button>
        </div>
      </div>

      <div class="tabs">
        <div class="tab active" onclick="showTab('source')">Source</div>
        <div class="tab" onclick="showTab('ingredients')">Ingredients</div>
        <div class="tab" onclick="showTab('nutrition')">Nutrition</div>
      </div>

      <div class="tab-content" id="tabContent">
        <h3>Fresh Farms Market</h3>
        <p>123 Organic Lane, Green Valley, CA 90210</p>
        <p>Our organic avocados are hand-picked at peak ripeness from sustainable farms in California.</p>
      </div>
    </main>
  </div>

  <script>
    document.getElementById('toggleBtn').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('active');
    });

    function changeQuantity(change) {
      const qtySpan = document.getElementById('productQuantity');
      let qty = parseInt(qtySpan.textContent);
      qty = Math.max(1, qty + change);
      qtySpan.textContent = qty;
    }

    function addToCart() {
      const qty = document.getElementById('productQuantity').textContent;
      alert(`${qty} item(s) added to cart.`);
    }

    function showTab(tab) {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelector(`.tab[onclick*="${tab}"]`).classList.add('active');

      const content = {
        source: `<h3>Fresh Farms Market</h3>
                 <p>123 Organic Lane, Green Valley, CA 90210</p>
                 <p>Our organic avocados are hand-picked at peak ripeness from sustainable farms in California.</p>`,
        ingredients: `<h3>Ingredients</h3>
                      <p>100% Organic Avocado</p><p>No additives or preservatives</p>`,
        nutrition: `<h3>Nutrition Facts</h3>
                    <p>Calories: 322</p><p>Total Fat: 29g</p><p>Fiber: 13g</p><p>Protein: 4g</p>`
      };

      document.getElementById('tabContent').innerHTML = content[tab];
    }

    // Image upload preview
    document.getElementById('imageInput').addEventListener('change', function(event) {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function(e) {
        document.getElementById('previewImage').src = e.target.result;
      };
      reader.readAsDataURL(file);
    });
  </script>
</body>
</html>
