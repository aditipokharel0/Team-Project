<?php
// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
include '../connect.php';

// Verify database connection
if (!$conn) {
    $e = oci_error();
    die("Database connection failed: " . $e['message']);
}

// 1) Determine the action: prefer POST over GET
$action  = $_POST['action'] ?? $_GET['action'] ?? '';
$shop_id = intval($_GET['id'] ?? 0);

// 2) Ensure trader is logged in
if (!isset($_SESSION['trader_id'])) {
    header('Location: login.php');
    exit;
}
$trader_id = $_SESSION['trader_id'];

$error   = '';
$success = '';

// 3) Handle form submissions (Add / Edit)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $shop_name        = trim($_POST['shop_name'] ?? '');
    $shop_description = trim($_POST['shop_description'] ?? '');

    // Validate inputs
    if (empty($shop_name)) {
        $error = 'Shop name is required.';
    } elseif (strlen($shop_name) > 250) {
        $error = 'Shop name must not exceed 250 characters.';
    } elseif (strlen($shop_description) > 2500) {
        $error = 'Shop description must not exceed 2500 characters.';
    } else {
        try {
            if ($action === 'add') {
                $sql = "
                    INSERT INTO SHOP (
                        SHOP_ID,
                        SHOP_NAME,
                        SHOP_DESCRIPTION,
                        FK1_TRADER_ID
                    ) VALUES (
                        SHOP_SEQ.NEXTVAL,
                        :name,
                        :description,
                        :trader_id
                    )
                ";
                $stmt = oci_parse($conn, $sql);
                oci_bind_by_name($stmt, ':name',        $shop_name);
                oci_bind_by_name($stmt, ':description', $shop_description);
                oci_bind_by_name($stmt, ':trader_id',   $trader_id);

                if (oci_execute($stmt, OCI_COMMIT_ON_SUCCESS)) {
                    // Get the last inserted ID
                    $sql_id = "SELECT SHOP_SEQ.CURRVAL AS SHOP_ID FROM DUAL";
                    $stmt_id = oci_parse($conn, $sql_id);
                    if (oci_execute($stmt_id)) {
                        $row = oci_fetch_assoc($stmt_id);
                        $new_id = $row['SHOP_ID'];
                        $success = "Shop added successfully (ID = $new_id)!";
                    } else {
                        $e = oci_error($stmt_id);
                        $error = 'Error retrieving new shop ID: ' . $e['message'];
                    }
                    oci_free_statement($stmt_id);
                } else {
                    $e = oci_error($stmt);
                    $error = 'Error adding shop: ' . $e['message'];
                }
                oci_free_statement($stmt);

            } elseif ($action === 'edit' && $shop_id > 0) {
                $sql = "
                    UPDATE SHOP
                    SET SHOP_NAME        = :name,
                        SHOP_DESCRIPTION = :description
                    WHERE SHOP_ID        = :shop_id
                    AND FK1_TRADER_ID    = :trader_id
                ";
                $stmt = oci_parse($conn, $sql);
                oci_bind_by_name($stmt, ':name',        $shop_name);
                oci_bind_by_name($stmt, ':description', $shop_description);
                oci_bind_by_name($stmt, ':shop_id',     $shop_id);
                oci_bind_by_name($stmt, ':trader_id',   $trader_id);

                if (oci_execute($stmt, OCI_COMMIT_ON_SUCCESS)) {
                    $success = 'Shop updated successfully!';
                } else {
                    $e = oci_error($stmt);
                    $error = 'Error updating shop: ' . $e['message'];
                }
                oci_free_statement($stmt);
            }
        } catch (Exception $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}

// 4) Handle delete action
if ($action === 'delete' && $shop_id > 0) {
    $sql = "
        DELETE FROM SHOP
        WHERE SHOP_ID       = :shop_id
        AND FK1_TRADER_ID   = :trader_id
    ";
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ':shop_id',   $shop_id);
    oci_bind_by_name($stmt, ':trader_id', $trader_id);

    if (oci_execute($stmt, OCI_COMMIT_ON_SUCCESS)) {
        $success = 'Shop deleted successfully!';
    } else {
        $e = oci_error($stmt);
        $error = 'Error deleting shop: ' . $e['message'];
    }
    oci_free_statement($stmt);
}

// 5) Fetch current trader's shops
$shops = [];
$sql = "
    SELECT SHOP_ID,
           SHOP_NAME,
           SHOP_DESCRIPTION
    FROM SHOP
    WHERE FK1_TRADER_ID = :trader_id
    ORDER BY SHOP_NAME
";
$stmt = oci_parse($conn, $sql);
oci_bind_by_name($stmt, ':trader_id', $trader_id);
if (oci_execute($stmt)) {
    while ($row = oci_fetch_assoc($stmt)) {
        $shops[] = $row;
    }
} else {
    $e = oci_error($stmt);
    $error = 'Error fetching shops: ' . $e['message'];
}
oci_free_statement($stmt);

// 6) If editing, fetch that shop row
$edit_shop = null;
if ($action === 'edit' && $shop_id > 0) {
    $sql = "
        SELECT SHOP_ID,
               SHOP_NAME,
               SHOP_DESCRIPTION
        FROM SHOP
        WHERE SHOP_ID       = :shop_id
        AND FK1_TRADER_ID   = :trader_id
    ";
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ':shop_id',   $shop_id);
    oci_bind_by_name($stmt, ':trader_id', $trader_id);
    if (oci_execute($stmt)) {
        $edit_shop = oci_fetch_assoc($stmt);
        if (!$edit_shop) {
            $error = 'Shop not found or you don\'t have permission to edit it';
            $action = ''; // Reset action if shop not found
        }
    } else {
        $e = oci_error($stmt);
        $error = 'Error fetching shop details: ' . $e['message'];
    }
    oci_free_statement($stmt);
}

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Shops</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/shop.css">
</head>
<body>
    <main class="shop-container">
        <h1>Manage Your Shops</h1>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Add / Edit Form -->
        <div class="shop-form">
            <h2><?= $action === 'edit' ? 'Edit Shop' : 'Add New Shop' ?></h2>
            <form id="shopForm" method="POST" action="shop.php?action=<?= htmlspecialchars($action ?: 'add') ?><?= $action === 'edit' ? '&id='.$shop_id : '' ?>">
                <!-- pass the action -->
                <input type="hidden" name="action" value="<?= htmlspecialchars($action ?: 'add') ?>">

                <div class="form-group">
                    <label for="shop_name">Shop Name</label>
                    <input
                        type="text"
                        id="shop_name"
                        name="shop_name"
                        value="<?= htmlspecialchars($edit_shop['SHOP_NAME'] ?? '') ?>"
                        required maxlength="250"
                    >
                </div>

                <div class="form-group">
                    <label for="shop_description">Description</label>
                    <textarea
                        id="shop_description"
                        name="shop_description"
                        maxlength="2500"
                    ><?= htmlspecialchars($edit_shop['SHOP_DESCRIPTION'] ?? '') ?></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-submit">
                        <?= $action === 'edit' ? 'Update' : 'Add' ?> Shop
                    </button>
                    <?php if ($action === 'edit'): ?>
                        <a href="shop.php" class="btn-cancel">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Shops List -->
        <div class="shops-list">
            <h2>Your Shops</h2>
            <?php if (empty($shops)): ?>
                <p>You don't have any shops yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Shop Name</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($shops as $shop): ?>
                        <tr>
                            <td><?= htmlspecialchars($shop['SHOP_NAME']) ?></td>
                            <td><?= htmlspecialchars($shop['SHOP_DESCRIPTION']) ?></td>
                            <td class="actions">
                                <a href="shop.php?action=edit&id=<?= $shop['SHOP_ID'] ?>" class="btn-edit">Edit</a>
                                <a href="#" class="btn-delete"
                                   data-id="<?= $shop['SHOP_ID'] ?>"
                                   data-name="<?= htmlspecialchars($shop['SHOP_NAME']) ?>">
                                    Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </main>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <p>Are you sure you want to delete "<span id="shopNameToDelete"></span>"?</p>
            <div class="modal-actions">
                <button id="confirmDelete" class="btn-danger">Delete</button>
                <button id="cancelDelete" class="btn-cancel">Cancel</button>
            </div>
        </div>
    </div>

    <script src="../script/shop.js"></script>
</body>
</html>