<?php
// categories.php
session_start();
ob_start();
include '../connect.php';

// 1) Ensure the sequence exists
$ddl = "
BEGIN
  DECLARE
    cnt INTEGER;
  BEGIN
    SELECT COUNT(*) INTO cnt
      FROM user_sequences
     WHERE sequence_name = 'CATEGORY_SEQ';
    IF cnt = 0 THEN
      EXECUTE IMMEDIATE 'CREATE SEQUENCE CATEGORY_SEQ
                         START WITH 1
                         INCREMENT BY 1
                         NOCACHE
                         NOCYCLE';
    END IF;
  END;
END;
";
$stmt = oci_parse($conn, $ddl);
oci_execute($stmt);

// 2) Process add/edit/delete
$action      = $_GET['action'] ?? $_POST['action'] ?? '';
$category_id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['category_name']        ?? '');
    $description = trim($_POST['category_description'] ?? '');
    
    if ($action === 'add') {
        $sql = "
          INSERT INTO PRODUCT_CATEGORY (
            CATEGORY_ID,
            CATEGORY_NAME,
            CATAGORY_DESCRIPTION
          ) VALUES (
            CATEGORY_SEQ.NEXTVAL,
            :cat_name,
            :cat_desc
          )
        ";
    }
    elseif ($action === 'edit' && $category_id > 0) {
        $sql = "
          UPDATE PRODUCT_CATEGORY
             SET CATEGORY_NAME        = :cat_name,
                 CATAGORY_DESCRIPTION = :cat_desc
           WHERE CATEGORY_ID         = :cat_id
        ";
    }
    
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ':cat_name', $name);
    oci_bind_by_name($stmt, ':cat_desc', $description);
    if ($action === 'edit') {
        oci_bind_by_name($stmt, ':cat_id', $category_id);
    }
    
    if (oci_execute($stmt, OCI_COMMIT_ON_SUCCESS)) {
        $success = "Category " . ($action === 'add' ? 'added' : 'updated') . " successfully!";
    } else {
        $error = "Error: " . oci_error($stmt)['message'];
    }
}
elseif ($action === 'delete' && $category_id > 0) {
    $sql  = "DELETE FROM PRODUCT_CATEGORY WHERE CATEGORY_ID = :cat_id";
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ':cat_id', $category_id);
    if (oci_execute($stmt, OCI_COMMIT_ON_SUCCESS)) {
        $success = "Category deleted successfully!";
    } else {
        $error = "Error: " . oci_error($stmt)['message'];
    }
}

// 3) Fetch data for display
$categories = [];
$sql        = "
  SELECT CATEGORY_ID,
         CATEGORY_NAME,
         CATAGORY_DESCRIPTION
    FROM PRODUCT_CATEGORY
ORDER BY CATEGORY_NAME
";
$stmt = oci_parse($conn, $sql);
oci_execute($stmt);
while ($row = oci_fetch_assoc($stmt)) {
    $categories[] = $row;
}

$edit = [];
if ($action === 'edit' && $category_id > 0) {
    $sql  = "SELECT * FROM PRODUCT_CATEGORY WHERE CATEGORY_ID = :cat_id";
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ':cat_id', $category_id);
    oci_execute($stmt);
    $edit = oci_fetch_assoc($stmt) ?: [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Product Categories</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root {
      --primary: #4CAF50;
      --primary-light: #66BB6A;
      --danger: #E53935;
      --gray-light: #f5f5f5;
      --gray: #888;
      --bg: #fafafa;
      --text: #333;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: 'Segoe UI', Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
    }
    .container {
      max-width: 1000px;
      margin: 40px auto;
      padding: 0 20px;
    }
    h1, h2 {
      margin-bottom: 20px;
      color: var(--primary);
    }
    .alert {
      padding: 12px 20px;
      margin-bottom: 20px;
      border-radius: 4px;
      position: relative;
    }
    .alert.success {
      background: #e8f5e9;
      border-left: 4px solid var(--primary);
    }
    .alert.error {
      background: #ffebee;
      border-left: 4px solid var(--danger);
    }
    form {
      background: #fff;
      padding: 20px;
      border-radius: 6px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      margin-bottom: 40px;
    }
    .form-group {
      margin-bottom: 16px;
    }
    label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
    }
    input[type="text"],
    textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid var(--gray-light);
      border-radius: 4px;
      font-size: 1rem;
    }
    textarea {
      resize: vertical;
      min-height: 80px;
    }
    .btn {
      display: inline-block;
      padding: 10px 18px;
      font-size: 1rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      margin-right: 10px;
      transition: background 0.2s;
    }
    .btn-primary {
      background: var(--primary);
      color: #fff;
    }
    .btn-primary:hover {
      background: var(--primary-light);
    }
    .btn-secondary {
      background: #ccc;
      color: #333;
    }
    .btn-secondary:hover {
      background: #bbb;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid var(--gray-light);
    }
    th {
      background: var(--gray-light);
      text-transform: uppercase;
      font-size: 0.9rem;
    }
    tr:nth-child(even) {
      background: #fdfdfd;
    }
    tr:hover {
      background: #f1f1f1;
    }
    .actions a {
      margin-right: 8px;
      font-size: 0.9rem;
    }
    @media (max-width: 600px) {
      .actions a {
        display: block;
        margin-bottom: 6px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Manage Product Categories</h1>
    
    <?php if (!empty($success)): ?>
      <div class="alert success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
      <div class="alert error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="categories.php">
      <input type="hidden" name="action" value="<?= $action === 'edit' ? 'edit' : 'add' ?>">
      <?php if ($action === 'edit'): ?>
        <input type="hidden" name="id" value="<?= $category_id ?>">
      <?php endif; ?>

      <div class="form-group">
        <label for="category_name">Category Name</label>
        <input id="category_name" type="text" name="category_name"
               value="<?= htmlspecialchars($edit['CATEGORY_NAME'] ?? '') ?>" required>
      </div>

      <div class="form-group">
        <label for="category_description">Description</label>
        <textarea id="category_description" name="category_description"><?= htmlspecialchars($edit['CATAGORY_DESCRIPTION'] ?? '') ?></textarea>
      </div>

      <button type="submit" class="btn btn-primary">
        <?= $action === 'edit' ? 'Update' : 'Add' ?> Category
      </button>
      <?php if ($action === 'edit'): ?>
        <a href="categories.php" class="btn btn-secondary">Cancel</a>
      <?php endif; ?>
    </form>

    <h2>Existing Categories</h2>
    <table>
      <thead>
        <tr><th>Name</th><th>Description</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($categories as $cat): ?>
        <tr>
          <td><?= htmlspecialchars($cat['CATEGORY_NAME']) ?></td>
          <td><?= htmlspecialchars($cat['CATAGORY_DESCRIPTION']) ?></td>
          <td class="actions">
            <a href="categories.php?action=edit&id=<?= $cat['CATEGORY_ID'] ?>" class="btn btn-secondary">Edit</a>
            <a href="categories.php?action=delete&id=<?= $cat['CATEGORY_ID'] ?>" class="btn btn-secondary"
               onclick="return confirm('Delete this category?')">Delete</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
<?php ob_end_flush(); ?>
