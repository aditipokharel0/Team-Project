<?php
// login.php
session_start();
ob_start();

// Define base URL for consistent redirects
define('BASE_URL', 'http://localhost/fi/final/trader-interface/');

// Database connection
include "../connect.php";

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = false;
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF token validation failed");
    }

    // Input sanitization
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = true;
        $error_message = "Email/Username and password are required";
    } else {
        // Database query
        $sql = "SELECT TRADER_ID, USERNAME, PASSWORD, EMAIL, FIRSTNAME 
                FROM TRADER 
                WHERE LOWER(EMAIL) = LOWER(:email) 
                OR LOWER(USERNAME) = LOWER(:email)";
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ":email", $email);
        
        if (oci_execute($stmt)) {
            if ($row = oci_fetch_assoc($stmt)) {
                $dbHash = trim($row["PASSWORD"]);
                $login_valid = false;

                // Multiple password hash type support
                if (password_verify($password, $dbHash)) {
                    $login_valid = true;
                } elseif (hash_equals($dbHash, hash('sha256', $password))) {
                    $login_valid = true;
                } elseif ($password === $dbHash) { // Remove in production
                    $login_valid = true;
                    error_log("Warning: Plain text password used for user " . $row["EMAIL"]);
                }

                if ($login_valid) {
                    // Session handling
                    session_regenerate_id(true);
                    $_SESSION = [
                        'trader_id' => (int)$row["TRADER_ID"],
                        'username' => htmlspecialchars($row["USERNAME"], ENT_QUOTES, 'UTF-8'),
                        'email' => htmlspecialchars($row["EMAIL"], ENT_QUOTES, 'UTF-8'),
                        'firstname' => htmlspecialchars($row["FIRSTNAME"], ENT_QUOTES, 'UTF-8'),
                        'last_activity' => time(),
                        'authenticated' => true
                    ];

                    // Output JavaScript to store trader_id and redirect
                    echo '<!DOCTYPE html>
                    <html>
                    <head>
                        <script>
                            localStorage.setItem("trader_id", "'.(int)$_SESSION['trader_id'].'");
                            window.location.href = "'.htmlspecialchars(BASE_URL.'traderdashboard.php', ENT_QUOTES).'";
                        </script>
                    </head>
                    <body>
                        <p>Login successful. Redirecting...</p>
                    </body>
                    </html>';
                    exit();
                }
            }
        } else {
            error_log("Database error: " . oci_error($conn));
        }

        // Generic error message (don't reveal specific details)
        $error = true;
        $error_message = "Invalid credentials";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trader Login – HuddersKart</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #bee97a;
            --primary-dark: #a2c96a;
            --text-dark: #1a1a1a;
            --background: #f8fafc;
            --border: #e5e7eb;
            --card-bg: #ffffff;
            --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --error-color: #f44336;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(120deg, #e8f8c9 0%, #bee97a 100%);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
        }
        .login-container {
            background: var(--card-bg);
            padding: 2.5rem 2rem;
            border-radius: 12px;
            box-shadow: var(--shadow);
            max-width: 400px;
            width: 100%;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 24px;
            font-weight: 700;
        }
        .form-group { margin-bottom: 1.2rem; }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            font-size: 15px;
        }
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 1.5px solid var(--border);
            border-radius: 8px;
            background: var(--background);
            font-size: 1rem;
            transition: border 0.2s, box-shadow 0.2s;
        }
        input:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(190, 233, 122, 0.2);
        }
        .form-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .form-footer a {
            color: var(--primary-dark);
            text-decoration: none;
            font-weight: 500;
        }
        .login-btn {
            width: 100%;
            padding: 0.9rem;
            border: none;
            border-radius: 8px;
            background: linear-gradient(90deg, #bee97a 60%, #a2c96a 100%);
            color: white;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s, box-shadow 0.2s;
        }
        .login-btn:hover {
            background: linear-gradient(90deg, #a2c96a 60%, #bee97a 100%);
            color: #222;
            box-shadow: 0 4px 16px rgba(190, 233, 122, 0.25);
        }
        .error-message {
            color: var(--error-color);
            background-color: #ffebee;
            padding: 12px;
            border-radius: 8px;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
            display: <?= $error ? 'block' : 'none' ?>;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Trader Login</h2>
        <?php if ($error): ?>
            <div class="error-message"><?= htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div class="form-group">
                <label for="email">Email or Username</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="you@example.com"
                    value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    required
                    autofocus
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="••••••••"
                    required
                >
            </div>

            <div class="form-footer">
                <label>
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <a href="forgot-password.php">Forgot password?</a>
            </div>

            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>
</body>
</html>
<?php
ob_end_flush();
?>