<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Profile Settings – Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    :root {
      --primary-color: #bee97a;
      --primary-dark: #a2c96a;
      --text-dark: #1a1a1a;
      --background: #f8fafc;
      --border: #e5e7eb;
      --card-bg: #ffffff;
      --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--background);
      color: var(--text-dark);
    }

    .layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: var(--primary-color);
      padding: 1.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      overflow-y: auto;
      z-index: 20;
    }

    .logo {
      display: flex;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .logo img {
      max-width: 250px;
      width: 100%;
      height: auto;
    }

    .sidebar ul {
      list-style: none;
    }

    .sidebar li {
      padding: 0.75rem 1rem;
      border-radius: 8px;
      font-weight: 500;
      color: #222;
      margin-bottom: 0.5rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: background 0.2s;
    }

    .sidebar li.active,
    .sidebar li:hover {
      background: #fff;
      color: var(--primary-color);
    }

    .topbar {
      position: fixed;
      top: 0;
      left: 260px;
      right: 0;
      height: 80px;
      background: var(--primary-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      z-index: 15;
      border-bottom: 1px solid var(--border);
    }

    .toggle-btn {
      font-size: 26px;
      background: none;
      border: none;
      cursor: pointer;
      color: #fff;
    }

    .topbar-right {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .topbar-icon {
      background: #fff;
      color: var(--primary-color);
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      cursor: pointer;
    }

    .avatar-circle {
      background: #fff;
      color: var(--primary-color);
      font-weight: 700;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
    }

    .main {
      margin-left: 260px;
      padding: 100px 1rem 2rem;
      width: 100%;
    }

    h2 {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 1.5rem;
    }

    .profile-wrapper {
      background: var(--card-bg);
      padding: 2rem;
      border-radius: 12px;
      box-shadow: var(--shadow);
      display: flex;
      flex-wrap: wrap;
      gap: 2rem;
    }

    .profile-section {
      flex: 1;
      min-width: 250px;
      text-align: center;
    }

    .profile-picture {
      width: 180px;
      height: 180px;
      border-radius: 50%;
      background: linear-gradient(135deg, #e8f8c9 0%, #bee97a 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 64px;
      color: white;
      margin: 0 auto 1rem;
      background-size: cover;
      background-position: center;
      border: 4px solid #fff;
    }

    .upload-btn {
      background: var(--primary-color);
      color: #fff;
      padding: 0.6rem 1.2rem;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
    }

    input[type="file"] {
      display: none;
    }

    form {
      flex: 2;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.5rem;
    }

    .form-group {
      display: flex;
      flex-direction: column;
    }

    .form-group.full {
      grid-column: span 2;
    }

    label {
      font-weight: 600;
      margin-bottom: 0.5rem;
    }

    input, select {
      padding: 0.75rem;
      border: 1px solid var(--border);
      border-radius: 8px;
      background: var(--background);
      font-size: 1rem;
    }

    button[type="submit"] {
      background: var(--primary-color);
      border: none;
      color: #fff;
      font-weight: 600;
      padding: 1rem;
      border-radius: 8px;
      grid-column: span 2;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s ease;
    }

    button[type="submit"]:hover {
      background: var(--primary-dark);
      color: #1a1a1a;
    }

    @media (max-width: 768px) {
      .sidebar {
        position: absolute;
        left: -260px;
        transition: left 0.3s ease;
      }

      .sidebar.active {
        left: 0;
      }

      .topbar {
        left: 0;
      }

      .main {
        margin-left: 0;
        padding: 100px 1rem 2rem;
      }

      form {
        grid-template-columns: 1fr;
      }

      .profile-wrapper {
        flex-direction: column;
        align-items: center;
      }
    }
  </style>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
      <div class="logo">
        <img src="assets/images/logo.png" alt="Logo">
      </div>
      <ul>
        <li>📊 Dashboard</li>
        <li>➕ Add Trader</li>
        <li>📦 Products</li>
        <li>📋 Orders</li>
        <li>📈 Reports</li>
        <li class="active">⚙️ Settings</li>
        <li>🚪 Logout</li>
      </ul>
    </aside>

    <!-- Topbar -->
    <header class="topbar">
      <button class="toggle-btn" id="toggleBtn">☰</button>
      <div class="topbar-right">
        <div class="topbar-icon">🔔</div>
        <div class="topbar-icon">🛒</div>
        <div class="avatar-circle">A</div>
        <div class="topbar-icon">▼</div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="main">
      <h2>Profile Settings</h2>
      <div class="profile-wrapper">
        <!-- Profile Picture -->
        <div class="profile-section">
          <div class="profile-picture" id="profilePreview">👤</div>
          <label for="profileImage" class="upload-btn">Upload Image</label>
          <input type="file" id="profileImage" accept="image/*">
        </div>

        <!-- Form -->
        <form id="profileForm">
          <div class="form-group">
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" placeholder="John">
          </div>
          <div class="form-group">
            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" placeholder="Doe">
          </div>
          <div class="form-group full">
            <label for="email">Email Address</label>
            <input type="email" id="email" placeholder="you@example.com">
          </div>
          <div class="form-group full">
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" placeholder="+44 1234 567890">
          </div>
          <div class="form-group full">
            <label for="address">Address</label>
            <input type="text" id="address" placeholder="123 Market Street">
          </div>
          <div class="form-group">
            <label for="currency">Preferred Currency</label>
            <select id="currency">
              <option value="">Select currency</option>
              <option value="GBP">GBP – British Pound</option>
              <option value="USD">USD – US Dollar</option>
              <option value="EUR">EUR – Euro</option>
            </select>
          </div>
          <div class="form-group">
            <label for="password">New Password</label>
            <input type="password" id="password" placeholder="Enter new password">
          </div>
          <div class="form-group full">
            <label for="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" placeholder="Re-enter new password">
          </div>
          <button type="submit">Save Changes</button>
        </form>
      </div>
    </main>
  </div>

  <script>
    // Sidebar toggle for mobile
    document.getElementById('toggleBtn').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('active');
    });

    // Profile image preview
    document.getElementById("profileImage").addEventListener("change", function (event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
          const preview = document.getElementById("profilePreview");
          preview.style.backgroundImage = `url('${e.target.result}')`;
          preview.textContent = "";
        };
        reader.readAsDataURL(file);
      }
    });

    // Password match check
    document.getElementById("profileForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const pw = document.getElementById("password").value;
      const cpw = document.getElementById("confirmPassword").value;
      if (pw && pw !== cpw) {
        alert("Passwords do not match!");
        return;
      }
      alert("Profile saved successfully.");
    });
  </script>
</body>
</html>
