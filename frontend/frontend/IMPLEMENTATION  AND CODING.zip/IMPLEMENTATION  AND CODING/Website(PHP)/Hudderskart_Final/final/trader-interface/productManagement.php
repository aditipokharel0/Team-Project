<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Product Management – Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    :root {
      --primary-color: #bee97a;
      --primary-dark: #a2c96a;
      --text-dark: #1a1a1a;
      --background: #f8fafc;
      --border: #e5e7eb;
      --card-bg: #ffffff;
      --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--background);
      color: var(--text-dark);
    }

    .layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: var(--primary-color);
      padding: 1.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      overflow-y: auto;
      z-index: 20;
    }

    .logo {
      display: flex;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .logo img {
      max-width: 250px;
      width: 100%;
      height: auto;
    }

    .sidebar ul {
      list-style: none;
    }

    .sidebar li {
      padding: 0.75rem 1rem;
      border-radius: 8px;
      font-weight: 500;
      color: #222;
      margin-bottom: 0.5rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: background 0.2s;
    }

    .sidebar li.active,
    .sidebar li:hover {
      background: #fff;
      color: var(--primary-color);
    }

    .topbar {
      position: fixed;
      top: 0;
      left: 260px;
      right: 0;
      height: 80px;
      background: var(--primary-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      z-index: 15;
      border-bottom: 1px solid var(--border);
    }

    .toggle-btn {
      font-size: 26px;
      background: none;
      border: none;
      cursor: pointer;
      color: #fff;
    }

    .topbar-right {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .topbar-icon {
      background: #fff;
      color: var(--primary-color);
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      cursor: pointer;
    }

    .avatar-circle {
      background: #fff;
      color: var(--primary-color);
      font-weight: 700;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
    }

    .main {
      margin-left: 260px;
      padding: 100px 1rem 2rem;
      width: 100%;
    }

    h2 {
      font-size: 24px;
      margin-bottom: 1.5rem;
    }

    .product-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 2rem;
      background: var(--card-bg);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: var(--shadow);
    }

    .product-table th,
    .product-table td {
      padding: 1rem;
      border-bottom: 1px solid var(--border);
      text-align: left;
      font-size: 15px;
    }

    .product-table th {
      background: var(--background);
    }

    .product-table td:last-child {
      white-space: nowrap;
    }

    .btn {
      padding: 0.4rem 0.8rem;
      border: none;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: 0.2s;
    }

    .btn-edit {
      background: #bee97a;
      color: #fff;
    }

    .btn-edit:hover {
      background: #a2c96a;
    }

    .btn-delete {
      background: #f87171;
      color: #fff;
    }

    .btn-delete:hover {
      background: #ef4444;
    }

    form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.5rem;
      background: var(--card-bg);
      padding: 2rem;
      border-radius: 12px;
      box-shadow: var(--shadow);
    }

    .form-group {
      display: flex;
      flex-direction: column;
    }

    .form-group.full {
      grid-column: span 2;
    }

    label {
      font-weight: 600;
      margin-bottom: 0.5rem;
    }

    input,
    textarea {
      padding: 0.75rem;
      border: 1px solid var(--border);
      border-radius: 8px;
      background: var(--background);
      font-size: 1rem;
    }

    textarea {
      resize: vertical;
      height: 80px;
    }

    button[type="submit"] {
      background: var(--primary-color);
      border: none;
      color: #fff;
      font-weight: 600;
      padding: 1rem;
      border-radius: 8px;
      grid-column: span 2;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s ease;
    }

    button[type="submit"]:hover {
      background: var(--primary-dark);
      color: #1a1a1a;
    }

    @media (max-width: 768px) {
      .sidebar {
        position: absolute;
        left: -260px;
        transition: left 0.3s ease;
      }

      .sidebar.active {
        left: 0;
      }

      .topbar {
        left: 0;
      }

      .main {
        margin-left: 0;
        padding: 100px 1rem 2rem;
      }

      form {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
      <div class="logo">
        <img src="assets/images/logo.png" alt="Logo">
      </div>
      <ul>
        <li>📊 Dashboard</li>
        <li>➕ Add Trader</li>
        <li class="active">📦 Products</li>
        <li>🔍 Details</li>
        <li>📋 Orders</li>
        <li>📈 Reports</li>
        <li>⚙️ Settings</li>
        <li>🚪 Logout</li>
      </ul>
    </aside>

    <!-- Topbar -->
    <header class="topbar">
      <button class="toggle-btn" id="toggleBtn">☰</button>
      <div class="topbar-right">
        <div class="topbar-icon">🔔</div>
        <div class="topbar-icon">🛒</div>
        <div class="avatar-circle">A</div>
        <div class="topbar-icon">▼</div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="main">
      <h2>Manage Products</h2>

      <table class="product-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price (£)</th>
            <th>Stock</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>101</td>
            <td>Organic Eggs</td>
            <td>2.99</td>
            <td>25</td>
            <td>
              <button class="btn btn-edit">Edit</button>
              <button class="btn btn-delete">Delete</button>
            </td>
          </tr>
          <tr>
            <td>102</td>
            <td>Fresh Milk</td>
            <td>1.50</td>
            <td>40</td>
            <td>
              <button class="btn btn-edit">Edit</button>
              <button class="btn btn-delete">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>

      <form id="productForm">
        <div class="form-group">
          <label for="name">Product Name</label>
          <input type="text" id="name" required>
        </div>
        <div class="form-group">
          <label for="price">Price (£)</label>
          <input type="number" id="price" step="0.01" required>
        </div>
        <div class="form-group">
          <label for="quantity">Quantity per item</label>
          <input type="text" id="quantity" required>
        </div>
        <div class="form-group">
          <label for="stock">Stock Available</label>
          <input type="number" id="stock" required>
        </div>
        <div class="form-group">
          <label for="minOrder">Minimum Order</label>
          <input type="number" id="minOrder" required>
        </div>
        <div class="form-group">
          <label for="maxOrder">Maximum Order</label>
          <input type="number" id="maxOrder" required>
        </div>
        <div class="form-group full">
          <label for="description">Description</label>
          <textarea id="description"></textarea>
        </div>
        <div class="form-group full">
          <label for="allergy">Allergy Information</label>
          <textarea id="allergy"></textarea>
        </div>
        <button type="submit">Save Product</button>
      </form>
    </main>
  </div>

  <script>
    document.getElementById('toggleBtn').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('active');
    });

    document.getElementById('productForm').addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Product saved successfully!');
    });
  </script>
</body>
</html>
