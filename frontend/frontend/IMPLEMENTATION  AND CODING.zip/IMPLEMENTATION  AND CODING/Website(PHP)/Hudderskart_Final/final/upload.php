<?php
// upload.php

// 1) Check for a POSTed file
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        isset($_FILES['image']) &&
        $_FILES['image']['error'] === UPLOAD_ERR_OK
    ) {
        // 2) Validate file type & size
        $allowed = ['image/jpeg','image/png','image/gif'];
        $maxSize = 2 * 1024 * 1024; // 2 MB

        $type = $_FILES['image']['type'];
        $size = $_FILES['image']['size'];
        $tmp  = $_FILES['image']['tmp_name'];

        if (!in_array($type, $allowed)) {
            $message = '❌ Only JPG, PNG or GIF allowed.';
        } elseif ($size > $maxSize) {
            $message = '❌ File too large (max 2 MB).';
        } else {
            // 3) Build a unique filename and move it
            $ext     = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $newName = uniqid('img_', true) . '.' . $ext;
            $dest    = __DIR__ . '/uploads/' . $newName;

            if (move_uploaded_file($tmp, $dest)) {
                $message = "✅ Uploaded successfully as $newName";
            } else {
                $message = '❌ Error moving file to uploads folder.';
            }
        }
    } else {
        $message = '❌ No file uploaded or upload error.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Upload an Image</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    form { margin-bottom: 1rem; }
    .message { margin-top: 1rem; }
  </style>
</head>
<body>
  <h1>Upload an Image</h1>
  <form method="POST" enctype="multipart/form-data">
    <label>
      Choose image (JPG/PNG/GIF, ≤2 MB):<br>
      <input type="file" name="image" required>
    </label><br><br>
    <button type="submit">Upload</button>
  </form>

  <?php if (!empty($message)): ?>
    <div class="message"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>
</body>
</html>
