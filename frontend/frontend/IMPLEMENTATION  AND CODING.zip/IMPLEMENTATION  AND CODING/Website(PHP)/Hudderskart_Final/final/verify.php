<?php
ob_start();
session_start();
include 'connect.php';   // ensures $conn via oci_connect()

// ─────────────────────────────────────────────────────
// 0) On first run, ensure the CUSTOMER table has an IS_VERIFIED column
// ─────────────────────────────────────────────────────
$ddl = <<<PLSQL
BEGIN
  EXECUTE IMMEDIATE '
    ALTER TABLE CUSTOMER
      ADD (IS_VERIFIED NUMBER(1) DEFAULT 0 NOT NULL)
  ';
EXCEPTION WHEN OTHERS THEN
  -- ORA-01430: column being added already exists
  IF SQLCODE != -1430 THEN RAISE; END IF;
END;
PLSQL;
oci_execute(oci_parse($conn, $ddl));

// ─────────────────────────────────────────────────────
// 1) Ensure we have an OTP and customer in session
// ─────────────────────────────────────────────────────
if (empty($_SESSION['otp']) || empty($_SESSION['customer_id'])) {
    header('Location: register.php');
    exit;
}

$error = '';

// ─────────────────────────────────────────────────────
// 2) Handle form submission
// ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputOtp = trim($_POST['otp'] ?? '');

    if ($inputOtp === (string)$_SESSION['otp']) {
        // ─────────────────────────────────────────────────
        // 3) Mark customer as verified
        // ─────────────────────────────────────────────────
        $sql = "
          UPDATE CUSTOMER
             SET IS_VERIFIED = 1
           WHERE CUSTOMER_ID = :id
        ";
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ':id', $_SESSION['customer_id']);

        if (oci_execute($stmt, OCI_COMMIT_ON_SUCCESS)) {
            // Clear OTP so code can't be reused
            unset($_SESSION['otp']);
            // Redirect to login
            header('Location: login.php');
            exit;
        } else {
            $e     = oci_error($stmt);
            $error = '❌ Database error: ' . htmlentities($e['message']);
        }
    } else {
        $error = '⚠️ Invalid verification code. Please try again.';
    }
}

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Verify Your Email – HuddersKart</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="./css/register.css">
</head>
<body>
  <?php include 'header.php'; ?>

  <main>
    <div class="container">
      <div class="signup-container">

        <!-- Header -->
        <div class="signup-header">
          <h1>Enter Verification Code</h1>
          <h2>We’ve sent a 6-digit code to <?= htmlspecialchars($_SESSION['customer_email']) ?></h2>
        </div>

        <!-- Error Message -->
        <?php if ($error): ?>
          <p class="error-msg"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <!-- OTP Form -->
        <form id="otp-form" method="POST" action="">
          <div class="form-group">
            <label for="otp">Verification Code</label>
            <input
              type="text"
              id="otp"
              name="otp"
              maxlength="6"
              pattern="\d{6}"
              required
              placeholder="123456"
            >
          </div>

          <button type="submit" class="submit-btn">VERIFY</button>
        </form>

        <p class="signin-link">
          Didn’t receive a code? <a href="register.php">Sign Up again</a>
        </p>
      </div>
    </div>
  </main>

  <?php include 'footer.php'; ?>
</body>
</html>
