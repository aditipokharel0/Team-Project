// Mobile menu toggle functionality
document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', function () {
        navLinks.classList.toggle('active');
    });

    // Category card click event
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function () {
            const category = this.getAttribute('data-category');
            alert(`You clicked on ${category} category. This would navigate to the ${category} page.`);
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-container input');
    searchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            alert(`Searching for: ${this.value}`);
            this.value = '';
        }
    });

    // Cart functionality
    const cartIcon = document.querySelector('.cart-icon');
    const cartSidebar = document.querySelector('.cart-sidebar');
    const cartOverlay = document.querySelector('.cart-overlay');
    const closeCart = document.querySelector('.close-cart');
    let cartCount = 0;

    function toggleCart() {
        cartSidebar.classList.toggle('active');
        cartOverlay.style.display = cartSidebar.classList.contains('active') ? 'block' : 'none';
    }

    cartIcon.addEventListener('click', toggleCart);
    closeCart.addEventListener('click', toggleCart);
    cartOverlay.addEventListener('click', toggleCart);

    // Function to update cart count (would be called when items are added)
    function updateCartCount(count) {
        cartCount += count;
        document.querySelector('.cart-count').textContent = cartCount;
    }

    // Dynamic window resize handling
    window.addEventListener('resize', function () {
        if (window.innerWidth > 768) {
            navLinks.classList.remove('active');
        }
    });
});


// Toggle mobile menu
document.querySelector('.menu-toggle').addEventListener('click', function () {
    document.getElementById('mainMenu').classList.toggle('active');
});

// Form validation
document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (email.trim() === '') {
        alert('Please enter your email');
        return;
    }

    if (password.trim() === '') {
        alert('Please enter your password');
        return;
    }

    // Here you would typically send the login data to your server
    console.log('Login attempt with:', { email, password });

    // For demo purposes, show success message
    alert('Login successful! Redirecting to dashboard...');
    // Redirect would happen here in a real application
});

// Show password toggle functionality
function addPasswordToggle() {
    const passwordField = document.getElementById('password');
    const toggleButton = document.createElement('button');
    toggleButton.type = 'button';
    toggleButton.textContent = 'Show';
    toggleButton.className = 'password-toggle';
    toggleButton.style.position = 'absolute';
    toggleButton.style.right = '20px';
    toggleButton.style.top = '50%';
    toggleButton.style.transform = 'translateY(-50%)';
    toggleButton.style.background = 'none';
    toggleButton.style.border = 'none';
    toggleButton.style.cursor = 'pointer';
    toggleButton.style.color = '#666';

    passwordField.parentElement.style.position = 'relative';
    passwordField.parentElement.appendChild(toggleButton);

    toggleButton.addEventListener('click', function () {
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleButton.textContent = 'Hide';
        } else {
            passwordField.type = 'password';
            toggleButton.textContent = 'Show';
        }
    });
}

// Initialize password toggle
window.addEventListener('DOMContentLoaded', function () {
    addPasswordToggle();
});

// Make cart count dynamic
let cartCount = 0;
const cartIcon = document.querySelector('.cart-icon');

function updateCartCount(count) {
    cartCount = count;
    cartIcon.textContent = cartCount;
}

// Example function to add item to cart
function addToCart() {
    updateCartCount(cartCount + 1);
}

// For demonstration purposes
document.addEventListener('keydown', function (e) {
    // Press 'c' key to simulate adding to cart
    if (e.key === 'c') {
        addToCart();
    }
});