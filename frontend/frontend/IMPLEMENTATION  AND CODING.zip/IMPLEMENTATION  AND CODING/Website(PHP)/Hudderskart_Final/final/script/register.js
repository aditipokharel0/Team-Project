
// Mobile Menu Toggle - FIXED SELECTOR
document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    // Category card click event
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function () {
            const category = this.getAttribute('data-category');
            alert(`You clicked on ${category} category. This would navigate to the ${category} page.`);
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-container input');
    searchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            alert(`Searching for: ${this.value}`);
            this.value = '';
        }
    });

    // Cart functionality
    const cartIcon = document.querySelector('.cart-icon');
    const cartSidebar = document.querySelector('.cart-sidebar');
    const cartOverlay = document.querySelector('.cart-overlay');
    const closeCart = document.querySelector('.close-cart');
    let cartCount = 0;

    if (cartIcon && cartSidebar && cartOverlay && closeCart) {
        function toggleCart() {
            cartSidebar.classList.toggle('active');
            cartOverlay.style.display = cartSidebar.classList.contains('active') ? 'block' : 'none';
        }

        cartIcon.addEventListener('click', toggleCart);
        closeCart.addEventListener('click', toggleCart);
        cartOverlay.addEventListener('click', toggleCart);
    }

    // Function to update cart count (would be called when items are added)
    function updateCartCount(count) {
        cartCount += count;
        document.querySelector('.cart-count').textContent = cartCount;
    }

    // Dynamic window resize handling
    window.addEventListener('resize', function () {
        if (window.innerWidth > 768) {
            navLinks.classList.remove('active');
        }
    });
});




document.addEventListener('DOMContentLoaded', function () {
    // Toggle between customer and trader
    const customerBtn = document.getElementById('customer-btn');
    const traderBtn = document.getElementById('trader-btn');

    customerBtn.addEventListener('click', function () {
        customerBtn.classList.add('active');
        traderBtn.classList.remove('active');
        document.querySelector('label[for="name"]').textContent = 'Name';
    });

    traderBtn.addEventListener('click', function () {
        traderBtn.classList.add('active');
        customerBtn.classList.remove('active');
        document.querySelector('label[for="name"]').textContent = 'Trader Name';
    });

    // Form validation
    const form = document.getElementById('signup-form');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm-password');

    const nameError = document.getElementById('name-error');
    const emailError = document.getElementById('email-error');
    const passwordError = document.getElementById('password-error');
    const confirmPasswordError = document.getElementById('confirm-password-error');

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        let isValid = true;

        // Reset errors
        resetErrors();

        // Validate name
        if (nameInput.value.trim() === '') {
            showError(nameInput, nameError, 'Name is required');
            isValid = false;
        }

        // Validate email
        if (emailInput.value.trim() === '') {
            showError(emailInput, emailError, 'Email is required');
            isValid = false;
        } else if (!isValidEmail(emailInput.value)) {
            showError(emailInput, emailError, 'Please enter a valid email address');
            isValid = false;
        }

        // Validate password
        if (passwordInput.value === '') {
            showError(passwordInput, passwordError, 'Password is required');
            isValid = false;
        } else if (passwordInput.value.length < 8) {
            showError(passwordInput, passwordError, 'Password must be at least 8 characters long');
            isValid = false;
        }

        // Validate confirm password
        if (confirmPasswordInput.value === '') {
            showError(confirmPasswordInput, confirmPasswordError, 'Please confirm your password');
            isValid = false;
        } else if (confirmPasswordInput.value !== passwordInput.value) {
            showError(confirmPasswordInput, confirmPasswordError, 'Passwords do not match');
            isValid = false;
        }

        if (isValid) {
            // Show success message
            alert('Registration successful!');
            form.reset();
        }
    });

    function showError(input, errorElement, message) {
        input.classList.add('error-input');
        errorElement.textContent = message;
    }

    function resetErrors() {
        const inputs = [nameInput, emailInput, passwordInput, confirmPasswordInput];
        const errors = [nameError, emailError, passwordError, confirmPasswordError];

        inputs.forEach(input => input.classList.remove('error-input'));
        errors.forEach(error => error.textContent = '');
    }

    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // Handle responsive navigation
    const handleResponsiveNav = () => {
        const screenWidth = window.innerWidth;
        const navElement = document.querySelector('nav ul');

        if (screenWidth <= 768) {
            navElement.style.flexWrap = 'wrap';
        } else {
            navElement.style.flexWrap = 'nowrap';
        }
    };

    // Call on page load and resize
    handleResponsiveNav();
    window.addEventListener('resize', handleResponsiveNav);
});