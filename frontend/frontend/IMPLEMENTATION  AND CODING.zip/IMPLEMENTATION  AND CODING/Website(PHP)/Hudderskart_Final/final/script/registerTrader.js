// registerTrader.js - Trader-only registration script

document.addEventListener('DOMContentLoaded', () => {
  // ===== Mobile Menu Toggle =====
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks   = document.querySelector('.nav-links');
  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  }

  // ===== Search on Enter =====
  const searchInput = document.querySelector('.search-container input');
  if (searchInput) {
    searchInput.addEventListener('keypress', e => {
      if (e.key === 'Enter') {
        alert(`Searching for: ${searchInput.value}`);
        searchInput.value = '';
      }
    });
  }

  // ===== Cart Sidebar Toggle =====
  const cartIcon    = document.querySelector('.cart-icon');
  const cartSidebar = document.querySelector('.cart-sidebar');
  const cartOverlay = document.querySelector('.cart-overlay');
  const closeCart   = document.querySelector('.close-cart');
  if (cartIcon && cartSidebar && cartOverlay && closeCart) {
    function toggleCart() {
      cartSidebar.classList.toggle('active');
      cartOverlay.style.display = cartSidebar.classList.contains('active') ? 'block' : 'none';
    }
    cartIcon.addEventListener('click', toggleCart);
    closeCart.addEventListener('click', toggleCart);
    cartOverlay.addEventListener('click', toggleCart);
  }

  // ===== Form Validation =====
  const form = document.getElementById('signup-form');
  if (form) {
    form.addEventListener('submit', e => {
      const pwd = document.getElementById('password').value;
      const confirmPwd = document.getElementById('confirm-password').value;
      const name = document.getElementById('name').value;
      
      // Validate name has at least first and last name
      if (name.trim().split(' ').length < 2) {
        alert('Please enter your full name (first and last name)');
        e.preventDefault();
        return;
      }
      
      // Validate password length
      if (pwd.length < 8) {
        alert('Password must be at least 8 characters long.');
        e.preventDefault();
        return;
      }
      
      // Validate password match
      if (pwd !== confirmPwd) {
        alert('Passwords do not match.');
        e.preventDefault();
        return;
      }
    });
  }

  // ===== Responsive Nav FlexWrap =====
  function handleResponsiveNav() {
    const navElem = document.querySelector('nav ul');
    if (!navElem) return;
    if (window.innerWidth <= 768) {
      navElem.style.flexWrap = 'wrap';
    } else {
      navElem.style.flexWrap = 'nowrap';
    }
  }
  handleResponsiveNav();
  window.addEventListener('resize', handleResponsiveNav);
});