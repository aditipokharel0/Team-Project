// shop.js - Shop Management Script

document.addEventListener('DOMContentLoaded', function() {
    // Delete Shop Confirmation Modal
    const deleteModal = document.getElementById('deleteModal');
    const shopNameSpan = document.getElementById('shopNameToDelete');
    const confirmDeleteBtn = document.getElementById('confirmDelete');
    const cancelDeleteBtn = document.getElementById('cancelDelete');
    let shopToDelete = null;

    // Set up delete buttons
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            shopToDelete = this.dataset.id;
            shopNameSpan.textContent = this.dataset.name;
            deleteModal.style.display = 'block';
        });
    });

    // Confirm delete
    confirmDeleteBtn.addEventListener('click', function() {
        if (shopToDelete) {
            window.location.href = `shop.php?action=delete&id=${shopToDelete}`;
        }
    });

    // Cancel delete
    cancelDeleteBtn.addEventListener('click', function() {
        deleteModal.style.display = 'none';
        shopToDelete = null;
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target === deleteModal) {
            deleteModal.style.display = 'none';
            shopToDelete = null;
        }
    });

    // Form validation
    const shopForm = document.getElementById('shopForm');
    if (shopForm) {
        shopForm.addEventListener('submit', function(e) {
            const shopName = document.getElementById('shop_name').value.trim();
            if (!shopName) {
                e.preventDefault();
                alert('Shop name is required');
                return false;
            }
            return true;
        });
    }

    // Responsive table
    function handleResponsiveTable() {
        const table = document.querySelector('table');
        if (!table) return;
        
        if (window.innerWidth <= 768) {
            table.classList.add('responsive');
        } else {
            table.classList.remove('responsive');
        }
    }
    
    handleResponsiveTable();
    window.addEventListener('resize', handleResponsiveTable);
});