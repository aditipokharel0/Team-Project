// Mobile Menu Toggle - FIXED SELECTOR
document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    // Category card click event
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function () {
            const category = this.getAttribute('data-category');
            alert(`You clicked on ${category} category. This would navigate to the ${category} page.`);
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-container input');
    searchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            alert(`Searching for: ${this.value}`);
            this.value = '';
        }
    });

    // Cart functionality
    const cartIcon = document.querySelector('.cart-icon');
    const cartSidebar = document.querySelector('.cart-sidebar');
    const cartOverlay = document.querySelector('.cart-overlay');
    const closeCart = document.querySelector('.close-cart');
    let cartCount = 0;

    if (cartIcon && cartSidebar && cartOverlay && closeCart) {
        function toggleCart() {
            cartSidebar.classList.toggle('active');
            cartOverlay.style.display = cartSidebar.classList.contains('active') ? 'block' : 'none';
        }

        cartIcon.addEventListener('click', toggleCart);
        closeCart.addEventListener('click', toggleCart);
        cartOverlay.addEventListener('click', toggleCart);
    }

    // Function to update cart count (would be called when items are added)
    function updateCartCount(count) {
        cartCount += count;
        document.querySelector('.cart-count').textContent = cartCount;
    }

    // Dynamic window resize handling
    window.addEventListener('resize', function () {
        if (window.innerWidth > 768) {
            navLinks.classList.remove('active');
        }
    });
});



// Sample data for demonstration
const userData = {
    name: "Lorem Ips",
    email: "XYZ@gmail.com",
    contact: "015559934",
    bio: "Welcome to my profile! This is where I can share information about myself and my interests."
};

// Function to populate user data
function populateUserData() {
    // Display bio
    document.getElementById('bio-section').textContent = userData.bio;
}

// Simple cart functionality
let cartItems = 0;

function updateCart() {
    document.getElementById('cart-count').textContent = cartItems;
}

// Photo upload functionality
const modal = document.getElementById('upload-modal');
const avatarContainer = document.getElementById('avatar-container');
const fileInput = document.getElementById('file-upload');
const triggerFileSelect = document.getElementById('trigger-file-select');
const previewImage = document.getElementById('preview-image');
const confirmUpload = document.getElementById('confirm-upload');
const closeModalBtn = document.querySelector('.close-modal');
const avatarImage = document.getElementById('avatar-image');
const notification = document.getElementById('notification');

// Open modal when avatar is clicked
avatarContainer.addEventListener('click', function () {
    modal.style.display = 'block';
});

// Close modal when X is clicked
closeModalBtn.addEventListener('click', function () {
    modal.style.display = 'none';
});

// Close modal when clicking outside
window.addEventListener('click', function (event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
});

// Trigger file input when button is clicked
triggerFileSelect.addEventListener('click', function () {
    fileInput.click();
});

// Show preview when file is selected
fileInput.addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();

        reader.onload = function (e) {
            previewImage.src = e.target.result;
            previewImage.style.display = 'block';
            confirmUpload.style.display = 'inline-block';
        }

        reader.readAsDataURL(file);
    }
});

// Confirm photo upload
confirmUpload.addEventListener('click', function () {
    // Update avatar with new image
    avatarImage.src = previewImage.src;

    // Close modal
    modal.style.display = 'none';

    // Show success notification
    showNotification('Profile photo updated successfully!');
});

// Show notification function
function showNotification(message) {
    notification.textContent = message;
    notification.style.display = 'block';

    // Hide after 3 seconds
    setTimeout(function () {
        notification.style.display = 'none';
    }, 3000);
}

// Initialize page
document.addEventListener('DOMContentLoaded', function () {
    populateUserData();
    updateCart();
});

// Responsive menu toggle (for smaller screens)
function toggleMenu() {
    const nav = document.querySelector('.nav-menu');
    nav.classList.toggle('active');
}