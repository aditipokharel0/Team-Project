
// Mobile menu toggle functionality
document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    menuToggle.addEventListener('click', function () {
        navLinks.classList.toggle('active');
    });

    // Category card click event
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function () {
            const category = this.getAttribute('data-category');
            alert(`You clicked on ${category} category. This would navigate to the ${category} page.`);
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-container input');
    searchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            alert(`Searching for: ${this.value}`);
            this.value = '';
        }
    });

    // Cart functionality
    const cartIcon = document.querySelector('.cart-icon');
    const cartSidebar = document.querySelector('.cart-sidebar');
    const cartOverlay = document.querySelector('.cart-overlay');
    const closeCart = document.querySelector('.close-cart');
    let cartCount = 0;
    let cartItems = [];

    function toggleCart() {
        cartSidebar.classList.toggle('active');
        cartOverlay.style.display = cartSidebar.classList.contains('active') ? 'block' : 'none';
    }

    if (cartIcon) cartIcon.addEventListener('click', toggleCart);
    if (closeCart) closeCart.addEventListener('click', toggleCart);
    if (cartOverlay) cartOverlay.addEventListener('click', toggleCart);

    // Function to update cart count
    function updateCartCount(count) {
        cartCount += count;
        const cartCountElement = document.querySelector('.cart-count');
        if (cartCountElement) {
            cartCountElement.textContent = cartCount;
        }
    }

    // Function to add item to cart
    function addToCart(productName, price) {
        // Get existing cart items from localStorage
        let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

        // Create new cart item
        const newItem = {
            id: Date.now(), // Unique ID
            name: productName,
            price: price,
            quantity: 1
        };

        // Add to cart items array
        cartItems.push(newItem);

        // Save to localStorage
        localStorage.setItem('cartItems', JSON.stringify(cartItems));

        // Update cart count
        updateCartCount(1);

        // Update cart sidebar
        updateCartSidebar();

        // Show success message
        alert(`${productName} added to cart!`);
    }

    // Function to update cart sidebar
    function updateCartSidebar() {
        const cartItemsContainer = document.querySelector('.cart-items');
        let total = 0;

        // Clear existing items
        cartItemsContainer.innerHTML = '';

        if (cartItems.length === 0) {
            cartItemsContainer.innerHTML = '<div class="empty-cart" style="text-align: center; padding: 20px; color: #666; font-style: italic;">Your cart is empty</div>';
            return;
        }

        // Add each item to the sidebar
        cartItems.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                        <div class="cart-item-details">
                            <h3>${item.name}</h3>
                            <p>$${item.price} x ${item.quantity}</p>
                            <button class="remove-btn" onclick="removeFromCart(${item.id})">Remove</button>
                        </div>
                    `;
            cartItemsContainer.appendChild(itemElement);
            total += item.price * item.quantity;
        });

        // Update total
        const totalElement = document.querySelector('.cart-total');
        if (totalElement) {
            totalElement.textContent = `Total: $${total.toFixed(2)}`;
        }
    }

    // Function to remove item from cart
    window.removeFromCart = function (itemId) {
        const index = cartItems.findIndex(item => item.id === itemId);
        if (index !== -1) {
            cartItems.splice(index, 1);
            updateCartCount(-1);
            updateCartSidebar();
        }
    }

    // Update product buttons to pass product info
    document.querySelectorAll('.add-to-cart').forEach(button => {
        const productCard = button.closest('.product-card');
        const productName = productCard.querySelector('.product-name').textContent;
        const productPrice = parseFloat(productCard.querySelector('.product-price').textContent.replace('$', ''));

        button.onclick = () => addToCart(productName, productPrice);
    });

    // Dynamic window resize handling
    window.addEventListener('resize', function () {
        if (window.innerWidth > 768) {
            navLinks.classList.remove('active');
        }
    });
});

//carousel

document.addEventListener('DOMContentLoaded', function () {
    const slides = document.querySelectorAll('.slide');
    const indicators = document.querySelectorAll('.indicator');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    let currentSlide = 0;
    let slideInterval;

    // Function to show a specific slide
    function showSlide(index) {
        // Hide all slides
        slides.forEach(slide => {
            slide.classList.remove('active');
        });

        // Hide all active indicators
        indicators.forEach(indicator => {
            indicator.classList.remove('active');
        });

        // Show the current slide
        slides[index].classList.add('active');
        indicators[index].classList.add('active');
        currentSlide = index;
    }

    // Function to show next slide
    function nextSlide() {
        let next = currentSlide + 1;
        if (next >= slides.length) {
            next = 0;
        }
        showSlide(next);
    }

    // Function to show previous slide
    function prevSlide() {
        let prev = currentSlide - 1;
        if (prev < 0) {
            prev = slides.length - 1;
        }
        showSlide(prev);
    }

    // Set up event listeners
    nextBtn.addEventListener('click', function () {
        nextSlide();
        resetInterval();
    });

    prevBtn.addEventListener('click', function () {
        prevSlide();
        resetInterval();
    });

    // Set up indicators
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', function () {
            showSlide(index);
            resetInterval();
        });
    });

    // Auto-rotate slides
    function startInterval() {
        slideInterval = setInterval(nextSlide, 5000); // Change slide every 5 seconds
    }

    function resetInterval() {
        clearInterval(slideInterval);
        startInterval();
    }

    // Initialize carousel
    showSlide(0);
    startInterval();

    // Touch swipe functionality for mobile
    let touchStartX = 0;
    let touchEndX = 0;

    const carousel = document.querySelector('.carousel');

    carousel.addEventListener('touchstart', function (e) {
        touchStartX = e.changedTouches[0].screenX;
    }, false);

    carousel.addEventListener('touchend', function (e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, false);

    function handleSwipe() {
        if (touchEndX < touchStartX - 50) {
            // Swipe left
            nextSlide();
            resetInterval();
        } else if (touchEndX > touchStartX + 50) {
            // Swipe right
            prevSlide();
            resetInterval();
        }
    }

    // Pause auto-rotation when hovering
    carousel.addEventListener('mouseenter', function () {
        clearInterval(slideInterval);
    });

    carousel.addEventListener('mouseleave', function () {
        startInterval();
    });
});

// ... existing code ...

document.addEventListener('DOMContentLoaded', function () {
    // Cart functionality
    const cartIcon = document.querySelector('.cart-icon');
    const cartSidebar = document.querySelector('.cart-sidebar');
    const cartOverlay = document.querySelector('.cart-overlay');
    const closeCart = document.querySelector('.close-cart');
    let cartCount = 0;
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

    // Initialize cart count
    updateCartCount(0);

    function toggleCart() {
        cartSidebar.classList.toggle('active');
        cartOverlay.style.display = cartSidebar.classList.contains('active') ? 'block' : 'none';
    }

    if (cartIcon) cartIcon.addEventListener('click', toggleCart);
    if (closeCart) closeCart.addEventListener('click', toggleCart);
    if (cartOverlay) cartOverlay.addEventListener('click', toggleCart);

    // Function to update cart count
    function updateCartCount(count) {
        cartCount = cartItems.length;
        const cartCountElement = document.querySelector('.cart-count');
        if (cartCountElement) {
            cartCountElement.textContent = cartCount;
        }
    }

    // Function to add item to cart
    function addToCart(productName, price) {
        // Create new cart item
        const newItem = {
            id: Date.now(), // Unique ID
            name: productName,
            price: price,
            quantity: 1
        };

        // Add to cart items array
        cartItems.push(newItem);

        // Save to localStorage
        localStorage.setItem('cartItems', JSON.stringify(cartItems));

        // Update cart count
        updateCartCount(1);

        // Update cart sidebar
        updateCartSidebar();

        // Show success message
        alert(`${productName} added to cart!`);
    }

    // Function to update cart sidebar
    function updateCartSidebar() {
        const cartItemsContainer = document.querySelector('.cart-items');
        let total = 0;

        // Clear existing items
        cartItemsContainer.innerHTML = '';

        if (cartItems.length === 0) {
            cartItemsContainer.innerHTML = '<div class="empty-cart" style="text-align: center; padding: 20px; color: #666; font-style: italic;">Your cart is empty</div>';
            return;
        }

        // Add each item to the sidebar
        cartItems.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                        <div class="cart-item-details">
                            <h3>${item.name}</h3>
                            <p>$${item.price} x ${item.quantity}</p>
                            <button class="remove-btn" onclick="removeFromCart(${item.id})">Remove</button>
                        </div>
                    `;
            cartItemsContainer.appendChild(itemElement);
            total += item.price * item.quantity;
        });

        // Update total
        const totalElement = document.querySelector('.cart-total');
        if (totalElement) {
            totalElement.textContent = `Total: $${total.toFixed(2)}`;
        }
    }

    // Function to remove item from cart
    window.removeFromCart = function (itemId) {
        cartItems = cartItems.filter(item => item.id !== itemId);
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartCount(-1);
        updateCartSidebar();
    }

    // Update product buttons to pass product info
    document.querySelectorAll('.add-to-cart').forEach(button => {
        const productCard = button.closest('.product-card');
        const productName = productCard.querySelector('.product-name').textContent;
        const productPrice = parseFloat(productCard.querySelector('.product-price').textContent.replace('$', ''));

        button.onclick = () => addToCart(productName, productPrice);
    });

    // Initialize cart sidebar
    updateCartSidebar();
});
