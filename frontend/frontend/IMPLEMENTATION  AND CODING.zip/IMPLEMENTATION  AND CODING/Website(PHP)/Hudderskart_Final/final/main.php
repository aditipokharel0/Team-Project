<?php
session_start();
require_once 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <!-- Carousel Implementation -->
        <div class="carousel">
            <div class="carousel-inner">
                <!-- Slide 1 -->
                <div class="slide active">
                    <img src="./images/456.png" alt="Fresh groceries" class="slide-img">
                    <div class="slide-overlay">
                        <h2>Fresh Groceries Delivered to Your Door</h2>
                        <p>Shop from our wide range of fresh fruits, vegetables, meat and more at the best prices.</p>
                        <button class="slide-btn">Shop Now</button>
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="slide">
                    <img src="./images/789.avif" alt="Local Products" class="slide-img">
                    <div class="slide-overlay">
                        <h2>Support Local Producers</h2>
                        <p>Every purchase helps local farmers and small businesses in your community.</p>
                        <button class="slide-btn">Explore Local</button>
                    </div>
                </div>

                <!-- Slide 3 -->
                <div class="slide">
                    <img src="./images/organic.avif" alt="Organic Selection" class="slide-img">
                    <div class="slide-overlay">
                        <h2>Organic & Sustainable Choices</h2>
                        <p>Discover our range of environmentally friendly and organic products.</p>
                        <button class="slide-btn">Go Organic</button>
                    </div>
                </div>
            </div>

            <!-- Carousel Controls -->
            <div class="carousel-control prev">
                <i class="fas fa-chevron-left"></i>
            </div>
            <div class="carousel-control next">
                <i class="fas fa-chevron-right"></i>
            </div>

            <!-- Carousel Indicators -->
            <div class="carousel-indicators">
                <div class="indicator active" data-slide="0"></div>
                <div class="indicator" data-slide="1"></div>
                <div class="indicator" data-slide="2"></div>
            </div>
        </div>
    </div>

    <!-- Categories Section -->
    <section>
        <div class="section-header">
            <h2>Categories</h2>
            <p>Our grocery store provides a complete selection of fresh produce, meats, dairy, bakery items, pantry
                staples, snacks, beverages, and frozen foods. We also offer household essentials, personal care items,
                baby and pet supplies, health products, and a variety of international foods to meet all your daily
                needs.</p>
            <a href="#" class="shop-all-btn">Shop All</a>
        </div>

        <div class="categories-grid">
            <div class="category-card">
                <img src="./images/789.avif" alt="Food category" class="category-img">
                <div class="category-name">Food</div>
            </div>
            <!-- <div class="category-card">
                    <img src="./images/meat.jpg" alt="Meat category" class="category-img">
                    <div class="category-name">Meat</div>
                </div> -->

            <div class="category-card" onclick="window.location.href='butcher.php';" style="cursor: pointer;">
                <img src="./images/meat.jpg" alt="Meat category" class="category-img">
                <div class="category-name">Meat</div>
            </div>

            <div class="category-card">
                <img src="./images/liquor.jpg" alt="Liquor category" class="category-img">
                <div class="category-name">Liquor</div>
            </div>
        </div>
    </section>

    <!-- Fresh Products Section -->
    <section>
        <div class="section-header">
            <h2>Our Fresh Products</h2>
            <p>A wide variety of farm-fresh fruits and vegetables, carefully selected for quality and freshness.
                Includes seasonal, organic, and locally-sourced options to keep your meals healthy and flavorful.</p>
            <a href="#" class="shop-all-btn">Shop All</a>
        </div>

        <div class="fresh-products">
            <div class="fresh-product">
                <img src="./images/veg.avif" alt="Fresh vegetables" class="fresh-product-img">
            </div>
            <div class="fresh-product">
                <img src="./images/fruit.avif" alt="Fresh fruits" class="fresh-product-img">
            </div>
            <div class="fresh-product">
                <img src="./images/dairy.avif" alt="Fresh dairy" class="fresh-product-img">
            </div>
        </div>
    </section>

    <!-- Products Section -->
    <section>
        <div class="section-header">
            <h2>Our Products</h2>
            <p>A premium selection of organic vegetables, ethically-sourced organic meats, and freshly baked organic
                bread—grown and prepared without synthetic chemicals, ensuring pure, natural goodness in every bite.</p>
            <a href="#" class="shop-all-btn">Products Details</a>
        </div>

        <div class="products-grid">
            <?php
            // Function to handle BLOB to base64 conversion
            function getImageData($blob) {
                if (!$blob) {
                    return '';
                }
                // Check if blob is already a string
                if (is_string($blob)) {
                    return base64_encode($blob);
                }
                // Handle OCI-Lob object
                if (is_object($blob)) {
                    return base64_encode($blob->load());
                }
                return '';
            }

            // Fetch products including images
            $sql = "SELECT p.Product_ID, p.Product_Name, p.Price, p.Stock, p.Product_Image, pc.Category_Name 
                    FROM PRODUCT p 
                    LEFT JOIN PRODUCT_CATEGORY pc ON p.fk3_Category_ID = pc.Category_ID 
                    WHERE p.Stock > 0 
                    AND ROWNUM <= 20
                    ORDER BY p.Date_Added DESC";

            $stmt = oci_parse($conn, $sql);
            if (!oci_execute($stmt)) {
                $e = oci_error($stmt);
                die("Query failed: " . $e['message']);
            }

            while ($row = oci_fetch_array($stmt, OCI_ASSOC + OCI_RETURN_LOBS)) {
                 $imageData = isset($row['PRODUCT_IMAGE']) ? getImageData($row['PRODUCT_IMAGE']) : '';
                ?>
                <div class="product-card">
                    <?php if ($imageData) { ?>
                        <img src="data:image/jpeg;base64,<?php echo $imageData; ?>" 
                             alt="<?php echo htmlspecialchars($row['PRODUCT_NAME']); ?>" 
                             class="product-img">
                    <?php } else { ?>
                        <img src="./images/default-product.jpg" 
                             alt="<?php echo htmlspecialchars($row['PRODUCT_NAME']); ?>" 
                             class="product-img">
                    <?php } ?>
                    <div class="product-info">
                        <div class="product-name"><?php echo htmlspecialchars($row['PRODUCT_NAME']); ?></div>
                        <div class="product-price">£<?php echo number_format($row['PRICE'], 2); ?></div>
                        <div class="product-stock">In Stock: <?php echo $row['STOCK']; ?></div>
                        <button class="add-to-cart" 
                                data-product-id="<?php echo $row['PRODUCT_ID']; ?>"
                                onclick="addToCart(<?php echo $row['PRODUCT_ID']; ?>)">
                            Add to Cart
                        </button>
                    </div>
                </div>
                <?php
            }
            oci_free_statement($stmt);
            ?>
        </div>
    </section>
    </main>

    <script>
        function addToCart(productId) {
        // Disable button to prevent double clicks
        const buttons = document.querySelectorAll('.add-to-cart');
        buttons.forEach(btn => btn.disabled = true);

        fetch('add_to_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'product_id=' + encodeURIComponent(productId),
            credentials: 'same-origin'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                alert('Product added to cart successfully!');
            } else {
                if (data.message === 'Please login first') {
                    window.location.href = 'login.php';
                } else {
                    throw new Error(data.message || 'Failed to add product to cart');
                }
            }
        })
        .catch(error => {
            console.error('Error details:', error);
            alert('Error adding product to cart: ' + error.message);
        })
        .finally(() => {
            // Re-enable buttons
            buttons.forEach(btn => btn.disabled = false);
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = this.getAttribute('data-product-id');
                if (productId) {
                    addToCart(productId);
                }
            });
        });
    });
    </script>
    </body>
    </html>