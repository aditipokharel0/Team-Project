<?php
ini_set('display_errors', 0); // Hide errors from output
error_reporting(0);
header('Content-Type: application/json');
session_start();
require_once 'connect.php';

try {
    // Validate input
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || !isset($_SESSION['customer_id'])) {
        throw new Exception('Invalid request data');
    }

    $customer_id = $_SESSION['customer_id'];
    $total = $data['total'] ?? 0;
    $items = $data['items'] ?? [];

    if (empty($items)) {
        throw new Exception('No items in cart');
    }

    // Get customer's cart ID
    $sql = "SELECT Cart_ID FROM CART WHERE fk1_Customer_ID = :customer_id";
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ':customer_id', $customer_id);
    oci_execute($stmt);
    $cart = oci_fetch_assoc($stmt);
    $cart_id = $cart['CART_ID'];

    // Get default slot ID (you might want to let user choose this)
    $sql = "SELECT MIN(Slot_ID) as slot_id FROM COLLECTION_SLOT";
    $stmt = oci_parse($conn, $sql);
    oci_execute($stmt);
    $slot = oci_fetch_assoc($stmt);
    $slot_id = $slot['SLOT_ID'];
    if (!$slot_id) {
        throw new Exception('No collection slot available. Please contact support.');
    }

    // 1. Insert payment
    $sql1 = "INSERT INTO PAYMENT (Payment_ID, Amount, Payment_Method, Payment_Date, fk1_Customer_ID)
            VALUES (seq_payment.NEXTVAL, :amount, 'PayPal', SYSDATE, :customer_id)
            RETURNING Payment_ID INTO :payment_id";
    $stmt1 = oci_parse($conn, $sql1);
    oci_bind_by_name($stmt1, ':amount', $total);
    oci_bind_by_name($stmt1, ':customer_id', $customer_id);
    oci_bind_by_name($stmt1, ':payment_id', $payment_id, 32);
    if (!oci_execute($stmt1)) {
        $e = oci_error($stmt1);
        throw new Exception($e['message']);
    }

    // 2. Insert order with coupon_id as NULL using a bind variable
    $sql2 = "INSERT INTO ORDER1 (
                Order_ID, Order_Date, Total_Amount, Quantity, 
                fk1_Customer_ID, fk2_Payment_ID, fk3_Cart_ID, 
                fk4_Slot_ID, fk5_Coupon_ID
            ) VALUES (
                seq_order1.NEXTVAL, SYSDATE, :total, :quantity, 
                :customer_id, :payment_id, :cart_id, 
                :slot_id, :coupon_id
            ) RETURNING Order_ID INTO :order_id";

    $quantity = array_sum(array_column($items, 'quantity'));
    $coupon_id = null; // explicitly set to null

    $stmt2 = oci_parse($conn, $sql2);
    oci_bind_by_name($stmt2, ':total', $total);
    oci_bind_by_name($stmt2, ':quantity', $quantity);
    oci_bind_by_name($stmt2, ':customer_id', $customer_id);
    oci_bind_by_name($stmt2, ':payment_id', $payment_id);
    oci_bind_by_name($stmt2, ':cart_id', $cart_id);
    oci_bind_by_name($stmt2, ':slot_id', $slot_id);
    oci_bind_by_name($stmt2, ':coupon_id', $coupon_id);
    oci_bind_by_name($stmt2, ':order_id', $order_id, 32);

    if (!oci_execute($stmt2)) {
        $e = oci_error($stmt2);
        throw new Exception($e['message']);
    }

    // 3. Insert order products
    foreach ($items as $item) {
        $sql3 = "INSERT INTO ORDER_PRODUCT (Order_Product_ID, fk1_Order_ID, fk2_Product_ID)
                VALUES (seq_order_product.NEXTVAL, :order_id, :product_id)";
        $stmt3 = oci_parse($conn, $sql3);
        oci_bind_by_name($stmt3, ':order_id', $order_id);
        oci_bind_by_name($stmt3, ':product_id', $item['product_id']);
        if (!oci_execute($stmt3)) {
            $e = oci_error($stmt3);
            throw new Exception($e['message']);
        }
    }

    // 4. Clear cart (delete from CART_PRODUCT for this customer)
    $sql4 = "DELETE FROM CART_PRODUCT WHERE fk1_Cart_ID = (SELECT Cart_ID FROM CART WHERE fk1_Customer_ID = :customer_id)";
    $stmt4 = oci_parse($conn, $sql4);
    oci_bind_by_name($stmt4, ':customer_id', $customer_id);
    if (!oci_execute($stmt4)) {
        $e = oci_error($stmt4);
        throw new Exception($e['message']);
    }

    // Commit the transaction
    oci_commit($conn);

    echo json_encode(['success' => true, 'order_id' => $order_id]);
} catch (Exception $e) {
    oci_rollback($conn);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

// No closing PHP tag to prevent whitespace