<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['customer_id']) || !isset($_POST['cart_product_id'])) {
    echo json_encode(['success' => false]);
    exit;
}

$sql = "DELETE FROM CART_PRODUCT 
        WHERE Cart_Product_ID = :cart_product_id
        AND fk1_Cart_ID IN (SELECT Cart_ID FROM CART WHERE fk1_Customer_ID = :customer_id)";

$stmt = oci_parse($conn, $sql);
oci_bind_by_name($stmt, ":cart_product_id", $_POST['cart_product_id']);
oci_bind_by_name($stmt, ":customer_id", $_SESSION['customer_id']);

if (oci_execute($stmt)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}

oci_free_statement($stmt);
oci_close($conn);
?>