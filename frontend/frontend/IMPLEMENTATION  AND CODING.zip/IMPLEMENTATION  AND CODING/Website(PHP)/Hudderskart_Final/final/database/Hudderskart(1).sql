-- Drop tables --
DROP TABLE DISCOUNT_PRODUCT;
DROP TABLE ORDER_PRODUCT;
DROP TABLE ORDER1;
DROP TABLE PAYMENT;
DROP TABLE WISHLIST_PRODUCT;
DROP TABLE REVIEW;
DROP TABLE CART_PRODUCT;
DROP TABLE PRODUCT;
DROP TABLE CART;
DROP TABLE WISHLIST;
DROP TABLE SHOP;
DROP TABLE COUPON;
DROP TABLE COLLECTION_SLOT;
DROP TABLE DISCOUNT;
DROP TABLE PRODUCT_CATEGORY;
DROP TABLE CUSTOMER;
DROP TABLE TRADER;
DROP TABLE ADMIN_USERS;









CREATE TABLE CUSTOMER (
   Customer_ID    INTEGER     NOT NULL,
  FullName   VARCHAR2(50),
  Date_Created DATE DEFAULT SYSDATE,
  Email       VARCHAR2(50) UNIQUE,
  Password    VARCHAR2(64) NOT NULL,
  UserName    VARCHAR2(20),
  CONSTRAINT pk_customer PRIMARY KEY (Customer_ID)
);


CREATE TABLE TRADER (
  Trader_ID    INTEGER     NOT NULL,
  FirstName   VARCHAR2(20),
  LastName    VARCHAR2(8),
  Date_Created DATE,
  Email       VARCHAR2(50) UNIQUE,
  Address     VARCHAR2(30),
  Password    VARCHAR2(64) NOT NULL,
  Phone_no    INTEGER,
  UserName    VARCHAR2(20),
  CONSTRAINT pk_trader PRIMARY KEY (Trader_ID)
);

CREATE TABLE ADMIN_USERS  (
  Admin_ID     INTEGER     NOT NULL,
  FirstName    VARCHAR2(20),
  LastName     VARCHAR2(8),
  Date_Created DATE,
  Email        VARCHAR2(50) UNIQUE,
  Address      VARCHAR2(30),
  Password     VARCHAR2(64) NOT NULL,
  Phone_no     INTEGER,
  UserName     VARCHAR2(20),
  CONSTRAINT pk_admin_users PRIMARY KEY (Admin_ID)
);





-- Create a Database table to represent the "PRODUCT_CATEGORY" entity.
CREATE TABLE PRODUCT_CATEGORY(
	Category_ID	INTEGER NOT NULL,
	Category_Name	VARCHAR(20),
	Catagory_Description	VARCHAR(300),
	-- Specify the PRIMARY KEY constraint for table "PRODUCT_CATEGORY".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_PRODUCT_CATEGORY PRIMARY KEY (Category_ID)
);

-- Create a Database table to represent the "DISCOUNT" entity.
CREATE TABLE DISCOUNT(
	Discount_ID	INTEGER NOT NULL,
	Percentage	NUMERIC(8,2),
	Expiry_Date	DATE,
	Amount	INTEGER,
	Start_Date	DATE,
	-- Specify the PRIMARY KEY constraint for table "DISCOUNT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_DISCOUNT PRIMARY KEY (Discount_ID)
);

-- Create a Database table to represent the "COLLECTION_SLOT" entity.
CREATE TABLE COLLECTION_SLOT(
	Slot_ID	INTEGER NOT NULL,
	Slot_Name	VARCHAR(50),
	Slot_Time	DATE,
	Slot_Capacity	INTEGER,
	-- Specify the PRIMARY KEY constraint for table "COLLECTION_SLOT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_COLLECTION_SLOT PRIMARY KEY (Slot_ID)
);


-- Create a Database table to represent the "COUPON" entity.
CREATE TABLE COUPON(
	Coupon_ID	INTEGER NOT NULL,
	Code	INTEGER,
	Discount_Percentage	INTEGER,
	Expiry_Date	DATE,
	Usage_Limit	INTEGER,
	-- Specify the PRIMARY KEY constraint for table "COUPON".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_COUPON PRIMARY KEY (Coupon_ID)
);




-- Create a Database table to represent the "SHOP" entity.
CREATE TABLE SHOP(
	Shop_ID	INTEGER NOT NULL,
	Shop_Name	VARCHAR(50),
	Shop_Description	VARCHAR(300),
	fk1_Trader_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "SHOP".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_SHOP PRIMARY KEY (Shop_ID),
    CONSTRAINT fk1_SHOP_to_TRADER FOREIGN KEY(fk1_Trader_ID) REFERENCES TRADER(Trader_ID)
);

/*
-- Create a Database table to represent the "REPORT" entity.
CREATE TABLE REPORT(
	Report_ID	INTEGER NOT NULL,
	Title	VARCHAR(50),
	Content	VARCHAR(50),
	Created_At	DATE,
	fk1_User_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "REPORT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_REPORT PRIMARY KEY (Report_ID),
    CONSTRAINT fk1_REPORT_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID)
);*/


-- Create a Database table to represent the "WISHLIST" entity.
CREATE TABLE WISHLIST(
	Wishlist_ID	INTEGER NOT NULL,
	Wishlist_Items	VARCHAR(20),
	fk1_Customer_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "WISHLIST".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_WISHLIST PRIMARY KEY (Wishlist_ID),
    CONSTRAINT fk1_WISHLIST_to_CUSTIOMER FOREIGN KEY(fk1_Customer_ID) REFERENCES CUSTOMER(Customer_ID)
);



-- Create a Database table to represent the "CART" entity.
CREATE TABLE CART(
	Cart_ID	INTEGER NOT NULL,
	Total_Price	INTEGER,
	fk1_Customer_ID	INTEGER NOT NULL,
	-- Specify FK as unique to maintain 1:1 relationship
	UNIQUE(fk1_Customer_ID),
	-- Specify the PRIMARY KEY constraint for table "CART".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_CART PRIMARY KEY (Cart_ID),
    CONSTRAINT fk1_CART_to_Customer FOREIGN KEY(fk1_Customer_ID) REFERENCES CUSTOMER(Customer_ID)
);



-- Create a Database table to represent the "PRODUCT" entity.
CREATE TABLE PRODUCT(
	Product_ID	INTEGER NOT NULL,
	Product_Name	VARCHAR(50),
	Description	VARCHAR(200),
	Price	INTEGER,
	Stock	INTEGER,
	Date_Added	DATE,
    Product_Image BLOB,
	Min_Order	INTEGER,
	Max_Order	INTEGER,
	fk1_Shop_ID	INTEGER NOT NULL,
	fk2_Trader_ID	INTEGER NOT NULL,
	fk3_Category_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "PRODUCT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_PRODUCT PRIMARY KEY (Product_ID),
    CONSTRAINT fk1_PRODUCT_to_SHOP FOREIGN KEY(fk1_Shop_ID) REFERENCES SHOP(Shop_ID),
    CONSTRAINT fk2_PRODUCT_to_trader FOREIGN KEY(fk2_Trader_ID) REFERENCES TRADER(Trader_ID),
    CONSTRAINT fk3_PRODUCT_to_PC FOREIGN KEY(fk3_Category_ID) REFERENCES PRODUCT_CATEGORY(Category_ID)
);



-- Create a Database table to represent the "CART_PRODUCT" entity.
CREATE TABLE CART_PRODUCT(
	Cart_Product_ID	INTEGER NOT NULL,
	fk1_Cart_ID	INTEGER NOT NULL,
	fk2_Product_ID	INTEGER NOT NULL,
    No_Of_Items	INTEGER,
	-- Specify the PRIMARY KEY constraint for table "CART_PRODUCT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_CART_PRODUCT PRIMARY KEY (Cart_Product_ID),
    CONSTRAINT fk1_CART_PRODUCT_to_CART FOREIGN KEY(fk1_Cart_ID) REFERENCES CART(Cart_ID),
    CONSTRAINT fk2_CART_P_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID)
);






-- Create a Database table to represent the "REVIEW" entity.
CREATE TABLE REVIEW(
	Review_ID	INTEGER NOT NULL,
	Rating	NUMERIC(8,2),
	Comments	VARCHAR(200),
	fk1_Customer_ID	INTEGER NOT NULL,
	fk2_Product_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "REVIEW".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_REVIEW PRIMARY KEY (Review_ID),
    CONSTRAINT fk1_REVIEW_to_customer FOREIGN KEY(fk1_Customer_ID) REFERENCES CUSTOMER(Customer_ID),
    CONSTRAINT fk2_REVIEW_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID)
);


-- Create a Database table to represent the "WISHLIST_PRODUCT" entity.
CREATE TABLE WISHLIST_PRODUCT(
	Wishlist_Product_ID	INTEGER NOT NULL,
	fk1_Wishlist_ID	INTEGER NOT NULL,
	fk2_Product_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "WISHLIST_PRODUCT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_WISHLIST_PRODUCT PRIMARY KEY (Wishlist_Product_ID),
    CONSTRAINT fk1_WP_to_WISHLIST FOREIGN KEY(fk1_Wishlist_ID) REFERENCES WISHLIST(wishlist_ID),
    CONSTRAINT fk2_WP_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID) 
);


/*
-- Create a Database table to represent the "REPORT_PRODUCT" entity.
CREATE TABLE REPORT_PRODUCT(
	Report_Product_ID	INTEGER NOT NULL,
	fk1_Report_ID	INTEGER NOT NULL,
	fk2_Product_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "REPORT_PRODUCT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_REPORT_PRODUCT PRIMARY KEY (Report_Product_ID),
    CONSTRAINT fk1_REPORT_PRODUCT_to_REPORT FOREIGN KEY(fk1_Report_ID) REFERENCES REPORT(Report_ID),
    CONSTRAINT fk2_REPORT_PRODUCT_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID)
);*/


-- Create a Database table to represent the "PAYMENT" entity.
CREATE TABLE PAYMENT(
	Payment_ID	INTEGER NOT NULL,
	Amount	NUMERIC(8,2),
	Payment_Method	VARCHAR(10),
	Payment_Date	DATE,
	fk1_Customer_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "PAYMENT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_PAYMENT PRIMARY KEY (Payment_ID),
    CONSTRAINT fk1_PAYMENT_to_customer FOREIGN KEY(fk1_Customer_ID) REFERENCES CUSTOMER(Customer_ID)
);


-- Create a Database table to represent the "ORDER" entity.
CREATE TABLE ORDER1(
	Order_ID	INTEGER NOT NULL,
	Order_Date	DATE,
	Total_Amount	NUMERIC(8,2),
	Quantity	INTEGER,
	fk1_Customer_ID	INTEGER NOT NULL,
	fk2_Payment_ID	INTEGER NOT NULL,
	-- Specify FK as unique to maintain 1:1 relationship
	UNIQUE(fk2_Payment_ID),
	fk3_Cart_ID	INTEGER NOT NULL,
	fk4_Slot_ID	INTEGER NOT NULL,
	fk5_Coupon_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "ORDER".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_ORDER PRIMARY KEY (Order_ID),
    CONSTRAINT fk1_ORDER_to_customer FOREIGN KEY(fk1_Customer_ID) REFERENCES CUSTOMER(Customer_ID),
    CONSTRAINT fk2_ORDER_to_PAYMENT FOREIGN KEY(fk2_Payment_ID) REFERENCES PAYMENT(Payment_ID),
    CONSTRAINT fk3_ORDER_to_CART FOREIGN KEY(fk3_Cart_ID) REFERENCES CART(Cart_ID),
    CONSTRAINT fk4_ORDER_to_COLLECTION_SLOT FOREIGN KEY(fk4_Slot_ID) REFERENCES COLLECTION_SLOT(Slot_ID),
    CONSTRAINT fk5_ORDER_to_COUPON FOREIGN KEY(fk5_Coupon_ID) REFERENCES COUPON(Coupon_ID)
);


-- Create a Database table to represent the "ORDER_PRODUCT" entity.
CREATE TABLE ORDER_PRODUCT(
	Order_Product_ID	INTEGER NOT NULL,
	fk1_Order_ID	INTEGER NOT NULL,
	fk2_Product_ID	INTEGER NOT NULL,
	-- Specify the PRIMARY KEY constraint for table "ORDER_PRODUCT".
	-- This indicates which attribute(s) uniquely identify each row of data.
	CONSTRAINT	pk_ORDER_PRODUCT PRIMARY KEY (Order_Product_ID),
    CONSTRAINT fk1_ORDER_PRODUCT_to_ORDER FOREIGN KEY(fk1_Order_ID) REFERENCES ORDER1(Order_ID),
    CONSTRAINT fk2_ORDER_PRODUCT_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID)
);








--------------------------------------------------------------
-- Create LINK tables --

-- These tables do not appear as entities on the model. The reason they are created
-- is to allow certain types of relationships to be implemented in a Relational type Database.
-- Each link table tends to represent a specific relationship that appears on the model.
-- The attributes contained in link tables are identified from the entities at either side
-- of the relationship. i.e. they do not define attributes in their own right.
-- Indeed foreign key constraints are always created to ensure referential integrity between the
-- link table attributes and the primary key attributes on which they are based.

-- Create a link table to represent the "DISCOUNT_PRODUCT" relationship.
-- The attributes of this table are taken from the primary keys of table "DISCOUNT" and
-- table "PRODUCT", i.e. each end of the relationship. A link table was created
-- because "DISCOUNT_PRODUCT" is a one to many relationship with optionality at the one side.
-- notice how the primary key is only based on the key of the table at the many side, i.e. table "PRODUCT".
CREATE TABLE DISCOUNT_PRODUCT(
	s_Discount_ID	INTEGER NOT NULL,
	d_Product_ID	INTEGER NOT NULL,
	PRIMARY KEY (d_Product_ID),
	FOREIGN KEY(s_Discount_ID) REFERENCES DISCOUNT(Discount_ID),-- ON DELETE RESTRICT ON UPDATE RESTRICT,
	FOREIGN KEY(d_Product_ID) REFERENCES PRODUCT(Product_ID) --ON DELETE RESTRICT ON UPDATE RESTRICT
);


--------------------------------------------------------------
-- Alter Tables to add fk constraints --

-- Now all the tables have been created the ALTER TABLE command is used to define some additional
-- constraints.  These typically constrain values of foreign keys to be associated in some way
-- with the primary keys of related tables.  Foreign key constraints can actually be specified
-- when each table is created, but doing so can lead to dependency problems within the script
-- i.e. tables may be referenced before they have been created.  This method is therefore safer.

-- Alter table to add new constraints required to implement the "REPORT_USER" relationship

-- This constraint ensures that the foreign key of table "REPORT"
-- correctly references the primary key of table "USER"

--ALTER TABLE REPORT ADD CONSTRAINT fk1_REPORT_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "SHOP_USER" relationship

-- This constraint ensures that the foreign key of table "SHOP"
-- correctly references the primary key of table "USER"

----ALTER TABLE SHOP ADD CONSTRAINT fk1_SHOP_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "PRODUCT_SHOP" relationship

-- This constraint ensures that the foreign key of table "PRODUCT"
-- correctly references the primary key of table "SHOP"

--ALTER TABLE PRODUCT ADD CONSTRAINT fk1_PRODUCT_to_SHOP FOREIGN KEY(fk1_Shop_ID) REFERENCES SHOP(Shop_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "PRODUCT_USER" relationship

-- This constraint ensures that the foreign key of table "PRODUCT"
-- correctly references the primary key of table "USER"

--ALTER TABLE PRODUCT ADD CONSTRAINT fk2_PRODUCT_to_USER FOREIGN KEY(fk2_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "WISHLIST_USER" relationship

-- This constraint ensures that the foreign key of table "WISHLIST"
-- correctly references the primary key of table "USER"

--ALTER TABLE WISHLIST ADD CONSTRAINT fk1_WISHLIST_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "REVIEW_USER" relationship

-- This constraint ensures that the foreign key of table "REVIEW"
-- correctly references the primary key of table "USER"

--ALTER TABLE REVIEW ADD CONSTRAINT fk1_REVIEW_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "CART_USER" relationship

-- This constraint ensures that the foreign key of table "CART"
-- correctly references the primary key of table "USER"

--ALTER TABLE CART ADD CONSTRAINT fk1_CART_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "ORDER_USER" relationship

-- This constraint ensures that the foreign key of table "ORDER"
-- correctly references the primary key of table "USER"

--ALTER TABLE ORDER1 ADD CONSTRAINT fk1_ORDER_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "PAYMENT_USER" relationship

-- This constraint ensures that the foreign key of table "PAYMENT"
-- correctly references the primary key of table "USER"

--ALTER TABLE PAYMENT ADD CONSTRAINT fk1_PAYMENT_to_USER FOREIGN KEY(fk1_User_ID) REFERENCES USER1(User_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "ORDER_PAYMENT" relationship

-- This constraint ensures that the foreign key of table "ORDER"
-- correctly references the primary key of table "PAYMENT"

--ALTER TABLE ORDER1 ADD CONSTRAINT fk2_ORDER_to_PAYMENT FOREIGN KEY(fk2_Payment_ID) REFERENCES PAYMENT(Payment_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "PRODUCT_PRODUCT_CATEGORY" relationship

-- This constraint ensures that the foreign key of table "PRODUCT"
-- correctly references the primary key of table "PRODUCT_CATEGORY"

--ALTER TABLE PRODUCT ADD CONSTRAINT fk3_PRODUCT_to_PRODUCT_CATEGORY FOREIGN KEY(fk3_Category_ID) REFERENCES PRODUCT_CATEGORY(Category_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "REVIEW_PRODUCT" relationship

-- This constraint ensures that the foreign key of table "REVIEW"
-- correctly references the primary key of table "PRODUCT"

--ALTER TABLE REVIEW ADD CONSTRAINT fk2_REVIEW_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "ORDER_CART" relationship

-- This constraint ensures that the foreign key of table "ORDER"
-- correctly references the primary key of table "CART"

--ALTER TABLE ORDER1 ADD CONSTRAINT fk3_ORDER_to_CART FOREIGN KEY(fk3_Cart_ID) REFERENCES CART(Cart_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "ORDER_COLLECTION_SLOT" relationship

-- This constraint ensures that the foreign key of table "ORDER"
-- correctly references the primary key of table "COLLECTION_SLOT"

--ALTER TABLE ORDER1 ADD CONSTRAINT fk4_ORDER_to_COLLECTION_SLOT FOREIGN KEY(fk4_Slot_ID) REFERENCES COLLECTION_SLOT(Slot_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "contains" relationship

-- This constraint ensures that the foreign key of table "WISHLIST_PRODUCT"
-- correctly references the primary key of table "WISHLIST"

--ALTER TABLE WISHLIST_PRODUCT ADD CONSTRAINT fk1_WISHLIST_PRODUCT_to_WISHLIST FOREIGN KEY(fk1_Wishlist_ID) REFERENCES WISHLIST(Wishlist_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "has" relationship

-- This constraint ensures that the foreign key of table "WISHLIST_PRODUCT"
-- correctly references the primary key of table "PRODUCT"

--ALTER TABLE WISHLIST_PRODUCT ADD CONSTRAINT fk2_WISHLIST_PRODUCT_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "contains" relationship

-- This constraint ensures that the foreign key of table "CART_PRODUCT"
-- correctly references the primary key of table "CART"

--ALTER TABLE CART_PRODUCT ADD CONSTRAINT fk1_CART_PRODUCT_to_CART FOREIGN KEY(fk1_Cart_ID) REFERENCES CART(Cart_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "has" relationship

-- This constraint ensures that the foreign key of table "CART_PRODUCT"
-- correctly references the primary key of table "PRODUCT"

--ALTER TABLE CART_PRODUCT ADD CONSTRAINT fk2_CART_PRODUCT_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "tracks" relationship

-- This constraint ensures that the foreign key of table "REPORT_PRODUCT"
-- correctly references the primary key of table "REPORT"

--ALTER TABLE REPORT_PRODUCT ADD CONSTRAINT fk1_REPORT_PRODUCT_to_REPORT FOREIGN KEY(fk1_Report_ID) REFERENCES REPORT(Report_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "tracks" relationship

-- This constraint ensures that the foreign key of table "REPORT_PRODUCT"
-- correctly references the primary key of table "PRODUCT"

--ALTER TABLE REPORT_PRODUCT ADD CONSTRAINT fk2_REPORT_PRODUCT_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "has" relationship

-- This constraint ensures that the foreign key of table "ORDER_PRODUCT"
-- correctly references the primary key of table "ORDER"

--ALTER TABLE ORDER_PRODUCT ADD CONSTRAINT fk1_ORDER_PRODUCT_to_ORDER FOREIGN KEY(fk1_Order_ID) REFERENCES ORDER1(Order_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "has" relationship

-- This constraint ensures that the foreign key of table "ORDER_PRODUCT"
-- correctly references the primary key of table "PRODUCT"

--ALTER TABLE ORDER_PRODUCT ADD CONSTRAINT fk2_ORDER_PRODUCT_to_PRODUCT FOREIGN KEY(fk2_Product_ID) REFERENCES PRODUCT(Product_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Alter table to add new constraints required to implement the "ORDER_COUPON" relationship

-- This constraint ensures that the foreign key of table "ORDER"
-- correctly references the primary key of table "COUPON"

--ALTER TABLE ORDER1 ADD CONSTRAINT fk5_ORDER_to_COUPON FOREIGN KEY(fk5_Coupon_ID) REFERENCES COUPON(Coupon_ID) ON DELETE RESTRICT ON UPDATE RESTRICT;


