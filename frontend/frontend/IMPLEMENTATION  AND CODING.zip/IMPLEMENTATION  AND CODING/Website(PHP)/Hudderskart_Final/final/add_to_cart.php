<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['customer_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

if (!isset($_POST['product_id'])) {
    echo json_encode(['success' => false, 'message' => 'Product ID not provided']);
    exit;
}

$customer_id = $_SESSION['customer_id'];
$product_id = $_POST['product_id'];

try {
    // Check if customer has a cart
    $check_cart = "SELECT Cart_ID FROM CART WHERE fk1_Customer_ID = :customer_id";
    $stmt = oci_parse($conn, $check_cart);
    oci_bind_by_name($stmt, ":customer_id", $customer_id);
    oci_execute($stmt);
    
    $cart_id = null;
    
    if ($row = oci_fetch_array($stmt, OCI_ASSOC)) {
        // Cart exists
        $cart_id = $row['CART_ID'];
        
        // Check if product already exists in cart
        $check_product = "SELECT Cart_Product_ID, No_Of_Items FROM CART_PRODUCT 
                         WHERE fk1_Cart_ID = :cart_id AND fk2_Product_ID = :product_id";
        $stmt = oci_parse($conn, $check_product);
        oci_bind_by_name($stmt, ":cart_id", $cart_id);
        oci_bind_by_name($stmt, ":product_id", $product_id);
        oci_execute($stmt);
        
        if ($product_row = oci_fetch_array($stmt, OCI_ASSOC)) {
            // Product exists, update quantity
            $new_quantity = $product_row['NO_OF_ITEMS'] + 1;
            $update_quantity = "UPDATE CART_PRODUCT 
                              SET No_Of_Items = :new_quantity 
                              WHERE Cart_Product_ID = :cart_product_id";
            $stmt = oci_parse($conn, $update_quantity);
            oci_bind_by_name($stmt, ":new_quantity", $new_quantity);
            oci_bind_by_name($stmt, ":cart_product_id", $product_row['CART_PRODUCT_ID']);
            oci_execute($stmt);
        } else {
            // Product doesn't exist, insert new
            $add_product = "INSERT INTO CART_PRODUCT (Cart_Product_ID, fk1_Cart_ID, fk2_Product_ID, No_Of_Items) 
                           VALUES (seq_cart_product.NEXTVAL, :cart_id, :product_id, 1)";
            $stmt = oci_parse($conn, $add_product);
            oci_bind_by_name($stmt, ":cart_id", $cart_id);
            oci_bind_by_name($stmt, ":product_id", $product_id);
            oci_execute($stmt);
        }
    } else {
        // Create new cart
        $create_cart = "INSERT INTO CART (Cart_ID, fk1_Customer_ID, Total_Price) 
                       VALUES (seq_cart.NEXTVAL, :customer_id, 0) 
                       RETURNING Cart_ID INTO :cart_id";
        $stmt = oci_parse($conn, $create_cart);
        oci_bind_by_name($stmt, ":customer_id", $customer_id);
        oci_bind_by_name($stmt, ":cart_id", $cart_id, -1, SQLT_INT);
        oci_execute($stmt);
        
        // Add first product with quantity 1
        $add_product = "INSERT INTO CART_PRODUCT (Cart_Product_ID, fk1_Cart_ID, fk2_Product_ID, No_Of_Items) 
                       VALUES (seq_cart_product.NEXTVAL, :cart_id, :product_id, 1)";
        $stmt = oci_parse($conn, $add_product);
        oci_bind_by_name($stmt, ":cart_id", $cart_id);
        oci_bind_by_name($stmt, ":product_id", $product_id);
        oci_execute($stmt);
    }
    
    // Update cart total
    $update_cart = "UPDATE CART 
                   SET Total_Price = (
                       SELECT SUM(p.Price * cp.No_Of_Items) 
                       FROM CART_PRODUCT cp 
                       JOIN PRODUCT p ON cp.fk2_Product_ID = p.Product_ID 
                       WHERE cp.fk1_Cart_ID = :cart_id
                   )
                   WHERE Cart_ID = :cart_id";
    $stmt = oci_parse($conn, $update_cart);
    oci_bind_by_name($stmt, ":cart_id", $cart_id);
    oci_execute($stmt);
    
    echo json_encode(['success' => true, 'message' => 'Product added to cart']);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    if (isset($stmt)) {
        oci_free_statement($stmt);
    }
    oci_close($conn);
}
?>