<?php
// Enable errors while debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'connect.php';

// ─────────────────────────────────────────────────────
// 0) Make sure we have a sequence to assign Trader_ID
// ─────────────────────────────────────────────────────
$ddl = <<<PLSQL
BEGIN
  EXECUTE IMMEDIATE
    'CREATE SEQUENCE TRADER_SEQ START WITH 1 INCREMENT BY 1 NOCACHE';
EXCEPTION WHEN OTHERS THEN
  IF SQLCODE != -955 THEN RAISE; END IF;  -- ignore "already exists"
END;
PLSQL;
oci_execute(oci_parse($conn, $ddl));

// ─────────────────────────────────────────────────────
// Gather POST values
// ─────────────────────────────────────────────────────
$error    = '';
$name     = $_POST['name']             ?? '';
$email    = $_POST['email']            ?? '';
$password = $_POST['password']         ?? '';
$confirm  = $_POST['confirm-password'] ?? '';
$address  = $_POST['address']          ?? '';
$phone    = $_POST['phone']            ?? '';
$username = $_POST['username']         ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1) Passwords match?
    if ($password !== $confirm) {
        $error = '⚠️ Passwords do not match.';
    } else {
        // 2) Check email/username uniqueness
        $chk = oci_parse($conn,
            "SELECT 1
               FROM TRADER
              WHERE Email = :email
                 OR Username = :username"
        );
        oci_bind_by_name($chk, ":email",    $email);
        oci_bind_by_name($chk, ":username", $username);
        oci_execute($chk);

        if (oci_fetch($chk)) {
            $error = '⚠️ Email or username already registered.';
        } else {
            // split name
            $parts = explode(' ', trim($name), 2);
            $fname = $parts[0];
            $lname = $parts[1] ?? '';

            // 3) Insert using TRADER_SEQ for Trader_ID
            $sql = <<<PLSQL
INSERT INTO TRADER (
  Trader_ID,
  FirstName,
  LastName,
  Date_Created,
  Email,
  Address,
  Password,
  Phone_no,
  Username
) VALUES (
  TRADER_SEQ.NEXTVAL,
  :fname,
  :lname,
  SYSDATE,
  :email,
  :address,
  :pass,
  :phone,
  :username
)
RETURNING Trader_ID INTO :new_id
PLSQL;
            $ins = oci_parse($conn, $sql);
            oci_bind_by_name($ins, ":fname",    $fname);
            oci_bind_by_name($ins, ":lname",    $lname);
            oci_bind_by_name($ins, ":email",    $email);
            oci_bind_by_name($ins, ":address",  $address);
            oci_bind_by_name($ins, ":pass",     $password);
            oci_bind_by_name($ins, ":phone",    $phone);
            oci_bind_by_name($ins, ":username", $username);
            oci_bind_by_name($ins, ":new_id",   $newId, -1, SQLT_INT);

            if (oci_execute($ins, OCI_COMMIT_ON_SUCCESS)) {
                // 4) Store session + email OTP
                $_SESSION['trader_id']    = $newId;
                $_SESSION['trader_email'] = $email;

                $otp = rand(100000, 999999);
                $_SESSION['otp'] = $otp;
                mail(
                  $email,
                  'HuddersKart Trader Verification',
                  "Hello $fname,\n\nYour verification code is: $otp",
                  "From: no-reply@hudderskart.com\r\n"
                );

                // 5) Redirect to OTP verify
                header('Location: verify_otp.php');
                exit;
            } else {
                $e     = oci_error($ins);
                $error = '❌ Registration error: ' . htmlentities($e['message']);
            }
        }
    }
}
oci_close($conn);
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HuddersKart – Trader Sign Up</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/register.css">
</head>
<body>
  <?php include 'header.php'; ?>

  <main>
    <div class="container">
      <div class="signup-container">
        <div class="signup-header">
          <h1>Trader Registration</h1>
          <h2>Create Your Trader Account</h2>
        </div>

        <?php if ($error): ?>
          <p class="error-msg"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form id="signup-form" method="POST" action="">
          <div class="form-group">
            <label for="name">Trader Name</label>
            <input type="text" id="name" name="name"
                   value="<?= htmlspecialchars($name) ?>"
                   required placeholder="First and last name">
          </div>
          <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username"
                   value="<?= htmlspecialchars($username) ?>"
                   required placeholder="Choose a username">
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($email) ?>"
                   required placeholder="you@example.com">
          </div>
          <div class="form-group">
            <label for="address">Address</label>
            <input type="text" id="address" name="address"
                   value="<?= htmlspecialchars($address) ?>"
                   required placeholder="Your business address">
          </div>
          <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone"
                   value="<?= htmlspecialchars($phone) ?>"
                   required placeholder="123-456-7890">
            <small>Format: 123-456-7890</small>
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                   required placeholder="••••••••" minlength="8">
          </div>
          <div class="form-group">
            <label for="confirm-password">Confirm Password</label>
            <input type="password" id="confirm-password"
                   name="confirm-password" required
                   placeholder="••••••••" minlength="8">
          </div>
          <button type="submit" class="submit-btn">
            REGISTER AS TRADER
          </button>
        </form>

        <p class="signin-link">
          Already have an account? <a href="login.php">Sign In</a>
        </p>
      </div>
    </div>
  </main>

  <?php include 'footer.php'; ?>
  <script src="script/registerTrader.js"></script>
</body>
</html>
