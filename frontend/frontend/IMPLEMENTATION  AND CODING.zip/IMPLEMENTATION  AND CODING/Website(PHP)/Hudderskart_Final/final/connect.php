<?php
// Replace these with the Oracle schema user that owns your CUSTOMER table:
$username = 'hudderskart';       // your Oracle username
$password = '123456';  // your Oracle password
// Either TNS name or EZCONNECT style:
$connection_string = 'localhost/XE';  

$conn = oci_connect($username, $password, $connection_string);
if (!$conn) {
    $e = oci_error();
    throw new Exception("Database connection failed: " . $e['message']);
}
?>
