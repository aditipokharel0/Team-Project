<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['customer_id'])) {
    header('Location: login.php');
    exit;
}

// Function to handle BLOB to base64 conversion
function getImageData($blob) {
    if (!$blob) return '';
    if (is_string($blob)) return base64_encode($blob);
    if (is_object($blob)) return base64_encode($blob->load());
    return '';
}

// Fetch cart items with proper case for column aliases
$sql = "SELECT p.Product_ID, 
               p.Product_Name, 
               p.Price, 
               p.Product_Image,
               cp.No_Of_Items as NO_OF_ITEMS, 
               cp.Cart_Product_ID,
               c.Total_Price
        FROM CART c
        JOIN CART_PRODUCT cp ON c.Cart_ID = cp.fk1_Cart_ID
        JOIN PRODUCT p ON cp.fk2_Product_ID = p.Product_ID
        WHERE c.fk1_Customer_ID = :customer_id";

$stmt = oci_parse($conn, $sql);
oci_bind_by_name($stmt, ":customer_id", $_SESSION['customer_id']);
oci_execute($stmt);

$cartItems = [];
$total = 0;
while ($row = oci_fetch_array($stmt, OCI_ASSOC + OCI_RETURN_LOBS)) {
    // Add error checking for the quantity
    $quantity = isset($row['NO_OF_ITEMS']) ? $row['NO_OF_ITEMS'] : 1;
    $row['NO_OF_ITEMS'] = $quantity; // Ensure the key exists
    $cartItems[] = $row;
    $total += ($row['PRICE'] * $quantity);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (empty($cartItems)): ?>
            <p>Your cart is empty</p>
            <a href="main.php" class="continue-shopping">Continue Shopping</a>
        <?php else: ?>
            <?php foreach ($cartItems as $item): ?>
                <div class="cart-item">
                    <?php 
                    $imageData = isset($item['PRODUCT_IMAGE']) ? getImageData($item['PRODUCT_IMAGE']) : '';
                    ?>
                    <?php if ($imageData): ?>
                        <img src="data:image/jpeg;base64,<?php echo $imageData; ?>" 
                             alt="<?php echo htmlspecialchars($item['PRODUCT_NAME']); ?>" 
                             class="cart-item-img">
                    <?php else: ?>
                        <img src="./images/default-product.jpg" 
                             alt="<?php echo htmlspecialchars($item['PRODUCT_NAME']); ?>" 
                             class="cart-item-img">
                    <?php endif; ?>
                    <div class="item-details">
                        <h3><?php echo htmlspecialchars($item['PRODUCT_NAME']); ?></h3>
                        <p>Price: £<?php echo number_format($item['PRICE'], 2); ?></p>
                        <p>Quantity: <?php echo $item['NO_OF_ITEMS']; ?></p>
                        <p>Subtotal: £<?php echo number_format($item['PRICE'] * $item['NO_OF_ITEMS'], 2); ?></p>
                    </div>
                    <button class="remove-btn" 
                            onclick="removeFromCart(<?php echo $item['CART_PRODUCT_ID']; ?>)">
                        Remove
                    </button>
                </div>
            <?php endforeach; ?>
            <div class="cart-summary">
                <h3>Total: £<?php echo number_format($total, 2); ?></h3>
                <button class="checkout-btn" onclick="window.location.href='checkout.php'">
                    Proceed to Checkout
                </button>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>