import serial  # Make sure pyserial is installed: pip install pyserial
import cx_Oracle
import time
import os

# Database configuration
DB_USER = "hudderskart"
DB_PASS = "123456"
DB_DSN = "localhost/XE"

# RFID to Product mapping
PRODUCTS = {
    "93513811": {
        "name": "chicken meat",
        "price": 12.50,
        "quantity": 1,
        "description": "Fresh chicken meat"
    },
    "D71CCF01": {
        "name": "buff",
        "price": 10.00,
        "quantity": 1,
        "description": "Fresh buff meat"
    }
}

# Get absolute path for the text file
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "last_uid.txt")
print(f"File will be saved to: {file_path}")

# Try to create the file first to test permissions
try:
    with open(file_path, "w+") as test_file:
        test_file.write("")
    print("File creation test successful")
except Exception as e:
    print(f"Cannot create file: {e}")
    exit(1)

def insert_product(conn, uid):
    if uid not in PRODUCTS:
        print(f"Unknown UID: {uid}")
        return False
    
    product = PRODUCTS[uid]
    cursor = conn.cursor()
    
    try:
        # Insert new product
        cursor.execute("""
            INSERT INTO PRODUCT (
                SHOP_ID, CATEGORY_ID, NAME, PRICE, QUANTITY,
                DESCRIPTION, CREATED_AT, IS_ACTIVE, MIN_ORDER,
                MAX_ORDER, ALLERGY_INFO, WISHLIST_COUNT, TRADER_ID
            ) VALUES (
                608, 1000, :name, :price, :quantity,
                :description, SYSTIMESTAMP, 1, 1,
                10, 'None', 0, 1
            )""", product)
        
        conn.commit()
        print(f"Product {product['name']} inserted successfully")
        return True
        
    except cx_Oracle.Error as e:
        print(f"Database error: {str(e)}")
        conn.rollback()
        return False
    finally:
        cursor.close()

def main():
    try:
        # Connect to Oracle
        print("Connecting to database...")
        conn = cx_Oracle.connect(DB_USER, DB_PASS, DB_DSN)
        print("Database connection successful")
        
        # Connect to Arduino
        ser = serial.Serial('COM7', 9600, timeout=1)
        print("Serial connection established on COM7")
        
        while True:
            if ser.in_waiting > 0:
                line = ser.readline().decode('utf-8').strip()
                print(f"Serial Read: {line}")
                
                if line.startswith("UID:"):
                    uid = line.split("UID:")[1].strip()
                    print(f"Processing UID: {uid}")
                    
                    if insert_product(conn, uid):
                        print("Product processed successfully")
                    else:
                        print("Failed to process product")
                    
                    time.sleep(1)
                    break
                    
    except serial.SerialException as e:
        print(f"Serial port error: {str(e)}")
    except cx_Oracle.Error as e:
        print(f"Database error: {str(e)}")
    finally:
        try:
            ser.close()
            conn.close()
            print("Connections closed")
        except:
            pass

if __name__ == "__main__":
    main()