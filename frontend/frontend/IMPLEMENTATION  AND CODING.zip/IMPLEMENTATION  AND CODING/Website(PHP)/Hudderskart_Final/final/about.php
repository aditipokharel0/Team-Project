<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HuddersKart - Local Food Marketplace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="./css/about.css">
</head>

<body>
    <?php
    include "header.php";
    ?>
    <!-- Banner -->
    <section class="banner">
        <h1>About Us</h1>
        <p>At HuddersKart, we're passionate about bringing fresh, high-quality groceries to your doorstep. Our mission
            is to connect local producers with consumers, making sustainable shopping easier and more convenient than
            ever before.</p>
    </section>

    <!-- Content -->
    <section class="content-section">
        <div class="image-block">
            <img src="https://images.unsplash.com/photo-1516594798947-e65505dbb29d?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZnJlc2glMjBwcm9kdWNlfGVufDB8fDB8fHww"
                alt="Fresh produce selection">
        </div>
        <div class="text-block highlight">
            <p>HuddersKart began with a simple idea: to create a marketplace where local farmers and food producers
                could connect directly with customers. We believe in supporting local communities and providing access
                to fresh, seasonal produce that doesn't have to travel thousands of miles to reach your table.</p>
        </div>
        <div class="text-block">
            <p>Our platform brings together hundreds of independent grocers, farmers, and artisanal food producers,
                giving you unprecedented access to the best local and organic products. We carefully vet each vendor to
                ensure they meet our high standards for quality, sustainability, and ethical business practices.</p>
        </div>
        <div class="image-block">
            <img src="https://images.unsplash.com/photo-1589470288084-ecad61835772?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bG9jYWwlMjBtYXJrZXR8ZW58MHx8MHx8fDA%3D"
                alt="Local farmers market">
        </div>
        <div class="text-block">
            <p>When you shop with HuddersKart, you're not just buying groceries—you're supporting a movement toward more
                sustainable, community-focused food systems. Our efficient delivery network ensures your items arrive
                fresh and on time, with minimal environmental impact. Join us in reimagining how grocery shopping can
                work for everyone.</p>
        </div>
    </section>


    <?php
    include "footer.php";
    ?>
    <script src="./script/about.js">
    </script>
</body>

</html>