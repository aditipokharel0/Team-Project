<?php
session_start();
require_once 'connect.php';

// Load PayPal configuration
$paypalConfig = require_once 'payment/config.php';
define('PAYPAL_CLIENT_ID', $paypalConfig['client_id']);

if (!isset($_SESSION['customer_id'])) {
    header('Location: login.php');
    exit;
}

// Function to handle BLOB to base64 conversion
function getImageData($blob) {
    if (!$blob) return '';
    if (is_string($blob)) return base64_encode($blob);
    if (is_object($blob)) return base64_encode($blob->load());
    return '';
}

// Fetch cart items with quantities
$sql = "SELECT p.Product_ID, 
               p.Product_Name, 
               p.Price, 
               p.Product_Image,
               cp.No_Of_Items as \"NO_OF_ITEMS\",  -- Note the double quotes and alias
               cp.Cart_Product_ID,
               c.Total_Price
        FROM CART c
        JOIN CART_PRODUCT cp ON c.Cart_ID = cp.fk1_Cart_ID
        JOIN PRODUCT p ON cp.fk2_Product_ID = p.Product_ID
        WHERE c.fk1_Customer_ID = :customer_id";

$stmt = oci_parse($conn, $sql);
oci_bind_by_name($stmt, ":customer_id", $_SESSION['customer_id']);
oci_execute($stmt);

$cartItems = [];
$subtotal = 0;

while ($row = oci_fetch_array($stmt, OCI_ASSOC + OCI_RETURN_LOBS)) {
    // Debug log to check the array keys
    // error_log(print_r($row, true));
    
    // Ensure quantity is set with a fallback to 1
    $quantity = isset($row['NO_OF_ITEMS']) ? $row['NO_OF_ITEMS'] : 1;
    $row['NO_OF_ITEMS'] = $quantity;
    $cartItems[] = $row;
    $subtotal += ($row['PRICE'] * $quantity);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - HuddersKart</title>
    <link rel="stylesheet" href="./css/style.css">
    <style>
        /* Main content */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .cart-title {
            font-size: 24px;
            margin-bottom: 5px;
        }

        .cart-subtitle {
            margin-bottom: 20px;
            color: #666;
        }

        /* Cart layout */
        .cart-layout {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
        }

        .cart-items {
            flex: 1 1 60%;
        }

        .order-summary {
            flex: 1 1 30%;
            min-width: 300px;
        }

        /* Cart item */
        .cart-item {
            display: flex;
            padding: 20px 0;
            border-bottom: 1px solid #ddd;
        }

        .item-image {
            width: 120px;
            height: 100px;
            background-color: #ddd;
            margin-right: 20px;
        }

        .item-details {
            flex-grow: 1;
        }

        .item-title {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .item-price {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .item-quantity {
            margin-bottom: 5px;
            color: #666;
        }

        .remove-btn {
            background: none;
            border: none;
            color: #e74c3c;
            cursor: pointer;
            padding: 0;
            margin-top: 5px;
        }

        /* Order summary */
        .summary-title {
            font-size: 20px;
            margin-bottom: 20px;
        }

        .coupon-input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .summary-label {
            color: #666;
        }

        .summary-value {
            font-weight: bold;
        }

        .shipping-note {
            color: #666;
            font-size: 14px;
        }

        .summary-total {
            border-top: 1px solid #ddd;
            padding-top: 15px;
            margin-top: 15px;
        }

        .checkout-btn {
            width: 100%;
            padding: 15px;
            background-color: #111;
            color: white;
            border: none;
            margin-top: 20px;
            cursor: pointer;
            font-size: 16px;
        }

        .checkout-btn:hover {
            background-color: #000;
        }

        .empty-cart {
            text-align: center;
            padding: 40px;
            color: #666;
            font-style: italic;
        }

        /* Quantity controls */
        .quantity-controls {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .quantity-btn {
            background-color: #f0f0f0;
            border: 1px solid #ddd;
            padding: 10px;
            cursor: pointer;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .quantity-input {
            border: 1px solid #ddd;
            padding: 10px;
            width: 60px;
            text-align: center;
            margin: 0 5px;
        }

        /* PayPal button container */
        #paypal-button-container {
            margin-top: 20px;
            width: 100%;
            min-height: 45px;
            clear: both;
        }

        .paypal-buttons {
            min-height: 45px;
            opacity: 1 !important;
            z-index: 999 !important;
        }
    </style>
</head>
<body>
    <!-- Header with Logo and Search -->
    <header class="header">
        <a href="./index.php" class="logo"><img src="images/logo.png" alt="HuddersKart Logo"></a>
        
        <div class="search-container">
            <input type="text" placeholder="Search">
            <i class="fa-solid fa-magnifying-glass"></i>
        </div>
        <div class="user-actions">
            <div class="cart-icon">
                <span>🛒</span>
                <span class="cart-count">0</span>
            </div>
            <a href="./login.php">Login</a>
            <a href="./register.php">Register</a>
            <a href="./costumer.php">👤</a>
        </div>
    </header>

    <!-- Main Navigation -->
    <nav class="main-nav">
        <div class="menu-toggle">☰</div>
        <ul class="nav-links">
            <li><a href="./index.php">Home</a></li>
            <li><a href="./about.php">About Us</a></li>
            <li><a href="./categories.php">Categories</a></li>
            <li><a href="#">Become a trader</a></li>
            <li><a href="./contact.php">Contact Us</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <h1 class="cart-title">Your cart</h1>
        <p class="cart-subtitle">Not ready to checkout? <a href="main.php">Continue Shopping</a></p>

        <div class="cart-layout">
            <div class="cart-items" id="cartItems">
                <?php if (empty($cartItems)): ?>
                    <div class="empty-cart">Your cart is empty</div>
                <?php else: ?>
                    <?php foreach ($cartItems as $item): ?>
                        <div class="cart-item">
                            <?php 
                            $imageData = isset($item['PRODUCT_IMAGE']) ? getImageData($item['PRODUCT_IMAGE']) : '';
                            if ($imageData): 
                            ?>
                                <img src="data:image/jpeg;base64,<?php echo $imageData; ?>" 
                                     alt="<?php echo htmlspecialchars($item['PRODUCT_NAME']); ?>" 
                                     class="item-image">
                            <?php else: ?>
                                <img src="./images/default-product.jpg" 
                                     alt="<?php echo htmlspecialchars($item['PRODUCT_NAME']); ?>" 
                                     class="item-image">
                            <?php endif; ?>
                            
                            <div class="item-details">
                                <h3 class="item-title"><?php echo htmlspecialchars($item['PRODUCT_NAME']); ?></h3>
                                <p class="item-price">£<?php echo number_format($item['PRICE'], 2); ?></p>
                                <div class="quantity-controls">
                                    <button class="quantity-btn minus" data-id="<?php echo $item['CART_PRODUCT_ID']; ?>">-</button>
                                    <input type="number" class="quantity-input" value="<?php echo $item['NO_OF_ITEMS']; ?>" 
                                           min="1" data-id="<?php echo $item['CART_PRODUCT_ID']; ?>" 
                                           data-product-id="<?php echo $item['PRODUCT_ID']; ?>" readonly>
                                    <button class="quantity-btn plus" data-id="<?php echo $item['CART_PRODUCT_ID']; ?>">+</button>
                                </div>
                                <p class="item-subtotal">Subtotal: £<?php echo number_format($item['PRICE'] * $item['NO_OF_ITEMS'], 2); ?></p>
                                <button class="remove-btn" data-id="<?php echo $item['CART_PRODUCT_ID']; ?>">Remove</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="order-summary">
                <h2 class="summary-title">Order Summary</h2>
                <div class="summary-row">
                    <span class="summary-label">Subtotal</span>
                    <span class="summary-value">£<?php echo number_format($subtotal, 2); ?></span>
                </div>
                
                <div class="summary-row">
                    <span class="summary-label">Shipping</span>
                    <span class="shipping-note">Calculated at the next step</span>
                </div>
                
                <div class="summary-row summary-total">
                    <span class="summary-label">Total</span>
                    <span class="summary-value">£<?php echo number_format($subtotal, 2); ?></span>
                </div>
                
                <!-- Add this in your order summary section, before the checkout button -->
                <div id="paypal-button-container"></div>
                <button class="checkout-btn" id="checkoutBtn" style="display: none;">
                    Continue to checkout
                </button>
            </div>
        </div>  
    </div>

    <script src="https://www.paypal.com/sdk/js?client-id=<?php echo PAYPAL_CLIENT_ID; ?>&currency=GBP"></script>
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Quantity update function with debug logging
    async function updateQuantity(cartProductId, change, quantityBtn) {
        console.log('Updating quantity for cart product ID:', cartProductId);

        try {
            const response = await fetch('update_cart_quantity.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `cart_product_id=${cartProductId}&change=${change}`
            });
            
            const data = await response.json();
            console.log('Server response:', data);
            
            if (data.success) {
                // Find the specific cart item using the button's parent container
                const itemContainer = quantityBtn.closest('.cart-item');
                const quantityInput = itemContainer.querySelector(`.quantity-input[data-id="${cartProductId}"]`);
                const currentQty = parseInt(quantityInput.value);
                const newQty = currentQty + change;
                
                console.log('Current quantity:', currentQty, 'New quantity:', newQty);
                
                if (newQty >= 1) {
                    quantityInput.value = newQty;
                    
                    // Update subtotal for this specific item
                    const priceEl = itemContainer.querySelector('.item-price');
                    const priceText = priceEl.textContent.replace('£', '');
                    const price = parseFloat(priceText);
                    const subtotalEl = itemContainer.querySelector('.item-subtotal');
                    const newSubtotal = (price * newQty).toFixed(2);
                    subtotalEl.textContent = `Subtotal: £${newSubtotal}`;
                    
                    console.log('Price:', price, 'New subtotal:', newSubtotal);
                    
                    // Update order total
                    updateOrderTotal();
                }
            } else {
                throw new Error(data.message || 'Error updating quantity');
            }
        } catch (error) {
            console.error('Error details:', error);
            alert('Error updating quantity: ' + error.message);
        }
    }

    // Function to update order total
    function updateOrderTotal() {
        const subtotals = document.querySelectorAll('.item-subtotal');
        let total = 0;
        
        subtotals.forEach(sub => {
            const subtotalText = sub.textContent.replace('Subtotal: £', '');
            const amount = parseFloat(subtotalText);
            if (!isNaN(amount)) {
                total += amount;
            }
        });
        
        console.log('Calculated total:', total);
        
        // Update both subtotal and total in summary
        document.querySelectorAll('.summary-value').forEach(value => {
            value.textContent = `£${total.toFixed(2)}`;
        });
    }

    // Add click handlers to all quantity buttons
    document.querySelectorAll('.quantity-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const cartProductId = this.getAttribute('data-id');
            const change = this.classList.contains('plus') ? 1 : -1;
            const quantityInput = this.closest('.quantity-controls').querySelector('.quantity-input');
            const currentQuantity = parseInt(quantityInput.value);
            
            console.log('Button clicked:', {
                cartProductId,
                change,
                currentQuantity
            });
            
            if (change === -1 && currentQuantity === 1) {
                if (confirm('Remove item from cart?')) {
                    removeFromCart(cartProductId);
                }
                return;
            }
            
            updateQuantity(cartProductId, change, this);
        });
    });

    // Function to remove item from cart
    function removeFromCart(cartProductId) {
        fetch('remove_from_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `cart_product_id=${cartProductId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove item from DOM
                const itemToRemove = document.querySelector(`.cart-item .remove-btn[data-id="${cartProductId}"]`).closest('.cart-item');
                if (itemToRemove) {
                    itemToRemove.remove();
                }
                updateOrderTotal();

                // Show empty cart message if no items left
                if (document.querySelectorAll('.cart-item').length === 0) {
                    document.getElementById('cartItems').innerHTML = '<div class="empty-cart">Your cart is empty</div>';
                    document.querySelectorAll('.summary-value').forEach(el => {
                        el.textContent = '£0.00';
                    });
                }
            } else {
                alert('Error removing item from cart');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error removing item from cart');
        });
    }

    // Initialize remove button listeners
    document.querySelectorAll('.remove-btn').forEach(button => {
        button.addEventListener('click', function() {
            const cartProductId = this.dataset.id;
            removeFromCart(cartProductId);
        });
    });

    // Checkout button click
    document.getElementById('checkoutBtn').addEventListener('click', (e) => {
        const cartItems = document.querySelectorAll('.cart-item');
        if (cartItems.length === 0) {
            e.preventDefault();
            alert('Your cart is empty!');
        }
    });

    // PayPal integration
    paypal.Buttons({
        createOrder: function(data, actions) {
            // Calculate total
            let total = 0;
            document.querySelectorAll('.item-subtotal').forEach(sub => {
                const amount = parseFloat(sub.textContent.replace('Subtotal: £', ''));
                if (!isNaN(amount)) total += amount;
            });

            if (total <= 0) {
                alert('Your cart is empty!');
                return;
            }

            return actions.order.create({
                purchase_units: [{
                    amount: {
                        currency_code: 'GBP',
                        value: total.toFixed(2)
                    }
                }]
            });
        },
        onApprove: function(data, actions) {
            // Show loading state
            document.body.style.cursor = 'wait';

            return actions.order.capture()
                .then(function(orderData) {
                    // Prepare cart items data
                    const cartItems = Array.from(document.querySelectorAll('.cart-item')).map(item => ({
                        product_id: item.querySelector('.quantity-input').getAttribute('data-product-id'),
                        quantity: parseInt(item.querySelector('.quantity-input').value)
                    }));

                    // Send to backend
                    return fetch('save_order.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            paypal_order_id: orderData.id,
                            total: orderData.purchase_units[0].amount.value,
                            items: cartItems
                        })
                    });
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear cart UI
                        const cartContainer = document.getElementById('cartItems');
                        if (cartContainer) {
                            cartContainer.innerHTML = '';
                        }
                        
                        // Update totals to zero
                        document.querySelectorAll('.summary-value').forEach(el => {
                            el.textContent = '£0.00';
                        });

                        // Redirect to success page
                        window.location.href = `order_success.php?order_id=${data.order_id}`;
                    } else {
                        throw new Error(data.message || 'Order processing failed');
                    }
                })
                .catch(error => {
                    console.error('Payment Error:', error);
                    alert('Payment failed: ' + error.message);
                    document.body.style.cursor = 'default';
                });
        }
    }).render('#paypal-button-container');
    });
    </script>
</body>
</html>

