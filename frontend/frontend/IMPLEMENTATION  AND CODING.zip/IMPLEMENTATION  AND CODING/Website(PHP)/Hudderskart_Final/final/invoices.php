<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
     /* Main Content */
        main {
            max-width: 1000px;
            margin: 20px auto;
            padding: 0 20px;
        }

        .order-container {
            background-color: #fff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .order-title {
            text-align: center;
            margin-bottom: 10px;
        }

        .order-date {
            text-align: center;
            color: #888;
            font-size: 0.9rem;
            margin-bottom: 20px;
        }

        .order-items {
            border: 2px solid #3498db;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dashed #3498db;
        }

        .order-item:last-child {
            border-bottom: none;
        }

        .order-total {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            font-weight: bold;
            border-top: 2px solid #3498db;
        }

        .message-box {
            background-color: #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            margin: 20px auto;
            max-width: 400px;
            height: 100px;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
        }
/* Dark mode toggle */
        .theme-switch {
            display: flex;
            align-items: center;
            margin-left: 15px;
        }

        .theme-switch-toggle {
            position: relative;
            display: inline-block;
            width: 40px;
            height: 20px;
        }

        .theme-switch-toggle input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 2px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: #2196F3;
        }

        input:checked + .slider:before {
            transform: translateX(18px);
        }

        /* Dark Mode Styles */
        body.dark-mode {
            background-color: #222;
            color: #f0f0f0;
        }

        body.dark-mode header,
        body.dark-mode nav,
        body.dark-mode footer {
            background-color: #333;
            border-color: #444;
        }

        body.dark-mode .order-container {
            background-color: #333;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        body.dark-mode .active-tab {
            background-color: #444;
        }

        body.dark-mode .message-box {
            background-color: #444;
        }

        body.dark-mode a,
        body.dark-mode nav ul li a,
        body.dark-mode .footer-links a {
            color: #f0f0f0;
        }
        
        body.dark-mode .payment-icon {
            background-color: #444;
        }
        /* Dark mode toggle */
        .theme-switch {
            display: flex;
            align-items: center;
            margin-left: 15px;
        }

        .theme-switch-toggle {
            position: relative;
            display: inline-block;
            width: 40px;
            height: 20px;
        }

        .theme-switch-toggle input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 2px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: #2196F3;
        }

        input:checked + .slider:before {
            transform: translateX(18px);
        }

</style>
<body>
 <?php
    include "header.php";
    ?>
    <main>
        <div class="order-container">
            <h2 class="order-title">Your Order</h2>
            <p class="order-date" id="order-date">Monday, March 28, 2025 at 4:13pm</p>

            <div class="order-items" id="order-items">
                <!-- Items will be added dynamically with JavaScript -->
            </div>

            <div class="message-box" id="message-box">
                Message
            </div>
        </div>
    </main>
    <?php
    include "footer.php";
    ?>

    <script>
        // Sample order data
        const orderItems = [
            { name: "Water Bottle", price: 20.00 },
            { name: "Paper Magazine", price: 10.00 },
            { name: "Something else that is really good", price: 5.00 },
            { name: "Other Items", price: 15.00 }
        ];

        // Calculate total
        const orderTotal = orderItems.reduce((total, item) => total + item.price, 0);

        // Function to display order items
        function displayOrderItems() {
            const container = document.getElementById('order-items');
            container.innerHTML = '';

            // Add items
            orderItems.forEach(item => {
                const div = document.createElement('div');
                div.className = 'order-item';
                div.innerHTML = `
                    <span class="item-name">${item.name}</span>
                    <span class="price">${item.price.toFixed(2)}</span>
                `;
                container.appendChild(div);
            });

            // Add total
            const totalDiv = document.createElement('div');
            totalDiv.className = 'order-total';
            totalDiv.innerHTML = `
                <span>Total</span>
                <span>${orderTotal.toFixed(2)}</span>
            `;
            container.appendChild(totalDiv);
        }

        // Update the current date
        function updateOrderDate() {
            const dateElement = document.getElementById('order-date');
            const now = new Date();
            
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit'
            };
            
            dateElement.textContent = now.toLocaleDateString('en-US', options).replace(' at', ' at');
        }

        // Theme toggle functionality
        function setupThemeToggle() {
            const themeToggle = document.getElementById('theme-toggle');
            
            // Check for saved theme preference or use default
            if (localStorage.getItem('darkMode') === 'enabled') {
                document.body.classList.add('dark-mode');
                themeToggle.checked = true;
            }

            themeToggle.addEventListener('change', () => {
                if (themeToggle.checked) {
                    document.body.classList.add('dark-mode');
                    localStorage.setItem('darkMode', 'enabled');
                } else {
                    document.body.classList.remove('dark-mode');
                    localStorage.setItem('darkMode', 'disabled');
                }
            });
        }

        // Shopping cart functionality (simplified)
        function setupCart() {
            const cartCount = document.getElementById('cart-count');
            // For demonstration, let's set a random number
            cartCount.textContent = Math.floor(Math.random() * 5);
        }

        // Message box functionality
        function setupMessageBox() {
            const messageBox = document.getElementById('message-box');
            messageBox.addEventListener('click', () => {
                const newMessage = prompt('Enter a message for this order:', '');
                if (newMessage !== null && newMessage.trim() !== '') {
                    messageBox.textContent = newMessage;
                }
            });
        }

        // Run on page load
        window.addEventListener('DOMContentLoaded', () => {
            displayOrderItems();
            updateOrderDate();
            setupThemeToggle();
            setupCart();
            setupMessageBox();
        });
    </script>
    
</body>
</html>