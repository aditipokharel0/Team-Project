<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
       <!-- Header with Logo and Search -->
   <header class="header">
        <a href="./index.php" class="logo"><img src="./images/logo.png" alt="HuddersKart Logo"></a>
        
        <div class="search-container">
            <input type="text" placeholder="Search">
            <i class="fa-solid fa-magnifying-glass"></i>
                </div>
        <div class="user-actions">
            <a href="./checkout.php">
                <div class="cart-icon">
                  <span>🛒</span>
                  <span class="cart-count">0</span>
                </div>
              </a>
              
            <a href="./login.php">Login</a>
            <a href="./register.php">Register</a>
            <a href="./costumer.php">👤</a>
        </div>
    </header>

    <!-- Main Navigation -->
    <nav class="main-nav">
        <div class="menu-toggle">☰</div>
        <ul class="nav-links">
            <li><a href="./index.php">Home</a></li>
            <li><a href="./about.php">About Us</a></li>
            <li><a href="./categories.php">Categories</a></li>
            <li><a href="/fi/final/trader_signup.php">Become a trader</a></li>
            <li><a href="./contact.php">Contact Us</a></li>
        </ul>
    </nav>
</body>
</html>