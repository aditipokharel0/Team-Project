<?php
// Prevent any unwanted output
ob_clean();

// Ensure proper content type
header('Content-Type: application/json');

session_start();
require_once 'connect.php';

try {
    // Validate input
    if (!isset($_POST['cart_product_id']) || !isset($_POST['change'])) {
        throw new Exception('Missing required parameters');
    }

    $cart_product_id = $_POST['cart_product_id'];
    $change = intval($_POST['change']);

    // First get current quantity
    $sql = "SELECT No_Of_Items FROM CART_PRODUCT WHERE Cart_Product_ID = :cart_product_id";
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ":cart_product_id", $cart_product_id);
    $success = oci_execute($stmt);

    if (!$success) {
        throw new Exception(oci_error($stmt)['message']);
    }

    $row = oci_fetch_array($stmt, OCI_ASSOC);
    $current_quantity = $row['NO_OF_ITEMS'];
    $new_quantity = $current_quantity + $change;

    if ($new_quantity < 1) {
        throw new Exception('Quantity cannot be less than 1');
    }

    // Update the quantity
    $update_sql = "UPDATE CART_PRODUCT 
                   SET No_Of_Items = :new_quantity 
                   WHERE Cart_Product_ID = :cart_product_id";

    $update_stmt = oci_parse($conn, $update_sql);
    oci_bind_by_name($update_stmt, ":new_quantity", $new_quantity);
    oci_bind_by_name($update_stmt, ":cart_product_id", $cart_product_id);
    $update_success = oci_execute($update_stmt);

    if (!$update_success) {
        throw new Exception(oci_error($update_stmt)['message']);
    }

    // Return success response
    echo json_encode([
        'success' => true,
        'new_quantity' => $new_quantity,
        'message' => 'Quantity updated successfully'
    ]);

} catch (Exception $e) {
    // Return error response
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Clean up
if (isset($stmt)) oci_free_statement($stmt);
if (isset($update_stmt)) oci_free_statement($update_stmt);
oci_close($conn);
?>