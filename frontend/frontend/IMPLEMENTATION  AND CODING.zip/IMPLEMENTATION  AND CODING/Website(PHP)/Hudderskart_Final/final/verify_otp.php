<?php
ob_start();
session_start();
include 'connect.php';

// ─────────────────────────────────────────────────────
// 0) Ensure the TRADER table has an IS_VERIFIED column
// ─────────────────────────────────────────────────────
$colCheck = oci_parse(
    $conn,
    "SELECT COLUMN_NAME 
       FROM USER_TAB_COLS 
      WHERE TABLE_NAME = 'TRADER' 
        AND COLUMN_NAME = 'IS_VERIFIED'"
);
oci_execute($colCheck);
if (!oci_fetch($colCheck)) {
    // Column missing → add it
    $ddl = "ALTER TABLE TRADER ADD (IS_VERIFIED NUMBER(1) DEFAULT 0 NOT NULL)";
    $ddlStmt = oci_parse($conn, $ddl);
    oci_execute($ddlStmt);
}

// ─────────────────────────────────────────────────────
// 1) Make sure we have OTP & trader in session
// ─────────────────────────────────────────────────────
if (empty($_SESSION['otp']) || empty($_SESSION['trader_id'])) {
    header('Location: trader_signup.php');
    exit;
}

$error = '';

// ─────────────────────────────────────────────────────
// 2) Handle form POST
// ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputOtp = trim($_POST['otp'] ?? '');

    if ($inputOtp === (string)$_SESSION['otp']) {
        // ─────────────────────────────────────────────────
        // 3) Mark trader as verified
        // ─────────────────────────────────────────────────
        $sql = "
          UPDATE TRADER
             SET IS_VERIFIED = 1
           WHERE TRADER_ID  = :id
        ";
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ':id', $_SESSION['trader_id']);

        if (oci_execute($stmt, OCI_COMMIT_ON_SUCCESS)) {
            // Clear OTP so page can’t be reused
            unset($_SESSION['otp']);
            // Redirect to trader login
            header('Location: trader-interface/TraderLogin.php');
            exit;
        } else {
            $e     = oci_error($stmt);
            $error = '❌ Database error: ' . htmlentities($e['message']);
        }
    } else {
        $error = '⚠️ Invalid verification code. Please try again.';
    }
}

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Verify Your Email – HuddersKart</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/register.css">
</head>
<body>
  <?php include 'header.php'; ?>

  <main>
    <div class="container">
      <div class="signup-container">

        <div class="signup-header">
          <h1>Enter Verification Code</h1>
          <h2>We’ve sent a code to <?= htmlspecialchars($_SESSION['trader_email']) ?></h2>
        </div>

        <?php if ($error): ?>
          <p class="error-msg"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form id="otp-form" method="POST" action="">
          <div class="form-group">
            <label for="otp">Verification Code</label>
            <input
              type="text"
              id="otp"
              name="otp"
              maxlength="6"
              pattern="\d{6}"
              required
              placeholder="123456"
            >
          </div>

          <button type="submit" class="submit-btn">VERIFY</button>
        </form>

        <p class="signin-link">
          Didn’t receive a code? <a href="traderregister.php">Register again</a>
        </p>
      </div>
    </div>
  </main>

  <?php include 'footer.php'; ?>
</body>
</html>
