import serial
import oracledb
from datetime import datetime

# — Enable Thick Mode with your Instant Client path
oracledb.init_oracle_client(lib_dir=r"C:\instantclient_21_17")

# # — Oracle DB Connection
# DB_USER = "Team"
# DB_PASS = "123456"
# DB_CONN = "localhost/xe"  # use XE for Express Edition

def get_serial_uid():
    try:
        arduino = serial.Serial('COM7', 9600, timeout=10)
        print("Waiting for RFID UID scan…")
        while True:
            line = arduino.readline().decode('utf-8').strip()
            if line.startswith("RFID Tag UID:"):
                uid = line.replace("RFID Tag UID:", "").strip()
                arduino.close()
                return uid
    except serial.SerialException as e:
        print(f"Error reading serial port: {e}")
        return None

def check_uid_exists(cursor, uid):
    # check against PRODUCT_NAME––you may switch to PRODUCT_ID if desired
    cursor.execute(
        "SELECT COUNT(*) FROM PRODUCT WHERE PRODUCT_NAME = :1",
        (uid,)
    )
    return cursor.fetchone()[0] > 0

def insert_product(cursor, uid):
    print("\nEnter product details:")
    product_name = input("Product Name: ")
    description  = input("Description: ")
    price        = float(input("Price: "))
    stock        = int(input("Stock: "))
    min_order    = int(input("Minimum Order (Min_Order): "))
    max_order    = int(input("Maximum Order (Max_Order): "))
    shop_id      = int(input("Shop ID (FK1_SHOP_ID): "))
    trader_id    = int(input("Trader ID (FK2_TRADER_ID): "))
    category_id  = int(input("Category ID (FK3_CATEGORY_ID): "))
    image_path   = input("Image file path: ").strip().strip('"')

    try:
        with open(image_path, 'rb') as f:
            image_data = f.read()
    except Exception as e:
        print(f"❌ Could not read image: {e}")
        return

    cursor.execute("""
        INSERT INTO PRODUCT (
            PRODUCT_NAME,
            DESCRIPTION,
            PRICE,
            STOCK,
            DATE_ADDED,
            PRODUCT_IMAGE,
            MIN_ORDER,
            MAX_ORDER,
            FK1_SHOP_ID,
            FK2_TRADER_ID,
            FK3_CATEGORY_ID
        ) VALUES (
            :product_name,
            :description,
            :price,
            :stock,
            SYSDATE,
            :product_image,
            :min_order,
            :max_order,
            :shop_id,
            :trader_id,
            :category_id
        )
    """, {
        'product_name': product_name,
        'description' : description,
        'price'       : price,
        'stock'       : stock,
        'product_image': image_data,
        'min_order'   : min_order,
        'max_order'   : max_order,
        'shop_id'     : shop_id,
        'trader_id'   : trader_id,
        'category_id' : category_id
    })

def main():
    try:
        conn = oracledb.connect(user=DB_USER, password=DB_PASS, dsn=DB_CONN)
        cursor = conn.cursor()
        print("✅ Connected to Oracle DB.")
    except oracledb.DatabaseError as e:
        print(f"❌ Connection error: {e}")
        return

    try:
        while True:
            uid = get_serial_uid()
            if not uid:
                print("⚠️ No UID read; retry.")
                continue

            print(f"\n📟 UID scanned: {uid}")
            if check_uid_exists(cursor, uid):
                print("⚠️ A product with this name already exists.")
            else:
                print("✅ New product—collecting details...")
                insert_product(cursor, uid)
                conn.commit()
                print("🎉 Insert successful.")

            if input("Scan another? (y/n): ").lower() != 'y':
                break

    except KeyboardInterrupt:
        print("\n🛑 Interrupted by user.")
    finally:
        cursor.close()
        conn.close()
        print("🔒 Connection closed.")

if __name__ == "__main__":
    main()



# import serial
# import cx_Oracle

# # Arduino Serial Port Settings
# SERIAL_PORT = 'COM11'  # Update with your actual COM port
# BAUD_RATE = 9600

# # Oracle DB Connection
# DB_USER = "TEAM16"
# DB_PASS = "123456"
# DB_CONN = "localhost:1521/XE"


# def get_serial_uid():
#     try:
#         arduino = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=10)
#         print("Waiting for RFID UID scan…")
#         while True:
#             line = arduino.readline().decode('utf-8').strip()
#             if line.startswith("RFID Tag UID:"):
#                 uid_str = line.replace("RFID Tag UID:", "").strip()
#                 arduino.close()
#                 return uid_str
#     except serial.SerialException as e:
#         print(f"Error reading serial port: {e}")
#         return None


# def check_uid_exists(cursor, product_id):
#     cursor.execute(
#         "SELECT COUNT(*) FROM PRODUCT WHERE Product_ID = :1",
#         (product_id,)
#     )
#     return cursor.fetchone()[0] > 0


# def insert_product(cursor, product_id):
#     print("Enter product details:")
#     product_name = input("Product Name: ")
#     description  = input("Description: ")
#     price        = float(input("Price: "))
#     stock        = int(input("Stock: "))
#     min_order    = int(input("Min Order: "))
#     max_order    = int(input("Max Order: "))
#     shop_id      = int(input("Shop ID (fk1_Shop_ID): "))
#     trader_id    = int(input("Trader ID (fk2_Trader_ID): "))
#     category_id  = int(input("Product Category ID (fk3_Category_ID): "))

#     cursor.execute("""
#         INSERT INTO PRODUCT (
#             Product_ID,
#             Product_Name,
#             Description,
#             Price,
#             Stock,
#             Date_Added,
#             Product_Image,
#             Min_Order,
#             Max_Order,
#             fk1_Shop_ID,
#             fk2_Trader_ID,
#             fk3_Category_ID
#         ) VALUES (
#             :product_id,
#             :product_name,
#             :description,
#             :price,
#             :stock,
#             SYSDATE,
#             :product_image,
#             :min_order,
#             :max_order,
#             :shop_id,
#             :trader_id,
#             :category_id
#         )
#     """, {
#         'product_id':    product_id,
#         'product_name':  product_name,
#         'description':   description,
#         'price':         price,
#         'stock':         stock,
#         'product_image': None,        # NULL blob for now
#         'min_order':     min_order,
#         'max_order':     max_order,
#         'shop_id':       shop_id,
#         'trader_id':     trader_id,
#         'category_id':   category_id
#     })


# def main():
#     try:
#         conn = cx_Oracle.connect(DB_USER, DB_PASS, DB_CONN)
#         cursor = conn.cursor()
#         print("Connected to Oracle DB successfully.")
#     except cx_Oracle.DatabaseError as e:
#         print(f"Database connection error: {e}")
#         return

#     try:
#         while True:
#             uid_str = get_serial_uid()
#             if not uid_str:
#                 print("No UID read. Try again.")
#                 continue

#             # assume UID is decimal; if hex, you could do int(uid_str, 16)
#             try:
#                 product_id = int(uid_str)
#             except ValueError:
#                 print("⚠️  UID not a valid integer. Skipping.")
#                 continue

#             print(f"Scanned UID as Product_ID: {product_id}")

#             if check_uid_exists(cursor, product_id):
#                 print("⚠️  Product_ID already exists. Please scan a different tag.")
#             else:
#                 print("✅ New Product_ID. Let's add the product.")
#                 insert_product(cursor, product_id)
#                 conn.commit()
#                 print("🎉 Product inserted successfully.")

#             if input("Scan another? (y/n): ").lower() != 'y':
#                 break

#     except KeyboardInterrupt:
#         print("\nProcess interrupted by user.")
#     finally:
#         cursor.close()
#         conn.close()
#         print("Connection closed.")


# if __name__ == "__main__":
#     main()
