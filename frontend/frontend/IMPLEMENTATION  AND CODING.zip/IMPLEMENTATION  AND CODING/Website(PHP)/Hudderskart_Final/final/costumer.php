<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - HuddersKart</title>
    <link rel="stylesheet" href="./css/customer.css">
</head>

<body>
    <?php
    include "header.php";
    ?>
    <main class="container">
        <section class="profile-section">
            <h1 class="profile-heading">Profile</h1>
            <div class="profile-avatar" id="avatar-container">
                <img id="avatar-image" src="/api/placeholder/150/150" alt="Profile Avatar">
                <div class="avatar-overlay">
                    <span>📷 Update Photo</span>
                </div>
                <input type="file" id="file-upload" class="file-input" accept="image/*">
            </div>
            <h2 class="profile-name">LOREM IPSUM</h2>
            <div class="profile-info">
                <div class="info-box">Full Name: Name</div>
                <div class="info-box">Email: XYZ@gmail.com</div>
                <div class="info-box">Contact: 015559934</div>
            </div>
            <div class="profile-bio" id="bio-section">
                <!-- Bio content will go here -->
            </div>
        </section>
    </main>

    <!-- Photo Upload Modal -->
    <div id="upload-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h2>Upload Profile Photo</h2>
            <p>Select an image to set as your profile picture</p>
            <button class="upload-btn" id="trigger-file-select">Choose File</button>
            <div class="preview-container">
                <img id="preview-image" class="image-preview" style="display: none;">
            </div>
            <button class="confirm-upload" id="confirm-upload" style="display: none;">Save Photo</button>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="notification"></div>

    <?php
    include "footer.php";
    ?>

    <script src="./script/customer.js">
    </script>
</body>

</html>