<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <!-- Footer -->
    <div class="separator"></div>
    <footer>
        <div class="footer">
            <div class="footer-section">
                <div class="footer-logo"><img src="images/logo.png" alt="HuddersKart Logo" style="height: 40px;"></div>
                <div class="footer-location">Hudderskart</div>
                <div class="contact-info">
                    <p><strong>Contact Information</strong></p>
                    <p>Email: HuddersKart12@gmail.com</p>
                    <p>Phone: 01555321</p>
                    <p>Address: Duarbarmarg, Kathmandu</p>
                </div>
            </div>

            <div class="footer-section">
                <h3>LINKS</h3>
                <ul class="footer-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Categories</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Profile</a></li>
                    <li><a href="#">Cart</a></li>
                    <li><a href="#">Login/Register</a></li>
                    <li><a href="#">Products</a></li>
                    <li><a href="#">Trader</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Help & Support</h3>
                <ul class="footer-links">
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Return & Refund Policy</a></li>
                    <li><a href="#">Shipping Information</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Social Media Links</h3>
                <div class="social-media">
                    <a href="#" class="social-icon">f</a>
                    <a href="#" class="social-icon">in</a>
                    <a href="#" class="social-icon">x</a>
                    <a href="#" class="social-icon">ig</a>
                </div>

                <h3 style="margin-top: 20px;">Payment Methods</h3>
                <div class="payment-methods">
    <img src="images/paypal.png" alt="PayPal" class="payment-icon" style="height: 35px; margin-right: 10px;">
    <img src="images/stripe.png" alt="Stripe" class="payment-icon" style="height: 35px;">
</div>

            </div>
        </div>

        <div class="copyright">
            © 2025 HUDDERSKART. ALL RIGHTS RESERVED
        </div>
    </footer>

</body>
</html>