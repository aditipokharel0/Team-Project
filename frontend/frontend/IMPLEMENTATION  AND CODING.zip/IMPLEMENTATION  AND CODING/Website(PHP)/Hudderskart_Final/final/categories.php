<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HuddersKart - Local Food Marketplace</title>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="./css/categories.css">

</head>

<body>
    <?php
    include "header.php";
    ?>
    <!-- Main Content -->
    <main class="main-content">
        <h2 class="section-title">Product Categories</h2>

        <!-- Categories Grid -->
        <div class="category-grid">
            <div class="category-card" data-category="butchers">
                <div class="category-image">
                    <img src="https://images.unsplash.com/photo-1601642263169-e6159cd2320e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnV0Y2hlcnN8ZW58MHx8MHx8fDA%3D"
                        alt="Butchers">
                </div>
                <div class="category-name"><a href="./butcher.php">Butcher</a></div>
            </div>
            </a>


            <!-- Category 2 -->
            <div class="category-card" data-category="greengrocer">
                <div class="category-image">
                    <img src="https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=300&h=200&fit=crop"
                        alt="Greengrocer">
                </div>
                <div class="category-name"><a href="green.html">Greengrocer</a></div>
            </div>

            <!-- Category 3 -->
            <div class="category-card" data-category="delicatessen">
                <div class="category-image">
                    <img src="https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=300&h=200&fit=crop"
                        alt="Delicatessen">
                </div>
                <div class="category-name"><a href="delicate.html">Delicatessen</a></div>
            </div>

            <!-- Category 4 -->
            <div class="category-card" data-category="fishmonger">
                <div class="category-image">
                    <img src="https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=300&h=200&fit=crop"
                        alt="Fishmonger">
                </div>
                <div class="category-name"><a href="fishmonger.html">Fishmonger</a></div>
            </div>

            <!-- Category 5 -->
            <div class="category-card" data-category="bakery">
                <div class="category-image">
                    <img src="https://images.unsplash.com/photo-1568254183919-78a4f43a2877?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8YmFrZXJ5fGVufDB8fDB8fHww"
                        alt="Bakery">
                </div>
                <div class="category-name"><a href="bakery.html">Bakery</a></div>
            </div>

            <!-- Category 6 -->
            <div class="category-card" data-category="new-trader">
                <div class="category-image">
                    <img src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=300&h=200&fit=crop"
                        alt="New Trader">
                </div>
                <div class="category-name"><a href="newtrader.html">Trader</a></div>
            </div>
        </div>
    </main>

    <!-- Cart Sidebar -->
    <div class="cart-overlay"></div>
    <div class="cart-sidebar">
        <div class="cart-header">
            <h2>Your Cart</h2>
            <button class="close-cart">&times;</button>
        </div>
        <div class="cart-items">
            <!-- Cart items will be added here dynamically -->
            <div class="empty-cart" style="text-align: center; padding: 20px; color: #666; font-style: italic;">Your
                cart is empty</div>
        </div>
        <div class="cart-total">
            Total: £0.00
        </div>
        <button class="checkout-btn">Proceed to Checkout</button>
    </div>
    <?php
    include "footer.php";
    ?>

    <script src="./script/categories.js">
    </script>
</body>

</html>