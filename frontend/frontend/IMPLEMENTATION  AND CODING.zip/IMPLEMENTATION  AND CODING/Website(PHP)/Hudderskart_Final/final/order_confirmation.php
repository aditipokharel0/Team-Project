<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['customer_id']) || !isset($_GET['order_id'])) {
    header('Location: login.php');
    exit;
}

$order_id = $_GET['order_id'];

// Fetch order details
$sql = "SELECT o.Order_ID, o.Order_Date, o.Total_Amount,
               p.Payment_Method, p.Payment_Date
        FROM ORDER1 o
        JOIN PAYMENT p ON o.fk2_Payment_ID = p.Payment_ID
        WHERE o.Order_ID = :order_id 
        AND o.fk1_Customer_ID = :customer_id";

$stmt = oci_parse($conn, $sql);
oci_bind_by_name($stmt, ":order_id", $order_id);
oci_bind_by_name($stmt, ":customer_id", $_SESSION['customer_id']);
oci_execute($stmt);

$order = oci_fetch_assoc($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation - HuddersKart</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Order Confirmation</h1>
        <?php if ($order): ?>
            <div class="order-details">
                <h2>Thank you for your order!</h2>
                <p>Order ID: <?php echo $order['ORDER_ID']; ?></p>
                <p>Order Date: <?php echo $order['ORDER_DATE']; ?></p>
                <p>Total Amount: £<?php echo number_format($order['TOTAL_AMOUNT'], 2); ?></p>
                <p>Payment Method: <?php echo $order['PAYMENT_METHOD']; ?></p>
                <a href="main.php" class="continue-shopping">Continue Shopping</a>
            </div>
        <?php else: ?>
            <p>Order not found.</p>
        <?php endif; ?>
    </div>
</body>
</html>