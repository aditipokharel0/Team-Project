<?php
return [
    'client_id' => 'ASP1xkDiPg36qfoBLLM_Bg3WnYDLQCz6q7YTQU8kSKZVABMJytD8fF7EVm4YNDDg4YFK85mKH_nAhkAv',
    'secret' => 'EAWNtu__EDsiCosE0S-KvUbS2ZxfB7KUqimOAV4gP8_BAju097ev5SbpoJgkyngoq31Hs2oON5fSEBBW',
    'settings' => [
        'mode' => 'sandbox', // Change to 'live' when going to production
        'http.ConnectionTimeOut' => 30,
        'log.LogEnabled' => true,
        'log.FileName' => __DIR__ . '/PayPal.log', // Adjust path as needed
        'log.LogLevel' => 'DEBUG', // Options: 'DEBUG', 'INFO', 'WARN' or 'ERROR'
    ]
];
