<!-- <?php
require_once '../config.php';

header('Content-Type: application/json');

// Get the POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate required fields
if (!isset($data['payment_id'], $data['amount'], $data['payment_method'], $data['transaction_id'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Connect to Oracle database
$conn = oci_connect(DB_USER, DB_PASSWORD, DB_CONNECTION_STRING);
if (!$conn) {
    $error = oci_error();
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $error['message']]);
    exit;
}

try {
    // Prepare SQL statement
    $sql = "INSERT INTO PAYMENT 
            (PAYMENT_ID, AMOUNT, PAYMENT_METHOD, PAYMENT_DATE, TRANSACTION_ID, STATUS) 
            VALUES (:payment_id, :amount, :payment_method, SYSDATE, :transaction_id, :status)";
    
    $stmt = oci_parse($conn, $sql);
    
    // Bind parameters
    oci_bind_by_name($stmt, ':payment_id', $data['payment_id']);
    oci_bind_by_name($stmt, ':amount', $data['amount']);
    oci_bind_by_name($stmt, ':payment_method', $data['payment_method']);
    oci_bind_by_name($stmt, ':transaction_id', $data['transaction_id']);
    oci_bind_by_name($stmt, ':status', $data['status'] ?? 'COMPLETED');
    
    // Execute the statement
    $result = oci_execute($stmt);
    
    if ($result) {
        oci_commit($conn);
        echo json_encode([
            'success' => true,
            'payment_id' => $data['payment_id'],
            'message' => 'Payment processed successfully'
        ]);
    } else {
        $error = oci_error($stmt);
        echo json_encode([
            'success' => false,
            'message' => 'Failed to process payment: ' . $error['message']
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
} finally {
    if ($conn) {
        oci_close($conn);
    }
}
?>-->

<?php
// process_payment.php
session_start();
include 'connect.php';   // must define $conn = oci_connect(...)

// 1) Ensure customer is logged in
$customerId = $_SESSION['customer_id'] ?? null;
if (!$customerId) {
    die('You must be logged in to checkout.');
}

// 2) Read & decode cart JSON
$cartJson = $_POST['cartData'] ?? '';
$cart     = json_decode($cartJson, true);
if (!is_array($cart) || empty($cart)) {
    die('Your cart is empty.');
}

// 3) Calculate total price and total item count
$total     = 0.0;
$itemCount = 0;
foreach ($cart as $item) {
    $qty   = intval($item['quantity']);
    $price = floatval($item['price']);
    $total     += $price * $qty;
    $itemCount += $qty;
}
$total = number_format($total, 2, '.', '');

// 4) Insert into CART, returning the new CART_ID
$newCartId = null;
$sql = "
  INSERT INTO CART (
    CART_ID,
    NO_OF_ITEMS,
    TOTAL_PRICE,
    FK1_CUSTOMER_ID
  ) VALUES (
    CART_SEQ.NEXTVAL,
    :numItems,
    :totalPrice,
    :custId
  )
  RETURNING CART_ID INTO :newCartId
";
$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ':numItems',   $itemCount);
oci_bind_by_name($stid, ':totalPrice', $total);
oci_bind_by_name($stid, ':custId',     $customerId);
oci_bind_by_name($stid, ':newCartId',  $newCartId, 32, SQLT_INT);

if (!oci_execute($stid)) {
    $e = oci_error($stid);
    die("Database insert failed: " . $e['message']);
}
oci_commit($conn);

// 5) Insert each cart item into CART_PRODUCT
$insertItemSql = "
  INSERT INTO CART_PRODUCT (CART_ID, PRODUCT_ID, QUANTITY)
   VALUES (:cartId, :prodId, :qty)
";
foreach ($cart as $item) {
    $s2 = oci_parse($conn, $insertItemSql);
    oci_bind_by_name($s2, ':cartId', $newCartId);
    oci_bind_by_name($s2, ':prodId', $item['id']);
    oci_bind_by_name($s2, ':qty',    $item['quantity']);
    if (!oci_execute($s2)) {
        $e = oci_error($s2);
        die("Failed to insert cart item: " . $e['message']);
    }
}
oci_commit($conn);

// 6) PayPal credentials & endpoints
$clientId = 'YOUR_SANDBOX_CLIENT_ID';
$secret   = 'YOUR_SANDBOX_SECRET';
$baseUrl  = 'https://api.sandbox.paypal.com';

// ─── Get OAuth token ───────────────────────────────────────────────
$ch = curl_init("$baseUrl/v1/oauth2/token");
curl_setopt($ch, CURLOPT_USERPWD,    "$clientId:$secret");
curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Accept: application/json',
    'Accept-Language: en_US',
]);
$tokenResult = curl_exec($ch);
if (!$tokenResult) {
    die('Error fetching PayPal token: ' . curl_error($ch));
}
curl_close($ch);

$tokenData   = json_decode($tokenResult, true);
$accessToken = $tokenData['access_token'] 
               ?? die('No access token from PayPal');

// ─── Create PayPal payment ─────────────────────────────────────────
$payload = [
    'intent'        => 'sale',
    'payer'         => ['payment_method' => 'paypal'],
    'redirect_urls' => [
      'return_url' => 'http://your-domain.com/execute_payment.php?success=true',
      'cancel_url' => 'http://your-domain.com/checkout.php?success=false'
    ],
    'transactions'  => [[
      'amount'      => [
        'total'    => $total,
        'currency' => 'USD'
      ],
      'description' => 'Order #'. $newCartId .' at HuddersKart'
    ]]
];

$ch = curl_init("$baseUrl/v1/payments/payment");
curl_setopt($ch, CURLOPT_POST,          true);
curl_setopt($ch, CURLOPT_POSTFIELDS,    json_encode($payload));
curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    "Authorization: Bearer $accessToken"
]);
$paymentResult = curl_exec($ch);
if (!$paymentResult) {
    die('Error creating PayPal payment: ' . curl_error($ch));
}
curl_close($ch);

$payData    = json_decode($paymentResult, true);
$approvalUrl = null;
foreach ($payData['links'] as $link) {
    if ($link['rel'] === 'approval_url') {
        $approvalUrl = $link['href'];
        break;
    }
}
if (!$approvalUrl) {
    die('No PayPal approval link returned.');
}

// 7) Redirect the user to PayPal
header('Location: ' . $approvalUrl);
exit;
