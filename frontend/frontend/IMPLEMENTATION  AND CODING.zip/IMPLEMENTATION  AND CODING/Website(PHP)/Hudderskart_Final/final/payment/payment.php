<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout with PayPal</title>
    <link rel="stylesheet" href="style.css">
    <!-- Add PayPal SDK -->
    <script src="https://www.paypal.com/sdk/js?client-id=YOUR_SANDBOX_CLIENT_ID&currency=USD"></script>
</head>
<style>
    body {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
    color: #333;
}

.checkout-container {
    max-width: 800px;
    margin: 30px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

h1, h2 {
    color: #2c3e50;
}

.order-summary {
    border: 1px solid #ddd;
    padding: 20px;
    margin-bottom: 30px;
    border-radius: 5px;
}

.order-item, .order-total {
    display: flex;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid #eee;
}

.order-total {
    font-weight: bold;
    border-bottom: none;
}

.payment-section {
    margin-top: 30px;
}

#paypal-button-container {
    margin: 20px 0;
    max-width: 300px;
}

#payment-success {
    background-color: #e8f8f5;
    padding: 20px;
    border-radius: 5px;
    margin-top: 30px;
    display: none;
}

#payment-success h2 {
    color: #27ae60;
}

.payment-details {
    background: white;
    padding: 15px;
    border-radius: 5px;
    margin-top: 15px;
}

.hidden {
    display: none;
}
</style>
<body>
    <div class="checkout-container">
        <h1>Complete Your Purchase</h1>
        
        <div class="order-summary">
            <h2>Order Summary</h2>
            <div class="order-item">
                <span>Product Name</span>
                <span>$19.99</span>
            </div>
            <div class="order-total">
                <span>Total</span>
                <span>$19.99</span>
            </div>
        </div>
        
        <div class="payment-section">
            <h2>Payment Method</h2>
            <div id="paypal-button-container"></div>
        </div>
        
        <div id="payment-success" class="hidden">
            <h2>Payment Successful!</h2>
            <p>Thank you for your purchase.</p>
            <div class="payment-details">
                <p>Payment ID: <span id="payment-id"></span></p>
                <p>Transaction ID: <span id="transaction-id"></span></p>
            </div>
        </div>
    </div>

    <script>
        // Set up PayPal button
        paypal.Buttons({
            style: {
                shape: 'rect',
                color: 'gold',
                layout: 'vertical',
                label: 'paypal'
            },
            
            // Create order
            createOrder: function(data, actions) {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: '19.99' // Set your amount here
                        }
                    }]
                });
            },
            
            // On approval
            onApprove: function(data, actions) {
                return actions.order.capture().then(function(details) {
                    // Show success message
                    document.getElementById('payment-success').classList.remove('hidden');
                    document.getElementById('transaction-id').textContent = details.id;
                    
                    // Send data to server
                    fetch('process_payment.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            payment_id: 'PAY-' + Math.floor(Math.random() * 1000000),
                            amount: 19.99,
                            payment_method: 'PAYPAL',
                            transaction_id: details.id,
                            status: 'COMPLETED'
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if(data.success) {
                            document.getElementById('payment-id').textContent = data.payment_id;
                        }
                    });
                });
            },
            
            // Handle errors
            onError: function(err) {
                console.error('PayPal error:', err);
                alert('Payment failed. Please try again.');
            }
        }).render('#paypal-button-container');
    </script>
</body>
</html>