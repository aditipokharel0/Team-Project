<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['customer_id']) || !isset($_GET['order_id'])) {
    header('Location: index.php');
    exit;
}

$order_id = $_GET['order_id'];

// Fetch order details
$sql = "SELECT o.Order_ID, o.Order_Date, o.Total_Amount, o.Quantity,
               p.Payment_Method, p.Amount as Payment_Amount
        FROM ORDER1 o
        JOIN PAYMENT p ON o.fk2_Payment_ID = p.Payment_ID
        WHERE o.Order_ID = :order_id AND o.fk1_Customer_ID = :customer_id";

$stmt = oci_parse($conn, $sql);
oci_bind_by_name($stmt, ":order_id", $order_id);
oci_bind_by_name($stmt, ":customer_id", $_SESSION['customer_id']);
oci_execute($stmt);

$order = oci_fetch_assoc($stmt);

if (!$order) {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Successful - HuddersKart</title>
    <link rel="stylesheet" href="./css/style.css">
    <style>
        .success-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            text-align: center;
        }
        .success-icon {
            font-size: 48px;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        .order-details {
            margin: 20px 0;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 5px;
        }
        .continue-shopping {
            display: inline-block;
            padding: 10px 20px;
            background: #111;
            color: white;
            text-decoration: none;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="success-container">
        <div class="success-icon">✓</div>
        <h1>Order Successful!</h1>
        <p>Thank you for your purchase.</p>
        
        <div class="order-details">
            <h2>Order Details</h2>
            <p>Order ID: #<?php echo $order['ORDER_ID']; ?></p>
            <p>Date: <?php echo date('d M Y', strtotime($order['ORDER_DATE'])); ?></p>
            <p>Total Amount: £<?php echo number_format($order['TOTAL_AMOUNT'], 2); ?></p>
            <p>Payment Method: <?php echo $order['PAYMENT_METHOD']; ?></p>
        </div>

        <p>A confirmation email has been sent to your registered email address.</p>
        <a href="index.php" class="continue-shopping">Continue Shopping</a>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>